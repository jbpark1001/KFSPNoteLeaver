# Replication code for Patterns of Communication Before Suicide

Prepared 9 November 2026 against the supplied main manuscript and the Supplementary Methods supplied in this chat. This is a new, separate local replication project. Original study scripts and the earlier `manuscript_analysis` workspace were not edited.

**Read [the replication status](docs/REPLICATION_STATUS.md) before interpreting a rerun.** The saved-feature analyses can be rerun, but the newer classifier and the frozen primary corpus do not describe the same cohort. The available manual labels do not reproduce the stated 80.5% agreement. Code cannot resolve those source discrepancies by itself.

## Run locally

Open PowerShell in this folder:

```powershell
& 'C:/anaconda3/envs/NLP/python.exe' run.py list
& 'C:/anaconda3/envs/NLP/python.exe' run.py check
& 'C:/anaconda3/envs/NLP/python.exe' run.py audit-inputs
& 'C:/anaconda3/envs/NLP/python.exe' -m unittest discover -s tests -v
```

`check` reports file presence and parses Python source; missing generated intermediates are expected before their producing stages run. It does not establish statistical reproduction. `--dry-run` prints the invocation without running an analysis. Every executed stage writes a timestamped log and stops on a nonzero exit code. Numerical checks are separate from input checks.

The local `config/paths.json` points to the existing restricted inputs without copying them. `config/runtime.json` identifies Python and R. On another machine, copy the three `*.example.json` files to their corresponding names without `.example` and configure the authorized input locations. Interpreter names on PATH are accepted. See [the data contract](docs/DATA_CONTRACT.md) and [the analysis map](docs/ANALYSIS_MAP.md).

## Current manuscript, saved-cohort route

```powershell
# All current stages in dependency order; includes the full 4,999 permutations.
& 'C:/anaconda3/envs/NLP/python.exe' run.py current --dry-run
& 'C:/anaconda3/envs/NLP/python.exe' run.py current

# Or run individual stages to reuse completed results:
& 'C:/anaconda3/envs/NLP/python.exe' run.py dictionary-sensitivity
& 'C:/anaconda3/envs/NLP/python.exe' run.py communication-profiles
& 'C:/anaconda3/envs/NLP/python.exe' run.py communication-age-contrasts
& 'C:/anaconda3/envs/NLP/python.exe' run.py communication-sex
& 'C:/anaconda3/envs/NLP/python.exe' run.py communication-sensitivity
& 'C:/anaconda3/envs/NLP/python.exe' run.py verbal-sentiments
& 'C:/anaconda3/envs/NLP/python.exe' run.py content-prevalence
& 'C:/anaconda3/envs/NLP/python.exe' run.py fig05-06
& 'C:/anaconda3/envs/NLP/python.exe' run.py sentence-order-permutation --jobs 4
& 'C:/anaconda3/envs/NLP/python.exe' tools/verify_manuscript_claims.py
```

The new permutation implementation follows the supplied Supplementary Methods: midpoint thirds, any-sentence section presence, all five thematic labels shuffled jointly within each note, five age-versus-rest models with all 15 thematic features and recorded sex, coefficient range and absolute ending-minus-opening statistics, plus-one p-values, and Holm correction across ten tests. The original permutation seed was unavailable; the explicit new default is 20261109. The completed corrected run matches the reported permutation conclusions; a full-cohort parity check validates all 279,720 indicators and the observed coefficients. Completed draws are checkpointed, and rerunning the same command resumes them after checking source and script hashes. A changed implementation or source requires a different output directory/seed. A reduced `--n-perm` is only a diagnostic run and is labeled separately.

## Historical classifier labels used by the primary cohort

The older saved classification snapshot has now been verified and wired into a separate branch: 27,294 raw / 10,168 summarized, with every raw ID matching the frozen primary features. See [the recovery report](docs/HISTORICAL_CLASSIFIER_RECOVERY.md). The exact original training implementation was not recovered: none of the four refitted historical definitions matches all saved labels. This branch imports verified historical predictions rather than claiming an identified old model.

```powershell
& 'C:/anaconda3/envs/NLP/python.exe' run.py 10-primary-labels --text-branch historical
& 'C:/anaconda3/envs/NLP/python.exe' run.py nlp-rebuild-primary --dry-run
# Full NLP rebuild, when intended:
& 'C:/anaconda3/envs/NLP/python.exe' run.py nlp-rebuild-primary
& 'C:/anaconda3/envs/NLP/python.exe' run.py fig05-06 --inputs rebuilt --text-branch historical
```

Historical intermediates live in `derived/historical_primary/`, with rebuilt analysis outputs in `outputs/rebuilt/historical_primary/`. Newer artifacts remain separate. The existing saved-feature analyses already retain the historical primary cohort. To describe this cohort consistently, the manuscript must use the older classification count or explicitly distinguish the two classifier versions. Manual agreement of 80.5% remains unreproduced.

## Rebuild NLP

```powershell
& 'C:/anaconda3/envs/NLP/python.exe' run.py nlp-rebuild --dry-run
& 'C:/anaconda3/envs/NLP/python.exe' run.py 10-classify --stability --weak-holdout
& 'C:/anaconda3/envs/NLP/python.exe' run.py verify-classifier-stability
& 'C:/anaconda3/envs/NLP/python.exe' run.py 11-segment
& 'C:/anaconda3/envs/NLP/python.exe' run.py 12-keywords
& 'C:/anaconda3/envs/NLP/python.exe' run.py 13-sentiments
& 'C:/anaconda3/envs/NLP/python.exe' run.py 17-build-primary-features
& 'C:/anaconda3/envs/NLP/python.exe' run.py fig05-06 --inputs rebuilt
```

These stages start from the supplied eligible-note workbook. They require the external Korean language models/tokenizers, the KOTE checkpoint, and compatible dependencies. The rebuilt branch produces a different cohort and cannot be substituted into published results while retaining the published numbers. Current communication/content extensions deliberately reject `--inputs rebuilt` until their cohort/linkage is reconciled. Primary demographic feature models and segmentation sensitivity stages support the rebuilt branch with separate outputs.

`text_analysis/00_prepare_eligible_notes.py` supplies the missing registry-to-eligible-workbook step, conditional on an authoritative ordered inclusion/exclusion manifest. The original 582 exclusion decisions were not supplied. Do not infer them from the desired count. This optional stage documents and verifies their provenance rather than inventing a language-selection rule.

## Contents and provenance

- `scripts/`: original demographic cleaning, eight candidate models, final model and plots, adapted to project paths.
- `text_analysis/`: classifier, segmentation, keyword/sentiment extraction, feature construction, sensitivity models and the newly implemented permutation test.
- `tools/`: current communication, content, prevalence, dictionary sensitivity, figure and validation stages.
- `figures/`: primary feature-association plots and retained earlier figure scripts. Figure numbering in old filenames belongs to the earlier manuscript; use the analysis map for current scope.
- `reference/originals/`: preserved supplied scripts. `reference/recovered/` adds relevant original scripts found outside the provided folder. Historical exploratory content-versus-placement scripts are reference material, not the specified permutation test.
- `tests/`: numerical checks of joint permutation invariants, aggregation, model parity and the four primary FDR families.
- `docs/`: source provenance, analysis map, data contract, known discrepancies and validation record.
- `derived/` and `outputs/`: locally generated intermediates and results. They can contain restricted case-level information and are excluded from version control. The complete local folder is not a public data release.

No installations, manuscript edits, GitHub uploads or source-data modifications are performed by this package. Expected manuscript numbers appear only in validation code and documentation; estimators calculate results from configured inputs.
