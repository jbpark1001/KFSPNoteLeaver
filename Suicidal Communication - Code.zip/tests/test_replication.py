"""Numerical checks of the new permutation implementation and primary FDR."""
from pathlib import Path
import sys,ast,importlib.util,unittest
import os
import numpy as np
import pandas as pd
import statsmodels.api as sm
from unittest.mock import patch
from statsmodels.stats.multitest import multipletests
from threadpoolctl import threadpool_limits
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))

def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m

perm=load('permutation_test',ROOT/'text_analysis/18_sentence_order_permutation.py')

class ScientificChecks(unittest.TestCase):
    def test_historical_rebuild_does_not_replace_newer_artifacts(self):
        import project
        with patch.dict(os.environ,{'MANUSCRIPT_TEXT_BRANCH':'newer','MANUSCRIPT_INPUT_PROFILE':'rebuilt'}):
            newer=project.derived_path('scored_notes.pkl')
            self.assertEqual(project.input_path('raw_features'),ROOT/'derived/primary_theme_features.pkl')
        with patch.dict(os.environ,{'MANUSCRIPT_TEXT_BRANCH':'historical','MANUSCRIPT_INPUT_PROFILE':'rebuilt'}):
            historical=project.derived_path('scored_notes.pkl')
            self.assertEqual(project.input_path('raw_features'),ROOT/'derived/historical_primary/primary_theme_features.pkl')
            self.assertEqual(project.input_path('section_results'),ROOT/'outputs/rebuilt/historical_primary/tables/section_robustness')
        self.assertNotEqual(newer,historical)

    def test_fixed_model_bootstrap_matches_independent_rescoring(self):
        m=load('raw_detector_bootstrap_test',ROOT/'text_analysis/raw_detector.py')
        class DeterministicModel:
            def predict_proba(self,frame):
                p=frame.NOTE_CONTENTDTL.str.len().to_numpy()%7/7
                return np.column_stack([1-p,p])
        d=pd.DataFrame({'NOTE_CONTENTDTL':['x'*i for i in range(1,35)]})
        model=DeterministicModel();seed=812;B=200;frac=.8
        actual=m.bootstrap_class_proportion(model,d,B=B,frac=frac,seed=seed)
        rng=np.random.default_rng(seed);values=[]
        for _ in range(B):
            sample=d.iloc[rng.integers(0,len(d),int(len(d)*frac))].reset_index(drop=True)
            values.append((model.predict_proba(sample)[:,1]<.5).mean())
        expected=[np.mean(values),np.std(values,ddof=1),np.percentile(values,2.5),np.percentile(values,97.5)]
        np.testing.assert_array_equal([actual[k] for k in ['mean_pct_raw','sd_pct_raw','ci95_low','ci95_high']],expected)

    def test_section_indices_do_not_overflow_with_full_cohort_sized_int16_codes(self):
        n=18648
        note=np.repeat(np.arange(n,dtype=np.int16),3)
        bins=np.tile([0,1,2],n)
        flags=np.zeros((3*n,5));flags[:,0]=np.arange(3*n)%2
        result=perm.aggregate(flags,note,bins,n)
        expected=flags.reshape(n,15)
        np.testing.assert_array_equal(result,expected)

    def test_classifier_import_never_reads_registry_or_annotation_files(self):
        with patch('pandas.read_excel',side_effect=AssertionError('Unexpected import-time data access')):
            module=load('raw_detector_import_test',ROOT/'text_analysis/raw_detector.py')
        self.assertTrue(hasattr(module,'SummarizationDetector'))

    def test_joint_permutations_preserve_within_sentence_patterns_and_note_membership(self):
        rng=np.random.default_rng(71)
        sizes=np.arange(3,27);note=np.repeat(np.arange(len(sizes)),sizes)
        flags=rng.integers(0,2,(len(note),5)).astype(float)
        moved=perm.shuffle(flags,note,np.random.default_rng(3))
        for i in range(len(sizes)):
            before=sorted(map(tuple,flags[note==i]));after=sorted(map(tuple,moved[note==i]))
            self.assertEqual(before,after)
        self.assertFalse(np.array_equal(flags,moved))

    def test_aggregation_matches_independent_note_section_loops(self):
        rng=np.random.default_rng(92);sizes=np.arange(3,18)
        note=np.repeat(np.arange(len(sizes)),sizes)
        bins=np.concatenate([np.minimum(((np.arange(n)+.5)/n*3).astype(int),2) for n in sizes])
        flags=rng.integers(0,2,(len(note),5)).astype(float)
        expected=np.array([[int(flags[(note==i)&(bins==b),t].max()) for b in range(3) for t in range(5)] for i in range(len(sizes))])
        np.testing.assert_array_equal(perm.aggregate(flags,note,bins,len(sizes)),expected)
        moved=perm.shuffle(flags,note,rng)
        for i in range(len(sizes)):
            np.testing.assert_array_equal(flags[note==i].sum(axis=0),moved[note==i].sum(axis=0))

    def test_statistics_match_original_model_function(self):
        rng=np.random.default_rng(2026);sizes=np.full(1700,6)
        note=np.repeat(np.arange(len(sizes)),sizes);bins=np.tile([0,0,1,1,2,2],len(sizes))
        state=dict(note=note,bins=bins,age=rng.integers(1,6,len(sizes)),male=rng.integers(0,2,len(sizes)),flags=rng.binomial(1,.18,(len(note),5)))
        with threadpool_limits(limits=1):stat,coef=perm.statistics(state,state['flags'])
        source=(ROOT/'text_analysis/15_sentence_robustness.py').read_text(encoding='utf-8')
        fn=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='fit_age_ovr_logit')
        sys.path.insert(0,str(ROOT/'text_analysis'))
        from inference_checks import require_valid_logit
        env=dict(np=np,pd=pd,sm=sm,AGE_ORDER=range(1,6),require_valid_logit=require_valid_logit,safe_log_or=lambda x:np.log(x),get_sig_star=lambda x:'')
        exec(compile(ast.Module(body=[fn],type_ignores=[]),'original_age_function','exec'),env)
        names=[f'Section {b+1} {t}' for b in range(3) for t in perm.THEMES]
        frame=pd.DataFrame(perm.aggregate(state['flags'],note,bins,len(sizes)),columns=names)
        frame['AGE2']=state['age'];frame['SEX']=np.where(state['male']==1,1,2)
        with threadpool_limits(limits=1):original=env['fit_age_ovr_logit'](frame,names)
        selected=original[original.Feature.isin(['Section '+str(b)+' Love and Gratitude' for b in range(1,4)])]
        np.testing.assert_allclose(coef,selected.Coefficient.to_numpy().reshape(5,3),atol=1e-10)
        np.testing.assert_allclose(stat[::2],np.ptp(coef,axis=1))
        np.testing.assert_allclose(stat[1::2],abs(coef[:,2]-coef[:,0]))

    def test_primary_fdr_families_preserve_original_fits(self):
        current=load('current_heatmap',ROOT/'figures/fig05_06_association_heatmaps.py')
        original=load('original_heatmap',ROOT/'reference/originals/Figure Codes/figure5-6a_theme_and_sentiment_heatmaps.py')
        rng=np.random.default_rng(820)
        meta=pd.DataFrame({'SEX':rng.choice([1,2],1200),'AGE2':rng.choice(range(1,6),1200)})
        for n,counts in [(15,(75,15)),(45,(225,45))]:
            names=[f'Section {i//(n//3)+1} Feature{i}' for i in range(n)]
            x=pd.DataFrame(rng.binomial(1,.3,(1200,n)),columns=names,dtype=float)
            with threadpool_limits(limits=1):
                old=original.fit_demographic_models(meta,x,names);new=current.fit_demographic_models(meta,x,names)
            np.testing.assert_allclose(new.Coefficient,old.Coefficient)
            for sex,count in zip([False,True],counts):
                rows=new.Demographic.eq('Gender (Male)').eq(sex)
                self.assertEqual(rows.sum(),count)
                np.testing.assert_allclose(new.loc[rows,'p-value FDR'],multipletests(old.loc[rows,'p-value'],method='fdr_bh')[1])

if __name__=='__main__':unittest.main(verbosity=2)
