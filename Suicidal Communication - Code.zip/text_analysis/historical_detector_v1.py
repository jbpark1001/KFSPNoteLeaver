"""Historical detector definitions only; extracted without executing notebook I/O.
Source: Summarized and Raw Classification.py, detector version 1.
"""
import pandas as pd
import re
import numpy as np
import pandas as pd
from dataclasses import dataclass
from typing import List, Dict, Tuple, Optional
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.linear_model import LogisticRegression
from sklearn.calibration import CalibratedClassifierCV
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import FunctionTransformer, StandardScaler
from scipy import sparse
KOREAN_RE = re.compile('[가-힣]')
QUOTE_RE = re.compile('[\\"“”‘’\'＂]')
DATE_RE = re.compile('(?:19|20)\\d{2}\\s*[./-]\\s*\\d{1,2}\\s*[./-]\\s*\\d{1,2}')
TIME_RE = re.compile('(\\d{1,2}\\s*시(\\s*\\d{1,2}\\s*분)?)')
LEADING_DATE_RE = re.compile('^\\s*(?:19|20)\\d{2}\\s*(?:[.\\-\\/]|년)\\s*\\d{1,2}\\s*(?:[.\\-\\/]|월)?\\s*\\d{1,2}\\s*(?:일|\\.)?')
POLICE_TERMS = ['경찰', '수사', '조사', '진술', '보고', '기재', '확인', '확인됨', '확인됐다', '파악', '파악됐다', '판단', '판단된다', '추정', '추정된다', '발견', '발견되', '현장', '사건', '사망자', '고인', '작성', '담당', '기록', '인용', '문구', '부검', '감식', '목격자', '변사자', '시신', '유류품']
REPORTED_SPEECH_PATTERNS = ['라고\\s*(말|전|진술|하였다|했다)', '이라며\\s*(말|했다|전했다)', '라는\\s*내용', '라는\\s*(메시지|문자)']
FORMAL_MEDIA_PASSIVE = ['된 것으로', '것으로 보', '것으로 추정', '보인다', '파악됐다', '확인됐다', '으로 보임', '으로 판단된다', '하였다', '했다', '한 바 있다']
FIRST_PERSON = ['나', '내', '난', '나는', '내가', '저', '전', '제', '저는', '제가', '우리', '우린']
SECOND_PERSON_KIN = ['너', '당신', '엄마', '아빠', '아들', '딸', '오빠', '언니', '형', '누나', '할머니', '할아버지', '친구', '여보', '아이들', '애들', '사랑', '사랑해', '미안', '죄송', '용서', '보고싶', '보고 싶', '울지말', '고맙']
DIRECT_ADDR_TOKENS = ['엄마', '아빠', '여보', '형', '언니', '오빠', '누나', '아이들', '애들', '딸', '아들']
FOUND_WILL_RE = re.compile('유서\\s*(?:가|를|은|이)?\\s*(?:발견|확인)[^.,\\n)]{0,12}(?:됨|됐다|되었|되다)')
PAREN_ENUM_RE = re.compile('(?:^|[,，]\\s*)[^,()]{1,20}\\([^()]{1,120}\\)')
NUMBERED_ENUM_RE = re.compile('(?:(?<=\\s)|^)\\d{1,2}\\s*[.)](?=\\s|[^0-9])')
ANGLE_HEADER_RE = re.compile('^\\s*<[^>]{1,40}>\\s*')
REDACTION_RE = re.compile('(\\(\\*{2,}\\)|\\*{2,}|○○|△△|◇◇|□□|ＸＸ|XX|xx)')
PAGE_TOKEN_RE = re.compile('\\d+\\s*(장|쪽|페이지)')
SUMMARIZER_PHRASES = ['와 같은 내용의 유서', '같은 내용의 유서', '유서 내용은', '유서에는', '유서 내용(']
CONTAINER_TERMS = ['수첩', '메모장', '메모지', '가방', '주머니', '노트', '메모']
ADMIN_VERBS = ['신고', '부탁', '전달', '안내', '수거', '보관', '확보', '인계', '판매', '팔기', '정리', '처분', '회수', '화장', '수리', '태워']
MSG_TOKENS = ['문자메시지', '메시지', '문자', '카카오톡', '카톡', '메일', '이메일', 'email', 'e-mail']
POLICE_INSTR_RE = re.compile('경찰(?:서)?(?:에|에게)?\\s*신고\\s*(?:하|해)(?:세요|시오|십시오|셔요|줘|주(?:세|십)요|라)?')
SENT_SPLIT_RE = re.compile('[.!?…]+|\\n')

def normalize_quotes(s: str) -> str:
    return s.replace('“', '"').replace('”', '"').replace('‘', "'").replace('’', "'").replace('＂', '"')

def tfidf_clean(s: str) -> str:
    s = re.sub('\\*+', ' ', s)
    s = re.sub('\\s{2,}', ' ', s)
    return s

def hangul_ratio(s: str) -> float:
    if not s:
        return 0.0
    total = len(s)
    if total == 0:
        return 0.0
    return len(KOREAN_RE.findall(s)) / total

def count_matches(s: str, patterns: List[str]) -> int:
    return sum((1 for p in patterns if re.search(p, s)))

def count_list_tokens(s: str, vocab: List[str]) -> int:
    return sum((s.count(w) for w in vocab))

def declarative_da_ratio(s: str) -> float:
    toks = [t.strip() for t in SENT_SPLIT_RE.split(s) if t and t.strip()]
    if not toks:
        return 0.0
    ends = sum((1 for t in toks if re.search('(다|니다)$', t)))
    return ends / len(toks)

@dataclass
class RuleSignals:
    police_terms: int
    reported_speech: int
    formal_passive: int
    quote_count: int
    date_count: int
    time_count: int
    first_person: int
    second_kin: int
    hangul_ratio: float
    length: int
    leading_date: int
    found_will: int
    parenthetical_enum_count: int
    summarizer_phrases_count: int
    yuseo_count: int
    numbered_enum_count: int
    angle_header: int
    redaction_count: int
    page_token_count: int
    container_count: int
    admin_verbs_count: int
    msg_token_count: int
    da_ratio: float
    direct_addr_count: int
    police_instruction: int

def extract_rule_signals(text: str) -> RuleSignals:
    if text is None:
        text = ''
    s = normalize_quotes(text)
    return RuleSignals(police_terms=count_list_tokens(s, POLICE_TERMS), reported_speech=count_matches(s, REPORTED_SPEECH_PATTERNS), formal_passive=count_list_tokens(s, FORMAL_MEDIA_PASSIVE), quote_count=len(QUOTE_RE.findall(s)), date_count=len(DATE_RE.findall(s)), time_count=len(TIME_RE.findall(s)), first_person=count_list_tokens(s, FIRST_PERSON), second_kin=count_list_tokens(s, SECOND_PERSON_KIN), hangul_ratio=hangul_ratio(s), length=len(s.strip()), leading_date=1 if LEADING_DATE_RE.search(s) else 0, found_will=1 if FOUND_WILL_RE.search(s) else 0, parenthetical_enum_count=len(PAREN_ENUM_RE.findall(s)), summarizer_phrases_count=count_list_tokens(s, SUMMARIZER_PHRASES), yuseo_count=s.count('유서'), numbered_enum_count=len(NUMBERED_ENUM_RE.findall(s)), angle_header=1 if ANGLE_HEADER_RE.search(s) else 0, redaction_count=len(REDACTION_RE.findall(s)), page_token_count=len(PAGE_TOKEN_RE.findall(s)), container_count=count_list_tokens(s, CONTAINER_TERMS), admin_verbs_count=count_list_tokens(s, ADMIN_VERBS), msg_token_count=count_list_tokens(s, MSG_TOKENS), da_ratio=declarative_da_ratio(s), direct_addr_count=count_list_tokens(s, DIRECT_ADDR_TOKENS), police_instruction=1 if POLICE_INSTR_RE.search(s) else 0)

def has_investigator_ctx(sig: RuleSignals) -> bool:
    if sig.yuseo_count >= 1 or sig.angle_header == 1 or sig.found_will == 1 or (sig.leading_date == 1):
        return True
    if sig.page_token_count >= 1 or sig.numbered_enum_count >= 3 or sig.summarizer_phrases_count >= 1:
        return True
    if sig.police_terms >= 1 and sig.police_instruction == 0:
        return True
    if sig.msg_token_count >= 1 and sig.reported_speech >= 1:
        return True
    return False

def lf_found_will(sig: RuleSignals) -> int:
    return 1 if sig.found_will >= 1 else -1

def lf_parenthetical_enum(sig: RuleSignals) -> int:
    return 1 if sig.yuseo_count >= 1 and sig.parenthetical_enum_count >= 2 else -1

def lf_summarizer_phrase(sig: RuleSignals) -> int:
    return 1 if sig.summarizer_phrases_count >= 1 else -1

def lf_inventory_meta(sig: RuleSignals) -> int:
    cond1 = sig.angle_header == 1
    cond2 = sig.yuseo_count >= 1 and sig.page_token_count >= 1
    cond3 = sig.yuseo_count >= 1 and sig.container_count >= 1 and (sig.numbered_enum_count >= 1)
    return 1 if cond1 or cond2 or cond3 else -1

def lf_numbered_will(sig: RuleSignals) -> int:
    return 1 if sig.yuseo_count >= 1 and sig.numbered_enum_count >= 3 else -1

def lf_redaction(sig: RuleSignals) -> int:
    return 1 if sig.redaction_count >= 1 and sig.yuseo_count >= 1 else -1

def lf_message_container(sig: RuleSignals) -> int:
    return 1 if sig.msg_token_count >= 1 and sig.reported_speech >= 1 else -1

def lf_leading_date_summary(sig: RuleSignals) -> int:
    return 1 if sig.leading_date == 1 and has_investigator_ctx(sig) else -1

def lf_police_narrative(sig: RuleSignals) -> int:
    score = 0
    score += sig.police_terms >= 2 and sig.police_instruction == 0
    score += sig.reported_speech >= 1
    score += sig.date_count + sig.time_count >= 1
    score += sig.formal_passive >= 1
    return 1 if score >= 2 else -1

def lf_quotes_reported(sig: RuleSignals) -> int:
    return 1 if sig.quote_count >= 2 and sig.reported_speech >= 1 else -1

def lf_formal_passive(sig: RuleSignals) -> int:
    return 1 if sig.formal_passive >= 2 and has_investigator_ctx(sig) else -1

def lf_raw_admin_direct(sig: RuleSignals) -> int:
    no_ctx = not has_investigator_ctx(sig)
    has_admin = sig.admin_verbs_count >= 2
    has_direct = sig.direct_addr_count >= 1
    firstp = sig.first_person >= 1
    not_listy = sig.numbered_enum_count <= 1 and sig.parenthetical_enum_count <= 1
    return 0 if no_ctx and has_admin and has_direct and firstp and not_listy else -1

def lf_diary_raw(sig: RuleSignals) -> int:
    no_ctx = not has_investigator_ctx(sig)
    diaryish = sig.da_ratio >= 0.6
    rich_affect = sig.first_person >= 2 and sig.second_kin >= 1
    not_listy = sig.numbered_enum_count <= 1 and sig.parenthetical_enum_count <= 1
    return 0 if no_ctx and diaryish and rich_affect and not_listy else -1

def lf_strong_raw_monologue(sig: RuleSignals) -> int:
    no_ctx = not has_investigator_ctx(sig)
    affect_heavy = sig.first_person >= 2 and sig.second_kin >= 2
    not_listy = sig.numbered_enum_count <= 1 and sig.parenthetical_enum_count <= 1
    return 0 if affect_heavy and no_ctx and not_listy else -1

def lf_firstperson_affect(sig: RuleSignals) -> int:
    if sig.first_person >= 1 and sig.second_kin >= 1 and (not has_investigator_ctx(sig)):
        return 0
    return -1

def lf_length_guard(sig: RuleSignals) -> int:
    if sig.length <= 15 and sig.first_person >= 1:
        return 0
    return -1

def lf_korean_ratio(sig: RuleSignals) -> int:
    return -1
LABELING_FUNCTIONS = [lf_leading_date_summary, lf_found_will, lf_parenthetical_enum, lf_summarizer_phrase, lf_inventory_meta, lf_numbered_will, lf_redaction, lf_message_container, lf_police_narrative, lf_quotes_reported, lf_formal_passive, lf_raw_admin_direct, lf_diary_raw, lf_strong_raw_monologue, lf_firstperson_affect, lf_length_guard, lf_korean_ratio]

def apply_weak_labels(sig: RuleSignals) -> Tuple[int, float, Dict[str, int]]:
    votes, per_rule = ([], {})
    for f in LABELING_FUNCTIONS:
        v = f(sig)
        per_rule[f.__name__] = v
        if v != -1:
            votes.append(v)
    if not votes:
        return (-1, 0.0, per_rule)
    ones = sum((v == 1 for v in votes))
    zeros = sum((v == 0 for v in votes))
    if ones == zeros:
        return (-1, 0.0, per_rule)
    label = 1 if ones > zeros else 0
    conf = abs(ones - zeros) / len(votes)
    return (label, conf, per_rule)

class SignalExtractor(BaseEstimator, TransformerMixin):
    """Extract numeric features from text. Accepts DataFrame/Series/array-like.
       Set `use_length_feature=False` to drop raw length from the model inputs."""

    def __init__(self, text_col: str='text', use_length_feature: bool=False):
        self.text_col = text_col
        self.use_length_feature = use_length_feature

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        if isinstance(X, pd.DataFrame):
            texts = X[self.text_col].fillna('').astype(str).tolist()
        elif isinstance(X, pd.Series):
            texts = X.fillna('').astype(str).tolist()
        else:
            arr = np.asarray(X)
            if arr.ndim == 2 and arr.shape[1] == 1:
                texts = pd.Series(arr[:, 0]).fillna('').astype(str).tolist()
            else:
                texts = pd.Series(arr).fillna('').astype(str).tolist()
        rows = []
        for txt in texts:
            s = extract_rule_signals(txt)
            feats = [s.police_terms, s.reported_speech, s.formal_passive, s.quote_count, s.date_count, s.time_count, s.first_person, s.second_kin, s.hangul_ratio, s.leading_date, s.found_will, s.parenthetical_enum_count, s.summarizer_phrases_count, s.yuseo_count, s.numbered_enum_count, s.angle_header, s.redaction_count, s.page_token_count, s.container_count, s.admin_verbs_count, s.msg_token_count, s.da_ratio, s.direct_addr_count, s.police_instruction]
            if self.use_length_feature:
                feats.insert(9, s.length)
            rows.append(feats)
        return np.array(rows)

def select_col(X, col: str):
    if isinstance(X, pd.DataFrame):
        return X[col]
    if isinstance(X, dict):
        return X[col]
    return X

def to_1d(x):
    return np.asarray(x).ravel()

def to_csr(X):
    return sparse.csr_matrix(X)

class SummarizationDetector:
    """
    Builds weak labels, trains a (optionally calibrated) classifier on
    TF-IDF char n-grams + numeric signals, and exposes predict_proba and explanations.

    Set `use_length_feature=False` (default here) to make the model more length-invariant.
    """

    def __init__(self, text_col: str='text', random_state: int=42, min_rule_conf: float=0.34, lr_solver: str='saga', lr_penalty: str='l2', lr_C: float=0.5, lr_max_iter: int=5000, lr_tol: float=0.001, calibrate_default: bool=True, use_length_feature: bool=False):
        self.text_col = text_col
        self.random_state = random_state
        self.min_rule_conf = min_rule_conf
        self.pipe = None
        self.label_map_ = {0: 'raw', 1: 'summarized'}
        self.lr_solver = lr_solver
        self.lr_penalty = lr_penalty
        self.lr_C = lr_C
        self.lr_max_iter = lr_max_iter
        self.lr_tol = lr_tol
        self.calibrate_default = calibrate_default
        self.use_length_feature = use_length_feature

    def _build_pipeline(self, calibrated: bool, cv: Optional[int]=None):
        text_branch = Pipeline([('select', FunctionTransformer(select_col, validate=False, kw_args={'col': self.text_col})), ('to1d', FunctionTransformer(to_1d, validate=False)), ('tfidf', TfidfVectorizer(analyzer='char', ngram_range=(3, 5), min_df=2, max_features=200000, preprocessor=tfidf_clean))])
        signals_branch = Pipeline([('select', FunctionTransformer(select_col, validate=False, kw_args={'col': self.text_col})), ('signals', SignalExtractor(text_col=self.text_col, use_length_feature=self.use_length_feature)), ('scale', StandardScaler(with_mean=False)), ('to_csr', FunctionTransformer(to_csr, validate=False))])
        features = FeatureUnion([('text', text_branch), ('signals', signals_branch)])
        base = LogisticRegression(solver=self.lr_solver, penalty=self.lr_penalty, C=self.lr_C, max_iter=self.lr_max_iter, tol=self.lr_tol, class_weight='balanced', random_state=self.random_state)
        clf = CalibratedClassifierCV(base, cv=cv, method='sigmoid') if calibrated else base
        self.pipe = Pipeline([('features', features), ('clf', clf)])

    def _weak_label_dataframe(self, df: pd.DataFrame) -> pd.DataFrame:
        recs = []
        for i, txt in enumerate(df[self.text_col].fillna('')):
            sig = extract_rule_signals(txt)
            y, conf, per_rule = apply_weak_labels(sig)
            recs.append({'idx': i, 'weak_label': y, 'rule_conf': conf, 'signals': sig, **{f'rule_{k}': v for k, v in per_rule.items()}})
        w = pd.DataFrame(recs)
        keep = (w['weak_label'] != -1) & (w['rule_conf'] >= self.min_rule_conf)
        return w.loc[keep].reset_index(drop=True)

    def fit(self, df: pd.DataFrame):
        if self.text_col not in df.columns:
            raise KeyError(f"Column '{self.text_col}' not found in DataFrame.")
        df = df.reset_index(drop=True)
        wd = self._weak_label_dataframe(df)
        n = len(wd)
        if n < 50:
            print(f'[WARN] Only {n} confident weak labels; consider lowering min_rule_conf or adding a few gold labels.')
        if n == 0:
            raise ValueError('No confident weak labels to train on. Adjust rules or min_rule_conf.')
        X = df.iloc[wd['idx'].to_numpy()][[self.text_col]].reset_index(drop=True)
        y = wd['weak_label'].values
        classes, counts = np.unique(y, return_counts=True)
        min_class_count = counts.min()
        n_classes = len(classes)
        if self.calibrate_default and min_class_count >= 2:
            cv = int(min(3, min_class_count))
            calibrated = True
        else:
            if self.calibrate_default and min_class_count < 2:
                print('[Info] Skipping probability calibration (too few samples per class).')
            calibrated = False
            cv = None
        self._build_pipeline(calibrated=calibrated, cv=cv)
        self.pipe.fit(X, y)
        if n >= n_classes * 2:
            test_size_int = max(int(np.ceil(0.2 * n)), n_classes)
            test_size_int = min(test_size_int, n - 1)
            try:
                Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=test_size_int, random_state=self.random_state, stratify=y)
                acc = (self.pipe.predict(Xte) == yte).mean()
                print(f'[Info] Sanity accuracy vs. weak labels: {acc:.3f} (interpret cautiously)')
            except ValueError as e:
                print(f'[Info] Skipping sanity split: {e}')
        else:
            print('[Info] Skipping sanity split; too few weak labels for a stratified holdout.')
        self._weak_df_ = wd
        return self

    def predict_proba(self, df: pd.DataFrame) -> np.ndarray:
        if self.pipe is None:
            raise RuntimeError('Call fit() first.')
        pm = self.pipe.predict_proba(df[[self.text_col]])[:, 1]
        rule_p = []
        ctxless_flags = []
        for txt in df[self.text_col].fillna(''):
            sig = extract_rule_signals(txt)
            y, conf, _ = apply_weak_labels(sig)
            if y == -1:
                rp = 0.5
            elif y == 1:
                rp = 0.5 + 0.5 * conf
            else:
                rp = 0.5 - 0.5 * conf
            rule_p.append(rp)
            ctxless_flags.append(not has_investigator_ctx(sig))
        rule_p = np.array(rule_p)
        ctxless_flags = np.array(ctxless_flags, dtype=bool)
        blended = 0.7 * pm + 0.3 * rule_p
        blended[ctxless_flags] = 0.35 * pm[ctxless_flags] + 0.65 * rule_p[ctxless_flags]
        return np.vstack([1 - blended, blended]).T

    def predict(self, df: pd.DataFrame, threshold: float=0.5) -> np.ndarray:
        proba = self.predict_proba(df)[:, 1]
        return (proba >= threshold).astype(int)

    def score_dataframe(self, df: pd.DataFrame, threshold: float=0.5) -> pd.DataFrame:
        proba = self.predict_proba(df)[:, 1]
        yhat = (proba >= threshold).astype(int)
        rules_fired = []
        signals_list = []
        for txt in df[self.text_col].fillna(''):
            sig = extract_rule_signals(txt)
            _, _, per_rule = apply_weak_labels(sig)
            fired = [k for k, v in per_rule.items() if v in (0, 1)]
            rules_fired.append(', '.join(fired))
            signals_list.append(sig.__dict__)
        out = df.copy()
        out['p_summarized'] = proba
        out['pred_label'] = np.where(yhat == 1, 'summarized', 'raw')
        out['rule_signals'] = signals_list
        out['rules_fired'] = rules_fired
        return out

    def propose_for_review(self, df: pd.DataFrame, k: int=100, low: float=0.4, high: float=0.6) -> pd.DataFrame:
        proba = self.predict_proba(df)[:, 1]
        mask = (proba > low) & (proba < high)
        cand = df.loc[mask].copy()
        cand['p_summarized'] = proba[mask]
        return cand.iloc[np.argsort(np.abs(cand['p_summarized'] - 0.5))[:k]]
