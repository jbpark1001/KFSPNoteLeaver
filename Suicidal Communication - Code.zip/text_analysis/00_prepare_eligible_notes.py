"""Rebuild the eligible text workbook from an authoritative inclusion manifest.

The 582 unavailable/multilingual exclusions cannot be recovered from a count.
Supply an ordered inclusion list tied to the exact source hash. This stage
does not guess a language filter or discard duplicates to force N=37,462.
"""
from pathlib import Path
import sys,json,hashlib,argparse
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import input_path,ROOT

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,required=True)
    args=parser.parse_args()
    spec=json.loads(args.manifest.read_text(encoding='utf-8'))
    source=input_path('demographic_source')
    digest=hashlib.sha256(source.read_bytes()).hexdigest()
    if spec['source_sha256']!=digest:raise ValueError('Inclusion manifest belongs to a different source version')
    d=pd.read_pickle(source);ids=spec['ordered_included_registry_ids']
    assert d.index.is_unique and len(ids)==len(set(ids))==37462
    assert set(ids).issubset(d.index) and d.loc[ids,'NOTE_EX'].eq(1).all()
    excluded=d.index[d.NOTE_EX.eq(1)].difference(ids)
    assert len(excluded)==582
    reasons=spec['excluded_registry_id_reasons']
    assert set(map(str,excluded))==set(reasons)
    assert all(isinstance(v,str) and v.strip() for v in reasons.values())
    selected=d.loc[ids].copy()
    assert selected.NOTE_CONTENTDTL.notna().all() and selected.NOTE_CONTENTDTL.astype(str).str.strip().ne('').all()
    selected.insert(0,'registry_source_id',selected.index)
    selected=selected.reset_index(drop=True)
    path=ROOT/'derived/eligible_notes.xlsx';path.parent.mkdir(parents=True,exist_ok=True)
    selected.to_excel(path,index=False)
    print('Created',path,'with',len(selected),'records. Configure eligible_notes explicitly to use this rebuild.')

if __name__=='__main__':main()
