"""Reconstructed from the Supplementary Methods supplied on 2026-11-09.

This is newly written replication code, not the recovered original script.
Each permutation moves the complete five-theme sentence vector jointly.
No NLP model, label, cohort, outcome or section size changes under the null.
"""
from pathlib import Path
import sys, argparse, json, hashlib, os
from concurrent.futures import ThreadPoolExecutor
import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
from threadpoolctl import threadpool_limits
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from project import input_path, output_path

THEMES = ['Sorry and Shame', 'Love and Gratitude', 'Burden', 'Despair', 'Post-mortem Affairs']
STATE = None

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024*1024), b''): h.update(block)
    return h.hexdigest()

def prepare():
    cols = ['note_id','sentence_index','n_sent','rel_pos','third_bin'] + ['theme_'+t for t in THEMES]
    s = pd.read_csv(input_path('sentence_flags'), usecols=cols).sort_values(['note_id','sentence_index'])
    m = pd.read_excel(input_path('section_annotations'), usecols=['SEX','AGE2','pred_label'])
    assert m.index.is_unique and not s.duplicated(['note_id','sentence_index']).any()
    g = s.groupby('note_id', sort=True)
    sizes = g.size()
    assert g.n_sent.nunique().eq(1).all() and sizes.eq(g.n_sent.first()).all()
    assert g.sentence_index.min().eq(1).all() and g.sentence_index.max().eq(sizes).all()
    assert set(s.note_id).issubset(m.index)
    assert np.allclose(s.rel_pos, (s.sentence_index-.5)/s.n_sent, atol=1e-12)
    assert np.array_equal(s.third_bin, np.minimum(np.floor(s.rel_pos*3).astype(int)+1,3))
    ids = sizes.index[(sizes>=3) & m.loc[sizes.index,'SEX'].isin([1,2]).to_numpy()
                     & m.loc[sizes.index,'AGE2'].isin(range(1,6)).to_numpy()
                     & m.loc[sizes.index,'pred_label'].eq('raw').to_numpy()]
    assert len(ids)==18648, f'Sentence cohort mismatch: {len(ids)}; expected 18,648. Reconcile sources.'
    s = s[s.note_id.isin(ids)].copy()
    note = pd.Categorical(s.note_id, categories=ids).codes.astype(np.int64)
    flags = s[['theme_'+t for t in THEMES]].to_numpy(dtype=float)
    assert np.isin(flags, [0,1]).all()
    bins = s.third_bin.to_numpy(dtype=int)-1
    sizes = s.groupby('note_id',sort=True).size().to_numpy()
    assert np.array_equal(np.unique(note),np.arange(len(ids)))
    return dict(flags=flags, note=note, bins=bins, sizes=sizes,
                age=m.loc[ids,'AGE2'].to_numpy(), male=m.loc[ids,'SEX'].eq(1).to_numpy(dtype=float))

def aggregate(flags, note, bins, n_notes):
    values=np.zeros((n_notes*3,5),dtype=float)
    # pandas categorical codes can be int16: multiplication must happen only
    # after promotion, otherwise >10,923 note groups overflow section indices.
    section_index=np.asarray(note,dtype=np.int64)*3+np.asarray(bins,dtype=np.int64)
    np.maximum.at(values,section_index,flags)
    return values.reshape(n_notes,15)

def shuffle(flags, note, rng):
    # Independent continuous random keys induce a uniform order in each note.
    # Lexicographic note grouping retains the original block/section exposures.
    order=np.lexsort((rng.random(len(note)),note))
    assert np.array_equal(note[order],note)
    return flags[order]

def statistics(state, flags):
    x=aggregate(flags,state['note'],state['bins'],len(state['age']))
    x=np.column_stack([np.ones(len(x)),x,state['male']])
    if np.linalg.matrix_rank(x)!=x.shape[1]: raise ValueError('Singular permutation design')
    stats=[]; coefficients=[]
    for age in range(1,6):
        fit=sm.Logit(state['age']==age,x).fit(disp=False,maxiter=200)
        if not fit.mle_retvals['converged'] or not np.isfinite(fit.params).all() or not np.isfinite(fit.bse).all():
            raise ValueError('Invalid permutation fit; no p-value will be issued')
        b=np.asarray(fit.params)[[2,7,12]] # intercept + section-major Love/Gratitude
        coefficients.append(b)
        stats.extend([np.ptp(b),abs(b[2]-b[0])])
    return np.asarray(stats),np.asarray(coefficients)

def initialize(state):
    global STATE
    STATE=state

def one(task):
    index,seed=task
    rng=np.random.default_rng(np.random.SeedSequence([seed,index]))
    result,_=statistics(STATE,shuffle(STATE['flags'],STATE['note'],rng))
    return {'permutation':index,'statistics':result.tolist()}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--n-perm',type=int,default=4999)
    parser.add_argument('--seed',type=int,default=20261109,help='Explicit new seed; original seed was not supplied')
    parser.add_argument('--jobs',type=int,default=1)
    args=parser.parse_args()
    if args.n_perm<1 or args.jobs<1 or args.seed<0: parser.error('n-perm/jobs must be positive; seed nonnegative')
    state=prepare()
    with threadpool_limits(limits=1): observed,coef=statistics(state,state['flags'])
    spec={'implementation':'new reconstruction from supplied Supplementary Methods',
          'n':len(state['age']),'sentences':len(state['note']),'n_perm':args.n_perm,'seed':args.seed,
          'source_hashes':{k:sha(input_path(k)) for k in ['sentence_flags','section_annotations']},
          'script_sha256':sha(__file__), 'model':'age group vs rest ~ all 15 section-theme indicators + male + intercept',
          'null':'joint five-label sentence-order shuffle within note; midpoint thirds; fixed section sizes',
          'tests':'range of three LG coefficients; absolute ending-minus-opening; Holm across 10',
          'original_seed_known':False,'full_permutation_count':args.n_perm==4999}
    base=output_path(f'tables/sentence_order_permutation/B{args.n_perm}_seed{args.seed}/manifest.json').parent
    manifest=base/'manifest.json'
    if manifest.exists() and json.loads(manifest.read_text(encoding='utf-8'))!=spec:
        raise ValueError('Checkpoint specification differs; use a separate output directory')
    manifest.write_text(json.dumps(spec,indent=2),encoding='utf-8')
    checkpoint=base/'permutations.jsonl'; done={}
    if checkpoint.exists():
        for line in checkpoint.read_text(encoding='utf-8').splitlines():
            r=json.loads(line);i=r['permutation']
            if i in done or not 1<=i<=args.n_perm or len(r['statistics'])!=10 or not np.isfinite(r['statistics']).all():
                raise ValueError('Invalid checkpoint')
            done[i]=r['statistics']
    tasks=[(i,args.seed) for i in range(1,args.n_perm+1) if i not in done]
    initialize(state)
    # Threads avoid Windows named-pipe permissions and share read-only inputs.
    with threadpool_limits(limits=1), ThreadPoolExecutor(max_workers=args.jobs) as pool:
        with checkpoint.open('a',encoding='utf-8') as f:
            for r in pool.map(one,tasks,chunksize=1):
                f.write(json.dumps(r)+'\n');f.flush();os.fsync(f.fileno())
                done[r['permutation']]=r['statistics']
                if len(done)%25==0 or len(done)==args.n_perm: print(f'Completed {len(done)}/{args.n_perm}',flush=True)
    null=np.asarray([done[i] for i in range(1,args.n_perm+1)])
    p=(1+(null>=observed).sum(axis=0))/(args.n_perm+1)
    q=multipletests(p,method='holm')[1]
    rows=[]
    for a in range(5):
        for j,test in enumerate(['coefficient_range','absolute_ending_minus_opening']):
            k=2*a+j
            rows.append(dict(age_code=a+1,test=test,n=spec['n'],statistic=observed[k],p_permutation=p[k],p_holm_10=q[k],
                             opening_coefficient=coef[a,0],middle_coefficient=coef[a,1],ending_coefficient=coef[a,2],
                             signed_ending_minus_opening=coef[a,2]-coef[a,0],n_perm=args.n_perm))
    pd.DataFrame(rows).to_csv(base/'results.csv',index=False)
    print('Results:',base/'results.csv',flush=True)

if __name__=='__main__': main()
