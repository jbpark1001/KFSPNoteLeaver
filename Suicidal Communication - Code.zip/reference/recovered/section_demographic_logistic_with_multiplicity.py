"""
Standalone section-based demographic logistic regressions with multiplicity control.

This script preserves the estimand used in the source analysis:

    Age analysis:
        one-vs-rest age-group membership ~ all section-specific features + recorded sex

    Recorded-sex analysis:
        male membership ~ all section-specific features + categorical age group

Theme and sentiment models are fitted separately. Benjamini-Hochberg FDR and
Holm family-wise corrections are applied within each coherent analysis family:

    segmentation scheme x feature domain (theme/sentiment) x demographic analysis

For age analyses, a family contains all five one-vs-rest age-group models. Thus,
for primary thirds, the theme-age family contains 5 age groups x 3 sections x
5 themes = 75 tests, and the sentiment-age family contains 5 x 3 x 15 = 225
tests. Recorded-sex families contain 15 and 45 tests, respectively.

The primary thirds and each sensitivity analysis are kept in separate correction
families. The raw p-values and ordinary 95% confidence intervals are retained;
the FDR-adjusted p-value is the default inferential quantity.
"""

from __future__ import annotations

import argparse
import ast
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests


# -----------------------------------------------------------------------------
# Defaults: these can be overridden from the command line.
# -----------------------------------------------------------------------------

DEFAULT_INPUT_FILE = Path(r"C:\Users\Jae Bin Park\kfsp_sectioned_ver2.xlsx")
DEFAULT_OUTPUT_DIR = Path(r"C:\Users\Jae Bin Park\section_logit_multiplicity_outputs")

AGE_ORDER = [1, 2, 3, 4, 5]
VALID_RECORDED_SEX = [1, 2]
ALPHA = 0.05

# Run the primary specification and the existing sensitivity specifications.
# Each scheme receives its own multiple-testing correction.
DEFAULT_SCHEMES = ["third", "quart", "third5", "shuf_third"]


SECTION_SCHEMES = {
    "third": {
        "tokenized_keyword_cols": [
            "tokenizedkluekeywordsentencetransformer_third_1",
            "tokenizedkluekeywordsentencetransformer_third_2",
            "tokenizedkluekeywordsentencetransformer_third_3",
        ],
        "sentiment_cols": [
            "third_1_sentiment",
            "third_2_sentiment",
            "third_3_sentiment",
        ],
        "section_labels": ["Section 1", "Section 2", "Section 3"],
        "min_sent_col": "third_total_n_sent",
        "min_sentences": 3,
    },
    "quart": {
        "tokenized_keyword_cols": [
            "tokenizedkluekeywordsentencetransformer_quart_1",
            "tokenizedkluekeywordsentencetransformer_quart_2",
            "tokenizedkluekeywordsentencetransformer_quart_3",
            "tokenizedkluekeywordsentencetransformer_quart_4",
        ],
        "sentiment_cols": [
            "quart_1_sentiment",
            "quart_2_sentiment",
            "quart_3_sentiment",
            "quart_4_sentiment",
        ],
        "section_labels": ["Section 1", "Section 2", "Section 3", "Section 4"],
        "min_sent_col": "quart_total_n_sent",
        "min_sentences": 4,
    },
    "third5": {
        "tokenized_keyword_cols": [
            "tokenizedkluekeywordsentencetransformer_third5_1",
            "tokenizedkluekeywordsentencetransformer_third5_2",
            "tokenizedkluekeywordsentencetransformer_third5_3",
        ],
        "sentiment_cols": [
            "third5_1_sentiment",
            "third5_2_sentiment",
            "third5_3_sentiment",
        ],
        "section_labels": ["Section 1", "Section 2", "Section 3"],
        "min_sent_col": "third5_total_n_sent",
        "min_sentences": 5,
    },
    "shuf_third": {
        "tokenized_keyword_cols": [
            "tokenizedkluekeywordsentencetransformer_shuf_third_1",
            "tokenizedkluekeywordsentencetransformer_shuf_third_2",
            "tokenizedkluekeywordsentencetransformer_shuf_third_3",
        ],
        "sentiment_cols": [
            "shuf_third_1_sentiment",
            "shuf_third_2_sentiment",
            "shuf_third_3_sentiment",
        ],
        "section_labels": ["Section 1", "Section 2", "Section 3"],
        "min_sent_col": "shuf_third_total_n_sent",
        "min_sentences": 3,
    },
}


THEME_TOKEN_DICT = {
    "Sorry and Shame": [
        "미안", "죄송", "용서", "잘못", "후회", "죄", "책임", "민폐", "반성"
    ],
    "Love and Gratitude": [
        "사랑", "고맙", "감사", "고생", "수고", "보고싶", "애틋", "소중", "그리"
    ],
    "Burden": [
        "버겁", "부담", "짐", "감당", "힘들", "무겁", "지치", "헷갈"
    ],
    "Despair": [
        "포기", "좌절", "죽", "끝", "아무것", "헛되", "무의미", "잊히", "없어지", "그만두"
    ],
    "Post-mortem Affairs": [
        "부탁", "정리", "남기", "처리", "보험", "은행", "장례", "통장", "유서"
    ],
}


SENTIMENT_LABEL_MAP = {
    "Despair": "절망",
    "Defeat": "패배/자기혐오",
    "Exhaustion": "힘듦/지침",
    "Anxious": "불안/걱정",
    "Disappointment": "안타까움/실망",
    "Anger": "화남/분노",
    "Hatred": "증오/혐오",
    "Resentment": "어이없음",
    "Sadness": "슬픔",
    "Sorrow": "서러움",
    "Gratitude": "고마움",
    "Affection": "흐뭇함(귀여움/예쁨)",
    "Happiness": "행복",
    "Relief": "안심/신뢰",
    "Neutral": "없음",
}


# -----------------------------------------------------------------------------
# Parsing and feature construction
# -----------------------------------------------------------------------------

def parse_listlike(value: Any) -> list[Any]:
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if pd.isna(value):
        return []
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return []
        try:
            parsed = ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return []
        if isinstance(parsed, (list, tuple)):
            return list(parsed)
    return []


def parse_dictlike(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return value
    if pd.isna(value):
        return {"labels": [], "scores": []}
    if isinstance(value, str):
        value = value.strip()
        if not value:
            return {"labels": [], "scores": []}
        try:
            parsed = ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return {"labels": [], "scores": []}
        if isinstance(parsed, dict):
            return parsed
    return {"labels": [], "scores": []}


def extract_tokens(items: Any) -> list[str]:
    tokens: list[str] = []
    for item in parse_listlike(items):
        if isinstance(item, (tuple, list)) and item:
            tokens.append(str(item[0]))
        elif isinstance(item, str):
            tokens.append(item)
    return tokens


def token_list_contains(tokens: Iterable[str], targets: Iterable[str]) -> int:
    return int(any(target in token for token in tokens for target in targets))


def sentiment_entry_contains(entry: Any, korean_label: str) -> int:
    labels = parse_dictlike(entry).get("labels", [])
    if not isinstance(labels, (list, tuple, set)):
        return 0
    return int(korean_label in labels)


def require_columns(df: pd.DataFrame, columns: Iterable[str], context: str) -> None:
    missing = [column for column in columns if column not in df.columns]
    if missing:
        raise KeyError(f"Missing columns for {context}: {missing}")


def filter_for_scheme(
    df: pd.DataFrame,
    scheme_name: str,
    scheme_config: dict[str, Any],
) -> pd.DataFrame:
    min_sent_col = scheme_config["min_sent_col"]
    min_sentences = scheme_config["min_sentences"]
    require_columns(df, [min_sent_col], scheme_name)
    n_sent = pd.to_numeric(df[min_sent_col], errors="coerce").fillna(0)
    return df.loc[n_sent >= min_sentences].copy()


def build_theme_features(
    df: pd.DataFrame,
    scheme_name: str,
    scheme_config: dict[str, Any],
) -> tuple[pd.DataFrame, list[str]]:
    out = df.copy()
    keyword_cols = scheme_config["tokenized_keyword_cols"]
    section_labels = scheme_config["section_labels"]
    require_columns(out, keyword_cols, f"{scheme_name} theme features")

    parsed_tokens = {column: out[column].map(extract_tokens) for column in keyword_cols}
    feature_names: list[str] = []

    for column, section_label in zip(keyword_cols, section_labels):
        for theme, targets in THEME_TOKEN_DICT.items():
            feature = f"{scheme_name} {section_label} {theme}"
            out[feature] = parsed_tokens[column].map(
                lambda tokens, target_terms=targets: token_list_contains(tokens, target_terms)
            )
            feature_names.append(feature)

    return out, feature_names


def build_sentiment_features(
    df: pd.DataFrame,
    scheme_name: str,
    scheme_config: dict[str, Any],
) -> tuple[pd.DataFrame, list[str]]:
    out = df.copy()
    sentiment_cols = scheme_config["sentiment_cols"]
    section_labels = scheme_config["section_labels"]
    require_columns(out, sentiment_cols, f"{scheme_name} sentiment features")

    parsed_entries = {column: out[column].map(parse_dictlike) for column in sentiment_cols}
    feature_names: list[str] = []

    for column, section_label in zip(sentiment_cols, section_labels):
        for sentiment, korean_label in SENTIMENT_LABEL_MAP.items():
            feature = f"{scheme_name} {section_label} {sentiment}"
            out[feature] = parsed_entries[column].map(
                lambda entry, label=korean_label: sentiment_entry_contains(entry, label)
            )
            feature_names.append(feature)

    return out, feature_names


# -----------------------------------------------------------------------------
# Logistic regression helpers
# -----------------------------------------------------------------------------

def empty_result_row(
    feature: str,
    scheme: str,
    domain: str,
    demographic_analysis: str,
    age_group: int | float,
    n_model: int,
    n_events: int,
    status: str,
) -> dict[str, Any]:
    return {
        "scheme": scheme,
        "domain": domain,
        "demographic_analysis": demographic_analysis,
        "age_group": age_group,
        "feature": feature,
        "coefficient": np.nan,
        "odds_ratio": np.nan,
        "ci_lower_95": np.nan,
        "ci_upper_95": np.nan,
        "p_raw": np.nan,
        "n_model": n_model,
        "n_events": n_events,
        "model_status": status,
    }


def fit_logit_feature_block(
    y: pd.Series,
    feature_df: pd.DataFrame,
    covariate_df: pd.DataFrame,
    feature_names: list[str],
    scheme: str,
    domain: str,
    demographic_analysis: str,
    age_group: int | float = np.nan,
    maxiter: int = 300,
) -> pd.DataFrame:
    """Fit one multivariable model and return only section-feature coefficients."""
    X = pd.concat([feature_df[feature_names], covariate_df], axis=1)
    X = X.apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan)
    y = pd.to_numeric(y, errors="coerce")

    complete = ~(X.isna().any(axis=1) | y.isna())
    X = X.loc[complete].copy()
    y = y.loc[complete].astype(int)
    n_model = len(y)
    n_events = int(y.sum())

    if n_model == 0 or y.nunique() < 2:
        status = "not_estimable_no_outcome_variation"
        return pd.DataFrame([
            empty_result_row(
                feature, scheme, domain, demographic_analysis,
                age_group, n_model, n_events, status
            )
            for feature in feature_names
        ])

    estimable_features = [
        feature for feature in feature_names if X[feature].nunique(dropna=True) > 1
    ]
    constant_features = sorted(set(feature_names) - set(estimable_features))

    rows = [
        empty_result_row(
            feature, scheme, domain, demographic_analysis,
            age_group, n_model, n_events, "not_estimable_constant_feature"
        )
        for feature in constant_features
    ]

    if not estimable_features:
        return pd.DataFrame(rows)

    model_columns = estimable_features + list(covariate_df.columns)
    X_model = sm.add_constant(X[model_columns], has_constant="add").astype(float)

    try:
        # HC1 sandwich standard errors reduce dependence on exact variance specification.
        result = sm.Logit(y, X_model).fit(
            disp=False,
            maxiter=maxiter,
            cov_type="HC1",
        )
        conf = result.conf_int()
        converged = bool(result.mle_retvals.get("converged", True))

        for feature in estimable_features:
            coefficient = float(result.params[feature])
            rows.append({
                "scheme": scheme,
                "domain": domain,
                "demographic_analysis": demographic_analysis,
                "age_group": age_group,
                "feature": feature,
                "coefficient": coefficient,
                "odds_ratio": float(np.exp(coefficient)),
                "ci_lower_95": float(np.exp(conf.loc[feature, 0])),
                "ci_upper_95": float(np.exp(conf.loc[feature, 1])),
                # A non-converged fit is retained for diagnosis, but its
                # inferential p-value is excluded from multiplicity control.
                "p_raw": float(result.pvalues[feature]) if converged else np.nan,
                "n_model": n_model,
                "n_events": n_events,
                "model_status": "ok" if converged else "not_converged_no_inference",
            })
    except Exception as exc:
        status = f"model_failed: {type(exc).__name__}: {exc}"
        rows.extend([
            empty_result_row(
                feature, scheme, domain, demographic_analysis,
                age_group, n_model, n_events, status
            )
            for feature in estimable_features
        ])

    return pd.DataFrame(rows)


def fit_age_one_vs_rest(
    df: pd.DataFrame,
    feature_names: list[str],
    scheme: str,
    domain: str,
) -> pd.DataFrame:
    work = df.loc[
        df["AGE2"].isin(AGE_ORDER) & df["SEX"].isin(VALID_RECORDED_SEX)
    ].copy()
    work["sex_male"] = work["SEX"].replace({1: 1, 2: 0}).astype(int)

    outputs = []
    for age_group in AGE_ORDER:
        y = work["AGE2"].eq(age_group).astype(int)
        outputs.append(
            fit_logit_feature_block(
                y=y,
                feature_df=work,
                covariate_df=work[["sex_male"]],
                feature_names=feature_names,
                scheme=scheme,
                domain=domain,
                demographic_analysis="age_one_vs_rest",
                age_group=age_group,
            )
        )
    return pd.concat(outputs, ignore_index=True)


def fit_recorded_sex_controlling_age(
    df: pd.DataFrame,
    feature_names: list[str],
    scheme: str,
    domain: str,
) -> pd.DataFrame:
    work = df.loc[
        df["AGE2"].isin(AGE_ORDER) & df["SEX"].isin(VALID_RECORDED_SEX)
    ].copy()
    y = work["SEX"].eq(1).astype(int)

    age_dummies = pd.get_dummies(
        work["AGE2"],
        prefix="AGE2",
        drop_first=True,
        dtype=int,
    )
    expected_age_covariates = ["AGE2_2", "AGE2_3", "AGE2_4", "AGE2_5"]
    age_dummies = age_dummies.reindex(columns=expected_age_covariates, fill_value=0)

    return fit_logit_feature_block(
        y=y,
        feature_df=work,
        covariate_df=age_dummies,
        feature_names=feature_names,
        scheme=scheme,
        domain=domain,
        demographic_analysis="recorded_sex_male_vs_female",
    )


# -----------------------------------------------------------------------------
# Multiple-testing correction
# -----------------------------------------------------------------------------

def significance_stars(p_value: float) -> str:
    if pd.isna(p_value):
        return ""
    if p_value < 0.001:
        return "***"
    if p_value < 0.01:
        return "**"
    if p_value < 0.05:
        return "*"
    return ""


def add_multiple_testing_corrections(results: pd.DataFrame) -> pd.DataFrame:
    """
    Correct within scheme x domain x demographic analysis.

    All five one-vs-rest age models are one family. Primary and sensitivity
    segmentation schemes are deliberately not pooled into one family.
    """
    out = results.copy()
    out["p_fdr_bh"] = np.nan
    out["reject_fdr_bh"] = False
    out["p_holm"] = np.nan
    out["reject_holm"] = False
    out["correction_family_n"] = 0

    family_cols = ["scheme", "domain", "demographic_analysis"]

    for _, family_index in out.groupby(family_cols, sort=False).groups.items():
        family_index = pd.Index(family_index)
        valid_index = family_index[out.loc[family_index, "p_raw"].notna()]
        m = len(valid_index)
        out.loc[family_index, "correction_family_n"] = m
        if m == 0:
            continue

        raw_p = out.loc[valid_index, "p_raw"].to_numpy(dtype=float)

        reject_fdr, p_fdr, _, _ = multipletests(
            raw_p,
            alpha=ALPHA,
            method="fdr_bh",
        )
        reject_holm, p_holm, _, _ = multipletests(
            raw_p,
            alpha=ALPHA,
            method="holm",
        )

        out.loc[valid_index, "p_fdr_bh"] = p_fdr
        out.loc[valid_index, "reject_fdr_bh"] = reject_fdr
        out.loc[valid_index, "p_holm"] = p_holm
        out.loc[valid_index, "reject_holm"] = reject_holm

    out["sig_fdr_bh"] = out["p_fdr_bh"].map(significance_stars)
    out["sig_holm"] = out["p_holm"].map(significance_stars)
    out["log_odds_ratio"] = out["coefficient"]
    out["annotation_fdr"] = (
        out["log_odds_ratio"].round(2).astype("string").fillna("")
        + out["sig_fdr_bh"]
    )
    return out


def correction_family_summary(results: pd.DataFrame) -> pd.DataFrame:
    family_cols = ["scheme", "domain", "demographic_analysis"]
    return (
        results.groupby(family_cols, dropna=False)
        .agg(
            n_tests=("p_raw", lambda x: int(x.notna().sum())),
            n_raw_p_lt_05=("p_raw", lambda x: int((x < ALPHA).sum())),
            n_fdr_q_lt_05=("reject_fdr_bh", "sum"),
            n_holm_p_lt_05=("reject_holm", "sum"),
            n_model_failures=("model_status", lambda x: int((x != "ok").sum())),
        )
        .reset_index()
    )


# -----------------------------------------------------------------------------
# Analysis runner and output
# -----------------------------------------------------------------------------

def required_input_columns(schemes: Iterable[str]) -> list[str]:
    columns = {"AGE2", "SEX", "pred_label"}
    for scheme_name in schemes:
        config = SECTION_SCHEMES[scheme_name]
        columns.add(config["min_sent_col"])
        columns.update(config["tokenized_keyword_cols"])
        columns.update(config["sentiment_cols"])
    return sorted(columns)


def load_analysis_dataframe(
    input_file: Path,
    schemes: Iterable[str] = DEFAULT_SCHEMES,
) -> pd.DataFrame:
    if not input_file.exists():
        raise FileNotFoundError(f"Input workbook not found: {input_file}")

    usecols = required_input_columns(schemes)
    scored = pd.read_excel(
        input_file,
        sheet_name="Sheet1",
        usecols=lambda column: column in usecols,
    )
    require_columns(scored, usecols, "standalone input workbook")
    require_columns(scored, ["AGE2", "SEX"], "demographic models")

    if "pred_label" in scored.columns:
        scored = scored.loc[scored["pred_label"].eq("raw")].copy()
    else:
        raise KeyError(
            "The workbook must contain `pred_label`; the analysis is restricted "
            "to rows classified as raw notes."
        )

    return scored


def run_scheme_domain(
    raw_df: pd.DataFrame,
    scheme_name: str,
    domain: str,
) -> pd.DataFrame:
    config = SECTION_SCHEMES[scheme_name]
    scheme_df = filter_for_scheme(raw_df, scheme_name, config)

    if domain == "theme":
        model_df, feature_names = build_theme_features(scheme_df, scheme_name, config)
    elif domain == "sentiment":
        model_df, feature_names = build_sentiment_features(scheme_df, scheme_name, config)
    else:
        raise ValueError(f"Unknown domain: {domain}")

    print(
        f"Running {scheme_name} / {domain}: "
        f"N={len(model_df):,}, section features={len(feature_names)}"
    )

    age_results = fit_age_one_vs_rest(
        model_df,
        feature_names,
        scheme=scheme_name,
        domain=domain,
    )
    sex_results = fit_recorded_sex_controlling_age(
        model_df,
        feature_names,
        scheme=scheme_name,
        domain=domain,
    )
    return pd.concat([age_results, sex_results], ignore_index=True)


def save_results(results: pd.DataFrame, output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)

    results.to_csv(
        output_dir / "section_demographic_logit_all_adjusted.csv",
        index=False,
        encoding="utf-8-sig",
    )

    for (domain, analysis), subset in results.groupby(
        ["domain", "demographic_analysis"], sort=False
    ):
        subset.to_csv(
            output_dir / f"section_{domain}_{analysis}_adjusted.csv",
            index=False,
            encoding="utf-8-sig",
        )

    family_summary = correction_family_summary(results)
    family_summary.to_csv(
        output_dir / "multiple_testing_family_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )

    print("\nMultiple-testing families:")
    print(family_summary.to_string(index=False))
    print(f"\nSaved adjusted results to: {output_dir}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run section-based age and recorded-sex logistic models with FDR/Holm correction."
    )
    parser.add_argument(
        "--input",
        type=Path,
        default=DEFAULT_INPUT_FILE,
        help="Input .xlsx containing section features and pred_label.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=DEFAULT_OUTPUT_DIR,
        help="Directory for adjusted CSV results.",
    )
    parser.add_argument(
        "--schemes",
        nargs="+",
        choices=list(SECTION_SCHEMES),
        default=DEFAULT_SCHEMES,
        help="Segmentation schemes to run.",
    )
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    raw_df = load_analysis_dataframe(args.input, schemes=args.schemes)
    print(f"Raw-classified rows loaded: {len(raw_df):,}")

    outputs = []
    for scheme_name in args.schemes:
        for domain in ["theme", "sentiment"]:
            outputs.append(run_scheme_domain(raw_df, scheme_name, domain))

    results = pd.concat(outputs, ignore_index=True)
    results = add_multiple_testing_corrections(results)

    sort_columns = [
        "scheme",
        "domain",
        "demographic_analysis",
        "age_group",
        "feature",
    ]
    results = results.sort_values(sort_columns, na_position="last").reset_index(drop=True)
    save_results(results, args.output_dir)


if __name__ == "__main__":
    main()
