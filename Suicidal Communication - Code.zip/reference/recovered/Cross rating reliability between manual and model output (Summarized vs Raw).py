# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 10:43:07 2026

@author: Jae Bin Park
"""
import pandas as pd

df_manual=pd.read_excel(r'C:\Users\Jae Bin Park\summarizedrawnotes_blind.xlsx')

df_pred=pd.read_excel(r'C:\Users\Jae Bin Park\summarizedrawnotes.xlsx')


# Take first 500 manually labeled notes
df_manual_500 = df_manual.head(1500)

# Merge only those with predictions
df_merged = pd.merge(
    df_manual_500[['NOTE_CONTENTDTL', 'Manual Label']],
    df_pred[['NOTE_CONTENTDTL', 'pred_label']],
    on='NOTE_CONTENTDTL',
    how='inner'
)

# Standardize labels
label_map = {'R': 'raw', 'S': 'summarized'}
df_merged['manual_std'] = df_merged['Manual Label'].map(label_map)


# Compare
df_merged['match'] = df_merged['manual_std'] == df_merged['pred_label']

# Accuracy
accuracy = df_merged['match'].mean()
print(f"Accuracy (first 500 manual): {accuracy:.4f}")

#%%

# -*- coding: utf-8 -*-
"""
Created on Thu Mar 26 10:43:07 2026

@author: Jae Bin Park
"""
import pandas as pd
from sklearn.metrics import confusion_matrix

df_manual = pd.read_excel(r'C:\Users\Jae Bin Park\summarizedrawnotes_blind.xlsx')
df_pred   = pd.read_excel(r'C:\Users\Jae Bin Park\summarizedrawnotes.xlsx')

# Take first 1500 manually labeled notes
df_manual_1500 = df_manual.head(1500)

# Merge only those with predictions
df_merged = pd.merge(
    df_manual_1500[['NOTE_CONTENTDTL', 'Manual Label']],
    df_pred[['NOTE_CONTENTDTL', 'pred_label']],
    on='NOTE_CONTENTDTL',
    how='inner'
)

# Standardize labels
label_map = {'R': 'raw', 'S': 'summarized'}
df_merged['manual_std'] = df_merged['Manual Label'].map(label_map)

# Drop rows with unmapped / missing labels just in case
df_merged = df_merged.dropna(subset=['manual_std', 'pred_label']).copy()

# Overall accuracy
df_merged['match'] = df_merged['manual_std'] == df_merged['pred_label']
accuracy = df_merged['match'].mean()

# --- Option 1: treat RAW as the positive class ---
# Positive = raw
y_true_raw = (df_merged['manual_std'] == 'raw').astype(int)
y_pred_raw = (df_merged['pred_label'] == 'raw').astype(int)

tn, fp, fn, tp = confusion_matrix(y_true_raw, y_pred_raw).ravel()

sensitivity_raw = tp / (tp + fn) if (tp + fn) > 0 else float('nan')   # recall for raw
specificity_raw = tn / (tn + fp) if (tn + fp) > 0 else float('nan')   # correctly rejects summarized

print(f"N matched after merge: {len(df_merged)}")
print(f"Accuracy: {accuracy:.4f}")
print(f"Sensitivity (RAW as positive): {sensitivity_raw:.4f}")
print(f"Specificity (RAW as positive): {specificity_raw:.4f}")

print("\nConfusion matrix (RAW positive):")
print(f"TP (manual raw, predicted raw): {tp}")
print(f"FN (manual raw, predicted summarized): {fn}")
print(f"FP (manual summarized, predicted raw): {fp}")
print(f"TN (manual summarized, predicted summarized): {tn}")

# --- Option 2: also report SUMMARIZED as the positive class ---
# Positive = summarized
y_true_sum = (df_merged['manual_std'] == 'summarized').astype(int)
y_pred_sum = (df_merged['pred_label'] == 'summarized').astype(int)

tn2, fp2, fn2, tp2 = confusion_matrix(y_true_sum, y_pred_sum).ravel()

sensitivity_sum = tp2 / (tp2 + fn2) if (tp2 + fn2) > 0 else float('nan')
specificity_sum = tn2 / (tn2 + fp2) if (tn2 + fp2) > 0 else float('nan')

print("\nSensitivity / Specificity (SUMMARIZED as positive):")
print(f"Sensitivity (SUMMARIZED): {sensitivity_sum:.4f}")
print(f"Specificity (SUMMARIZED): {specificity_sum:.4f}")