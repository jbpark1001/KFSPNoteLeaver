# -*- coding: utf-8 -*-
"""
Created on Wed Jun 18 13:54:15 2025

@author: Jae Bin Park
"""

# -*- coding: utf-8 -*-
"""
Created on Mon May  5 14:24:32 2025

@author: Jae Bin Park
"""

#%% Required Libraries
import pandas as pd


#%% Importing data
print("Loading data...")

#kfsp=pd.read_excel(r'G:\KFSP\Raw Data\KFSPdatacopy.xlsx')
#kfsppororo=pd.read_excel(r'C:\Users\Jae Bin Park\pororokfspnotes.xlsx')
#psmmatchedmurd=pd.read_csv(r'C:\Users\Jae Bin Park\OneDrive\KAIST Research\Suicide Research\KFSP Data (Remote)\2024\Codes\R\88+glm_matched_ratio2.csv')
#kfspnonote=kfsp[kfsp['NOTE_CONTENTDTL'].isna()]
#kfspnote=kfsp[~kfsp['NOTE_CONTENTDTL'].isna()]

kfsppororo= pd.read_excel(r'C:\Users\Jae Bin Park\kfsp_sectioned_ver2.xlsx')
print("Data loaded successfully!")
#%% Basic Preprocessing
print("Running basic preprocessing...")

kfsppororo['NOTE_CONTENTDTL']=kfsppororo['NOTE_CONTENTDTL'].str.replace("엄마아빠", "엄마 아빠", regex=False)
kfsppororo['preprocessednotes']=kfsppororo['NOTE_CONTENTDTL'].str.replace("[^ㄱ-ㅎㅏ-ㅣ가-힣 ]", "", regex=True)

kfsppororo['preprocessednotes']=kfsppororo['NOTE_CONTENTDTL'].str.replace(r'[^ㄱ-ㅎㅏ-ㅣ가-힣 .!?]', "", regex=True)


print("Running basic preprocessing...Completed")

#%% Extracting note length and pronoun counts

"""Note Length"""
def word_length(text):
    return len(text.split())

kfsppororo['notelength'] = kfsppororo["preprocessednotes"].apply(lambda text: word_length(text))

"""Pronoun Use"""

from transformers import AutoModelForTokenClassification,AutoModel,AutoTokenizer
import torch

klue_tokenizer = AutoTokenizer.from_pretrained("klue/roberta-large")

def Pronoun_Count(text,klue_tokenizer):
    Tokens = klue_tokenizer.tokenize(text)
    Count = 0
    Count2 = 0
    Count3 = 0
    
    FP = ['나','내','저','제','우리','저희']
    SP = ['너','그대','당신','너희','우리','저희']
    TP = ['그','그녀','그들','그분','그녀들']
    
    for token in Tokens:
        if token in FP:
            Count +=1
        elif token in SP:
            Count2 +=1
        elif token in TP:
            Count3 +=1
            
    return (Count,Count2,Count3)

kfsppororo['FP_Count'] = kfsppororo['preprocessednotes'].apply(lambda x: Pronoun_Count(x,klue_tokenizer)[0])
kfsppororo['SP_Count'] = kfsppororo['preprocessednotes'].apply(lambda x: Pronoun_Count(x,klue_tokenizer)[1])
kfsppororo['TP_Count'] = kfsppororo['preprocessednotes'].apply(lambda x: Pronoun_Count(x,klue_tokenizer)[2])

#%%
import pandas as pd
import kss
from tqdm import tqdm

tqdm.pandas(desc="Labeling short notes")

kfsppororo['too_short1'] = kfsppororo['preprocessednotes'].progress_apply(
    lambda x: len(kss.split_sentences(x)) < 3 if isinstance(x, str) else True
)
#%%


# Enable tqdm for pandas
tqdm.pandas()

# Function to extract intro, body, and conclusion
def split_intro_body_conclusion(text):
    if not isinstance(text, str):
        return '', '', ''
    sentences = kss.split_sentences(text)
    n = len(sentences)
    
    if n == 0:
        return '', '', ''
    elif n <= 2:
        return sentences[0], '', sentences[-1] if n == 2 else ''
    else:
        intro = ' '.join(sentences[:2])  # First 2 sentences
        conclusion = ' '.join(sentences[-2:])  # Last 2 sentences
        body = ' '.join(sentences[2:-2]) if n > 4 else ''
        return intro, body, conclusion

# Apply to the DataFrame
kfsppororo[['Intro', 'Body', 'Conclusion']] = kfsppororo['preprocessednotes'].progress_apply(
    lambda x: pd.Series(split_intro_body_conclusion(x))
)

#%%One third division

import pandas as pd
import kss
from tqdm import tqdm


tqdm.pandas()



def split_sections(text):
    if not isinstance(text, str):
        return '', '', ''
    
    sentences = kss.split_sentences(text)
    n = len(sentences)

    if n == 0:
        return '', '', ''
    elif n == 1:
        return sentences[0], '', ''
    elif n == 2:
        return sentences[0], '', sentences[1]
    else:
        one_third = n // 3
        two_third = 2 * one_third

        intro = ' '.join(sentences[:one_third])
        body = ' '.join(sentences[one_third:two_third])
        conclusion = ' '.join(sentences[two_third:])
        return intro, body, conclusion

# Apply the function to the DataFrame
kfsppororo[['1st_section', '2nd_section', '3rd_section']] = kfsppororo['preprocessednotes'].progress_apply(
    lambda x: pd.Series(split_sections(x))
)
#%%

import os

# Make absolutely sure transformers won't try TF/Flax in this process
os.environ["USE_TF"] = "0"
os.environ["USE_FLAX"] = "0"
os.environ["TRANSFORMERS_NO_TF"] = "1"
os.environ["TRANSFORMERS_NO_FLAX"] = "1"

#%%
from keybert import KeyBERT
from transformers import BertModel

import os

# Make absolutely sure transformers won't try TF/Flax in this process
os.environ["TRANSFORMERS_NO_TF"] = "1"
os.environ["TRANSFORMERS_NO_FLAX"] = "1"

model = BertModel.from_pretrained('skt/kobert-base-v1')
kw_model = KeyBERT(model)

# Initialize new columns
kfsppororo["kluekeyword_Intro"] = ""
kfsppororo["kluekeyword_Body"] = ""
kfsppororo["kluekeyword_Conclusion"] = ""

# Loop with progress bar
for ind in tqdm(kfsppororo.index):
    for section in ["Intro", "Body", "Conclusion"]:
        text = kfsppororo[f"{section}"][ind]
        if isinstance(text, str) and len(text.strip()) > 0:
            keywords = kw_model.extract_keywords(
                text,
                keyphrase_ngram_range=(1, 1),
                stop_words=None,
                top_n=5
            )
        else:
            keywords = []
        kfsppororo.at[ind, f"kluekeyword_{section}"] = keywords


kfsppororo["kluekeyword_1st_section"] = ""
kfsppororo["kluekeyword_2nd_section"] = ""
kfsppororo["kluekeyword_3rd_section"] = ""

# Loop with progress bar
for ind in tqdm(kfsppororo.index):
    for section in ["1st_section", "2nd_section", "3rd_section"]:
        text = kfsppororo[f"{section}"][ind]
        if isinstance(text, str) and len(text.strip()) > 0:
            keywords = kw_model.extract_keywords(
                text,
                keyphrase_ngram_range=(1, 1),
                stop_words=None,
                
                top_n=5
            )
        else:
            keywords = []
        kfsppororo.at[ind, f"kluekeyword_{section}"] = keywords


#%%

from keybert import KeyBERT
from sentence_transformers import SentenceTransformer

kw_model = KeyBERT(SentenceTransformer('jhgan/ko-sbert-nli'))


kfsppororo["kluekeywordsentencetransformer_Intro"] = ""
kfsppororo["kluekeywordsentencetransformer_Body"] = ""
kfsppororo["kluekeywordsentencetransformer_Conclusion"] = ""

# Loop with progress bar
for ind in tqdm(kfsppororo.index):
    for section in ["Intro", "Body", "Conclusion"]:
        text = kfsppororo[f"{section}"][ind]
        if isinstance(text, str) and len(text.strip()) > 0:
            keywords = kw_model.extract_keywords(
                text,
                keyphrase_ngram_range=(1, 1),
                stop_words=None,
                
                top_n=5
            )
        else:
            keywords = []
        kfsppororo.at[ind, f"kluekeywordsentencetransformer_{section}"] = keywords



kfsppororo["kluekeywordsentencetransformer_1st_section"] = ""
kfsppororo["kluekeywordsentencetransformer_2nd_section"] = ""
kfsppororo["kluekeywordsentencetransformer_3rd_section"] = ""

# Loop with progress bar
for ind in tqdm(kfsppororo.index):
    for section in ["1st_section", "2nd_section", "3rd_section"]:
        text = kfsppororo[f"{section}"][ind]
        if isinstance(text, str) and len(text.strip()) > 0:
            keywords = kw_model.extract_keywords(
                text,
                keyphrase_ngram_range=(1, 1),
                stop_words=None,
                
                top_n=5
            )
        else:
            keywords = []
        kfsppororo.at[ind, f"kluekeywordsentencetransformer_{section}"] = keywords

#%%from transformers import AutoTokenizer
from transformers import AutoTokenizer
from tqdm import tqdm

def tokenize_keyword_columns_with_scores(df, keyword_columns, stopwords=None):
    if stopwords is None:
        stopwords = []

    # Load the KLUE tokenizer
    klue_tokenizer = AutoTokenizer.from_pretrained("klue/roberta-large")

    for col in keyword_columns:
        tokenized_col = []
        
        for keyword_list in tqdm(df[col], desc=f"Tokenizing {col}"):
            if not isinstance(keyword_list, list):
                tokenized_col.append([])
                continue

            token_score_list = []
            for word_score in keyword_list:
                if not isinstance(word_score, tuple) or len(word_score) != 2:
                    continue
                word, score = word_score
                try:
                    tokens = klue_tokenizer.tokenize(word)
                    tokens = [t for t in tokens if t not in stopwords and '#' not in t]
                    token_score_list.extend([(t, score) for t in tokens])
                except:
                    continue

            tokenized_col.append(token_score_list)

        # Store the result in a new column
        output_col = f"tokenized{col}"  # e.g., 'Intro', 'Body', etc.
        df[output_col] = tokenized_col

    return df


keyword_cols = [
    "kluekeywordsentencetransformer_Intro",
    "kluekeywordsentencetransformer_Body",
    "kluekeywordsentencetransformer_Conclusion"
]

kfsppororo = tokenize_keyword_columns_with_scores(kfsppororo, keyword_cols)

keyword_cols = [
    "kluekeywordsentencetransformer_1st_section",
    "kluekeywordsentencetransformer_2nd_section",
    "kluekeywordsentencetransformer_3rd_section"
]

kfsppororo = tokenize_keyword_columns_with_scores(kfsppororo, keyword_cols)

#%%
