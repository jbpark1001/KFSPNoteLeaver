"""Exploratory matched-cohort content/placement analysis; never alters source files.

Uses the saved sentence labels from 15_sentence_robustness.py, not rebuilt NLP.
Run with the bundled Python. Dependencies are project-local. Outputs contain no text.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS', '1')
os.environ.setdefault('OMP_NUM_THREADS', '1')
from pathlib import Path
import sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / '.analysis_dependencies'))
import json, hashlib, re, warnings
import numpy as np
import pandas as pd
from scipy import linalg
from scipy.optimize import minimize
from scipy.special import gammaln, logsumexp, expit
from scipy.stats import chi2, norm
import statsmodels.api as sm
from statsmodels.stats.multitest import multipletests
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.exceptions import ConvergenceWarning
from threadpoolctl import threadpool_limits

OUT = ROOT / 'manuscript_analysis/outputs/tables/content_vs_placement_20261102'
OUT.mkdir(parents=True, exist_ok=True)
SENT = ROOT / 'manuscript_analysis/outputs/tables/sentence_robustness/sentence_df_with_theme_sentiment_flags_and_shuffled_bins.csv'
META = Path(r'C:\Users\Jae Bin Park\kfsp_sectioned_ver2.xlsx')
THEMES = ['Sorry and Shame','Love and Gratitude','Burden','Despair','Post-mortem Affairs']
AGE_LABELS = ['<=18','19-34','35-49','50-64','>=65']

def log(message):
    print(message, flush=True)

def prepare():
    cache = OUT / 'analysis_features.pkl'
    manifest=OUT/'feature_cache_sources.json'
    fingerprint={str(p):dict(size=p.stat().st_size,mtime_ns=p.stat().st_mtime_ns) for p in [SENT,META]}
    if cache.exists() and manifest.exists() and json.loads(manifest.read_text())==fingerprint:
        return pd.read_pickle(cache)
    cols = ['note_id','sentence_index','n_sent','rel_pos','third_bin'] + ['theme_'+t for t in THEMES]
    s = pd.read_csv(SENT, usecols=cols)
    m = pd.read_excel(META, usecols=['SEX','AGE2','pred_label','NOTE_CONTENTDTL'])
    assert not s.duplicated(['note_id','sentence_index']).any()
    g = s.groupby('note_id',sort=True)
    d = g.size().to_frame('n')
    assert (d.n == g.n_sent.first()).all()
    assert g.n_sent.nunique().eq(1).all()
    assert g.sentence_index.min().eq(1).all() and g.sentence_index.max().eq(d.n).all()
    assert np.allclose(s.rel_pos,(s.sentence_index-.5)/s.n_sent,atol=1e-12)
    expected = np.minimum(np.floor(s.rel_pos.to_numpy()*3).astype(int)+1,3)
    assert np.array_equal(expected,s.third_bin.to_numpy())
    assert set(d.index).issubset(m.index)
    d = d.join(m[['SEX','AGE2','pred_label']])
    d = d[(d.n>=3)&d.SEX.isin([1,2])&d.AGE2.isin([1,2,3,4,5])&d.pred_label.eq('raw')].copy()
    for b in [1,2,3]:
        d['n'+str(b)] = s[s.third_bin.eq(b)].groupby('note_id').size().reindex(d.index,fill_value=0)
    assert d[['n1','n2','n3']].sum(axis=1).eq(d.n).all()
    for j,t in enumerate(THEMES):
        flag='theme_'+t
        assert s[flag].isin([0,1]).all()
        d['k'+str(j)] = g[flag].sum().reindex(d.index)
        for b in [1,2,3]:
            d[f'k{j}_{b}'] = s[s.third_bin.eq(b)].groupby('note_id')[flag].sum().reindex(d.index,fill_value=0)
    # Exact full-note duplicates share every fold and bootstrap sampling unit.
    texts=m.loc[d.index,'NOTE_CONTENTDTL'].fillna('').astype(str)
    assert texts.str.strip().ne('').all()
    d['duplicate_group']=[hashlib.sha256(re.sub(r'\s+','',x).encode('utf-8')).hexdigest() for x in texts]
    for b in [1,3]:
        d['p'+str(b)]=np.divide(d[f'k1_{b}'],d.k1,out=np.zeros(len(d)),where=d.k1.to_numpy()>0)
    d.to_pickle(cache)
    manifest.write_text(json.dumps(fingerprint,indent=2),encoding='utf-8')
    return d

def design(d):
    def restricted_cubic(x,knots):
        # Natural cubic spline: linear beyond the boundary knots.
        ts=np.asarray(knots);last=ts[-1];prev=ts[-2]
        basis=[x]
        for t in ts[:-2]:
            h=(np.maximum(x-t,0)**3-np.maximum(x-prev,0)**3*(last-t)/(last-prev)+np.maximum(x-last,0)**3*(prev-t)/(last-prev))/(last-ts[0])**2
            basis.append(h)
        return basis
    z={'intercept':np.ones(len(d)), 'male':d.SEX.eq(1).astype(float)}
    ln=np.log(d.n.to_numpy())
    for j,x in enumerate(restricted_cubic(ln,np.log([3,6,12,30]))):z[f'length_spline_{j}']=x
    # Midpoint thirds have equal opening/ending exposures. Include their common
    # share once; the middle share is 1 minus twice this value.
    assert d.n1.eq(d.n3).all()
    z['outer_section_share']=d.n1/d.n
    for j,t in enumerate(THEMES):
        k=d['k'+str(j)].to_numpy(); x=np.log1p(k); f=k/d.n.to_numpy()
        z[f'{t}_any']=(k>0).astype(float)
        for p,v in enumerate(restricted_cubic(x,np.log1p([0,2,8]))): z[f'{t}_count_spline_{p}']=v
        for p in [1,2]: z[f'{t}_fraction^{p}']=f**p
    a=pd.DataFrame(z,index=d.index)
    # Reject rather than silently fit a singular inferential model.
    assert np.linalg.matrix_rank(a.to_numpy())==a.shape[1]
    b=a.assign(LG_opening_share=d.p1,LG_ending_share=d.p3)
    assert np.linalg.matrix_rank(b.to_numpy())==b.shape[1]
    return a,b

def inference(d,a,b):
    rows=[]; coefficients=[]
    # Scale once only for full-sample inference; no estimated transforms reused in CV.
    aa=a.copy(); bb=b.copy()
    for frame in [aa,bb]:
        frame.iloc[:,1:]=(frame.iloc[:,1:]-frame.iloc[:,1:].mean())/frame.iloc[:,1:].std(ddof=0)
    for age,label in enumerate(AGE_LABELS,1):
        y=d.AGE2.eq(age).astype(int)
        fits=[];clusters=pd.factorize(d.duplicate_group)[0]
        for x in [aa,bb]:
            X=x.to_numpy(float);Y=y.to_numpy(float)
            def objective(beta):
                eta=X@beta;pr=expit(eta)
                return float(np.sum(np.logaddexp(0,eta)-Y*eta)),X.T@(pr-Y)
            fit=minimize(objective,np.zeros(X.shape[1]),jac=True,method='BFGS',options={'gtol':1e-6,'maxiter':2000})
            val,score=objective(fit.x)
            assert np.max(np.abs(score))<1e-3,(fit.message,float(np.max(np.abs(score))))
            pr=expit(X@fit.x);H=X.T@((pr*(1-pr))[:,None]*X)
            bread=np.linalg.inv(H);sc=np.zeros((max(clusters)+1,X.shape[1]));np.add.at(sc,clusters,X*(Y-pr)[:,None])
            cov=bread@(sc.T@sc)@bread
            assert np.isfinite(cov).all() and np.min(np.linalg.eigvalsh(H))>1e-7
            fits.append(dict(beta=fit.x,ll=-val,cov=cov,aic=2*len(fit.x)+2*val,max_score=float(np.max(np.abs(score))),hessian_condition=float(np.linalg.cond(H))))
        f0,f1=fits; lr=2*(f1['ll']-f0['ll'])
        R=np.zeros((2,bb.shape[1])); R[0,-2]=1;R[1,-1]=1
        contrast=R@f1['beta'];wald=float(contrast@np.linalg.solve(R@f1['cov']@R.T,contrast))
        rows.append(dict(age=label,n=len(d),cases=int(y.sum()),lr_chi2=float(lr),df=2,p_lr=float(chi2.sf(lr,2)),p_cluster_wald=float(chi2.sf(wald,2)),aic_content=f0['aic'],aic_placement=f1['aic'],max_score=max(f0['max_score'],f1['max_score']),hessian_condition=f1['hessian_condition']))
        # Convert standardized placement coefficients back to original share units.
        for col in ['LG_opening_share','LG_ending_share']:
            j=bb.columns.get_loc(col);sd=b[col].std(ddof=0); beta=f1['beta'][j]/sd; se=np.sqrt(f1['cov'][j,j])/sd
            coefficients.append(dict(age=label,term=col,log_or_per_unit=beta,se=se,or_per_10pct=float(np.exp(.1*beta)),lo_10pct=float(np.exp(.1*(beta-1.96*se))),hi_10pct=float(np.exp(.1*(beta+1.96*se)))))
    r=pd.DataFrame(rows)
    for c in ['p_lr','p_cluster_wald']:r[c+'_holm']=multipletests(r[c],method='holm')[1]
    r.to_csv(OUT/'nested_model_tests.csv',index=False)
    pd.DataFrame(coefficients).to_csv(OUT/'placement_coefficients.csv',index=False)
    log(r.to_string(index=False))
    return r

def bootstrap_ci(v,groups,rng,B=2000):
    # Paired bootstrap of frozen out-of-fold losses, resampling duplicate groups.
    codes,_=pd.factorize(groups)
    sums=np.bincount(codes,weights=v); counts=np.bincount(codes)
    vals=[]
    for _ in range(B):
        ii=rng.integers(0,len(sums),len(sums))
        vals.append(sums[ii].sum()/counts[ii].sum())
    return np.percentile(vals,[2.5,97.5])

def cross_validate(d,a,b,repeats=3,C=1.0,suffix=''):
    losses=np.zeros((len(d),5,2,2)); probs=np.zeros((len(d),5,2))
    foldrows=[]
    groups=d.duplicate_group.to_numpy(); labels=d.AGE2.to_numpy().astype(int)
    for rep in range(repeats):
        splitter=StratifiedGroupKFold(n_splits=5,shuffle=True,random_state=20261102+rep)
        for fold,(tr,te) in enumerate(splitter.split(a,labels,groups)):
            assert not set(groups[tr])&set(groups[te])
            for j,x in enumerate([a.iloc[:,1:].to_numpy(),b.iloc[:,1:].to_numpy()]):
                scaler=StandardScaler().fit(x[tr]); xt=scaler.transform(x[tr]); xv=scaler.transform(x[te])
                for ag in range(1,6):
                    y=(labels==ag).astype(int)
                    with warnings.catch_warnings():
                        warnings.simplefilter('error',ConvergenceWarning)
                        model=LogisticRegression(C=C,solver='lbfgs',max_iter=3000,tol=1e-9).fit(xt,y[tr])
                    p=np.clip(model.predict_proba(xv)[:,1],1e-12,1-1e-12)
                    ll=-(y[te]*np.log(p)+(1-y[te])*np.log1p(-p)); br=(y[te]-p)**2
                    losses[te,ag-1,j,0]+=ll/repeats;losses[te,ag-1,j,1]+=br/repeats
                    probs[te,ag-1,j]+=p/repeats
                    foldrows.append(dict(repeat=rep+1,fold=fold+1,age=AGE_LABELS[ag-1],model=['content','placement'][j],n=len(te),logloss=ll.mean(),brier=br.mean()))
            log(f'CV C={C}: repeat {rep+1}, fold {fold+1} complete')
    rows=[];rng=np.random.default_rng(20261102)
    for ag,label in enumerate(AGE_LABELS):
        for metric,name in enumerate(['logloss','brier']):
            base=losses[:,ag,0,metric]; new=losses[:,ag,1,metric]; delta=base-new
            lo,hi=bootstrap_ci(delta,groups,rng)
            rows.append(dict(age=label,metric=name,content=base.mean(),placement=new.mean(),improvement=delta.mean(),relative_improvement_pct=100*delta.mean()/base.mean(),ci_low=lo,ci_high=hi,C=C,repeats=repeats))
    result=pd.DataFrame(rows);result.to_csv(OUT/f'cross_validation{suffix}.csv',index=False)
    pd.DataFrame(foldrows).to_csv(OUT/f'cross_validation_folds{suffix}.csv',index=False)
    np.savez_compressed(OUT/f'oof_losses{suffix}.npz',losses=losses,probs=probs)
    log(result.to_string(index=False))
    return result

def conditional(d,adjust=True):
    """Exact conditional likelihood aggregated by section counts.

    Equivalent to sentence-level conditional logistic with middle as reference.
    For each note, condition on total thematic positives k. Probability of an
    allocation is proportional to product choose(n_b,k_b)*exp(beta1*k1+beta3*k3).
    This avoids enumerating individual sentence subsets, without approximation.
    """
    informative=d[(d.k1>0)&(d.k1<d.n)].copy()
    groups=[]
    mean_male=float(informative.SEX.eq(1).mean())
    mean_logn=float(np.log(informative.n).mean())
    keys=['AGE2','SEX','n1','n2','n3','k1']
    for key,g in informative.groupby(keys,sort=True):
        age,sex,n1,n2,n3,k=map(int,key)
        x1s=[];x3s=[];lc=[]
        for x1 in range(max(0,k-n2-n3),min(n1,k)+1):
            for x3 in range(max(0,k-x1-n2),min(n3,k-x1)+1):
                x2=k-x1-x3
                x1s.append(x1);x3s.append(x3)
                lc.append(sum(gammaln(n+1)-gammaln(x+1)-gammaln(n-x+1) for n,x in [(n1,x1),(n2,x2),(n3,x3)]))
        X=np.column_stack([x1s,x3s]).astype(float)
        observed=g[['k1_1','k1_3']].to_numpy(float)
        groups.append((age-1,X,np.asarray(lc),observed,g.duplicate_group.to_numpy(),float(sex==1)-mean_male,np.log(n1+n2+n3)-mean_logn))
    def evaluate(theta,full=False,details=False):
        base=10 if full else 2;p=base+(4 if adjust else 0)
        ll=0.;grad=np.zeros(p);hess=np.zeros((p,p));scores=[];ids=[]
        for age,X,lc,obs,gids,male,ln in groups:
            sl=slice(2*age,2*age+2) if full else slice(0,2)
            D=np.zeros((2,p));D[:,sl]=np.eye(2)
            if adjust:
                D[:,base:base+2]=male*np.eye(2)
                D[:,base+2:base+4]=ln*np.eye(2)
            beta=D@theta; z=lc+X@beta; lz=logsumexp(z); w=np.exp(z-lz)
            mu=w@X; centered=X-mu; cov=(centered*w[:,None]).T@centered
            ll+=np.sum(obs@beta)-len(obs)*lz
            grad+=D.T@(obs.sum(axis=0)-len(obs)*mu)
            hess+=len(obs)*D.T@cov@D
            if details:
                sc=(obs-mu)@D
                scores.append(sc);ids.extend(gids)
        return ll,grad,hess,(np.vstack(scores),ids) if details else None
    fits=[]
    for full in [False,True]:
        init=np.zeros((10 if full else 2)+(4 if adjust else 0))
        fit=minimize(lambda t:(-evaluate(t,full)[0],-evaluate(t,full)[1]),init,jac=True,method='BFGS',options={'gtol':1e-6,'maxiter':500})
        ll,gr,hess,detail=evaluate(fit.x,full,True)
        assert np.max(np.abs(gr))<1e-3, (fit.message,gr)
        codes,_=pd.factorize(np.asarray(detail[1]));sc=np.zeros((max(codes)+1,len(fit.x)));np.add.at(sc,codes,detail[0])
        bread=np.linalg.inv(hess);robust=bread@(sc.T@sc)@bread
        fits.append((fit.x,ll,robust,float(np.max(np.abs(gr)))))
    theta,ll,cov,gr=fits[1]; lr=2*(ll-fits[0][1])
    R=np.zeros((8,len(theta)))
    for age in range(1,5):
        for j in [0,1]:R[2*(age-1)+j,2*age+j]=1;R[2*(age-1)+j,j]=-1
    v=R@theta;w=float(v@np.linalg.solve(R@cov@R.T,v))
    rows=[]
    for age,label in enumerate(AGE_LABELS):
        c=np.zeros(len(theta));c[2*age]=-1;c[2*age+1]=1
        beta=float(c@theta);se=float(np.sqrt(c@cov@c))
        rows.append(dict(age=label,informative_notes=int(informative.AGE2.eq(age+1).sum()),ending_vs_opening_or=np.exp(beta),ci_low=np.exp(beta-1.96*se),ci_high=np.exp(beta+1.96*se),log_or=beta,se=se))
    r=pd.DataFrame(rows);r.to_csv(OUT/'conditional_position_by_age.csv',index=False)
    # A focused youngest/oldest contrast supplements the omnibus 8-df interaction.
    c=np.zeros(len(theta));c[1]=1;c[0]=-1;c[9]=-1;c[8]=1
    v=float(c@theta);se=float(np.sqrt(c@cov@c))
    result=dict(informative_notes=len(informative),excluded_no_LG=int(d.k1.eq(0).sum()),excluded_all_LG=int(d.k1.eq(d.n).sum()),lr_chi2=lr,df=8,p_lr=float(chi2.sf(lr,8)),cluster_wald=w,p_cluster_wald=float(chi2.sf(w,8)),youngest_oldest_or_ratio=np.exp(v),youngest_oldest_ci=[np.exp(v-1.96*se),np.exp(v+1.96*se)],max_score=gr,adjust_sex_and_loglength_position_effects=adjust,reference_male_fraction=mean_male,reference_log_sentence_count=mean_logn)
    result['parameters']=theta.tolist()
    result['cluster_covariance']=cov.tolist()
    (OUT/'conditional_summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    log(json.dumps({k:v for k,v in result.items() if k not in ['parameters','cluster_covariance']}));log(r.to_string(index=False))
    return r,result

def describe(d):
    rows=[]
    for age,label in enumerate(AGE_LABELS,1):
        g=d[d.AGE2.eq(age)];positive=g[g.k1>0]
        rows.append(dict(age=label,n=len(g),LG_present_pct=100*g.k1.gt(0).mean(),mean_note_LG_fraction=(g.k1/g.n).mean(),LG_positive_notes=len(positive),mean_LG_opening_share=positive.p1.mean(),mean_LG_ending_share=positive.p3.mean(),median_sentences=g.n.median()))
    pd.DataFrame(rows).to_csv(OUT/'descriptive_by_age.csv',index=False)
    info=dict(n=len(d),sentences=int(d.n.sum()),age_counts=d.AGE2.value_counts().sort_index().to_dict(),unique_duplicate_groups=int(d.duplicate_group.nunique()),duplicate_notes=int(d.duplicate_group.duplicated(keep=False).sum()),max_sentences=int(d.n.max()),source_sentence_file=str(SENT),source_metadata_file=str(META),seed=20261102,exploratory=True)
    (OUT/'cohort_and_specification.json').write_text(json.dumps(info,indent=2),encoding='utf-8')
    log(json.dumps(info))

def plot(des,cv,cond):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axs=plt.subplots(1,3,figsize=(15,4.5),layout='constrained')
    x=np.arange(5)
    axs[0].plot(x,des.LG_present_pct,'o-',color='#315b7d')
    axs[0].set(ylabel='Notes containing Love/Gratitude (%)',title='A. Whole-note presence')
    lo=cond.ending_vs_opening_or-cond.ci_low;hi=cond.ci_high-cond.ending_vs_opening_or
    axs[1].errorbar(x,cond.ending_vs_opening_or,yerr=[lo,hi],fmt='o',capsize=4,color='#9c4f30')
    axs[1].axhline(1,color='grey',lw=1);axs[1].set(ylabel='Ending versus opening odds ratio',title='B. Conditional on each note’s theme count')
    c=cv[cv.metric.eq('logloss')]
    axs[2].errorbar(x,c.improvement,yerr=[c.improvement-c.ci_low,c.ci_high-c.improvement],fmt='o',capsize=4,color='#376b4d')
    axs[2].axhline(0,color='grey',lw=1);axs[2].set(ylabel='Held-out log-loss reduction (nats/note)',title='C. Added value of placement')
    for ax in axs:
        ax.set_xticks(x,AGE_LABELS);ax.set_xlabel('Age group');ax.spines[['right','top']].set_visible(False)
    fig.savefig(OUT/'content_vs_placement.png',dpi=220)
    fig.savefig(OUT/'content_vs_placement.pdf')
    plt.close(fig)

def main():
    with threadpool_limits(limits=1):
        log('Preparing saved sentence features and checking cohort linkage...')
        d=prepare();describe(d);a,b=design(d)
        log(f'Baseline columns={a.shape[1]}, placement columns={b.shape[1]}')
        if '--finish' not in sys.argv:
            inference(d,a,b)
            cv=cross_validate(d,a,b)
            cross_validate(d,a,b,repeats=1,C=10.,suffix='_C10_sensitivity')
        else:
            cv=pd.read_csv(OUT/'cross_validation.csv')
        cond,summary=conditional(d)
        plot(pd.read_csv(OUT/'descriptive_by_age.csv'),cv,cond)
        import scipy,sklearn,statsmodels
        (OUT/'software_versions.json').write_text(json.dumps({p:m.__version__ for p,m in [('numpy',np),('pandas',pd),('scipy',scipy),('sklearn',sklearn),('statsmodels',statsmodels)]},indent=2),encoding='utf-8')
        log('COMPLETE: '+str(OUT))

if __name__=='__main__':
    main()
