"""Independent numerical checks for the exploratory conditional likelihood."""
from pathlib import Path
import sys,json,hashlib
ROOT=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'.analysis_dependencies'))
import numpy as np
import pandas as pd
from scipy.special import gammaln,logsumexp
from statsmodels.discrete.conditional_models import ConditionalLogit
from itertools import combinations

OUT=ROOT/'manuscript_analysis/outputs/tables/content_vs_placement_20261102'
rng=np.random.default_rng(7411)
max_error=0.;checked=0
for n in range(3,11):
    bins=np.minimum(np.floor(((np.arange(n)+.5)/n)*3).astype(int),2)
    X=np.column_stack([bins==0,bins==2]).astype(float)
    ns=np.bincount(bins,minlength=3)
    for k in range(1,n):
        y=np.zeros(n);y[rng.choice(n,k,replace=False)]=1
        for _ in range(3):
            beta=rng.normal(size=2)
            # Independently enumerate every subset of k positive sentences.
            brute=logsumexp([np.sum(X[list(ix)]@beta) for ix in combinations(range(n),k)])
            terms=[]
            for a in range(ns[0]+1):
                for c in range(ns[2]+1):
                    b=k-a-c
                    if 0<=b<=ns[1]:
                        lc=sum(gammaln(nn+1)-gammaln(xx+1)-gammaln(nn-xx+1) for nn,xx in zip(ns,[a,b,c]))
                        terms.append(lc+a*beta[0]+c*beta[1])
            aggregated=logsumexp(terms)
            expected=y@(X@beta)-aggregated
            library=ConditionalLogit(y,X,groups=np.zeros(n)).loglike(beta)
            err=max(abs(brute-aggregated),abs(library-expected))
            max_error=max(max_error,float(err));checked+=1
assert max_error<1e-10
d=pd.read_pickle(OUT/'analysis_features.pkl')
s=pd.read_csv(ROOT/'manuscript_analysis/outputs/tables/sentence_robustness/sentence_df_with_theme_sentiment_flags_and_shuffled_bins.csv',usecols=['note_id','sentence_index','n_sent','rel_pos'])
assert np.allclose(s.rel_pos,(s.sentence_index-.5)/s.n_sent,atol=1e-12)
assert not s.duplicated(['note_id','sentence_index']).any()
g=s.groupby('note_id')
assert g.sentence_index.min().eq(1).all() and g.sentence_index.max().eq(g.size()).all()
assert len(d)==18648
assert d[['n1','n2','n3']].sum(axis=1).eq(d.n).all()
assert d.n1.eq(d.n3).all()
assert (d.p1+d.p3<=1+1e-12).all()
for j in range(5):
    assert d[[f'k{j}_1',f'k{j}_2',f'k{j}_3']].sum(axis=1).eq(d[f'k{j}']).all()
    assert d[f'k{j}'].between(0,d.n).all()
cv=pd.read_csv(OUT/'cross_validation.csv')
assert np.allclose(cv.content-cv.placement,cv.improvement)
cond=json.loads((OUT/'conditional_summary.json').read_text())
assert cond['informative_notes']+cond['excluded_no_LG']+cond['excluded_all_LG']==len(d)
hashes={}
for p in [ROOT/'manuscript_analysis/text_analysis/15_sentence_robustness.py',ROOT/'manuscript_analysis/text_analysis/19_content_vs_placement.py',Path(r'C:\Users\Jae Bin Park\kfsp_sectioned_ver2.xlsx'),ROOT/'manuscript_analysis/outputs/tables/sentence_robustness/sentence_df_with_theme_sentiment_flags_and_shuffled_bins.csv']:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    hashes[str(p)]=h.hexdigest()
result=dict(passed=True,conditional_likelihood_cases=checked,max_absolute_error=max_error,checks=['Exact conditional denominator versus exhaustive subsets','Conditional likelihood versus statsmodels','Cohort size, section sizes, theme totals and placement shares','Sentence indices and relative-position formula','Cross-validation metric arithmetic','Conditional informative/excluded note accounting'],source_sha256=hashes)
(OUT/'validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print(json.dumps({k:v for k,v in result.items() if k!='source_sha256'},indent=2))
