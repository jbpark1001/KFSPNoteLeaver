# Restricted inputs and reconstruction boundaries

Each input location is explicit in `config/paths.json`. Input hashes, observed software versions and cohort counts are written by `run.py audit-inputs` to `outputs/validation/input_audit.json`. The local configuration is excluded from version control. Only trusted study-origin pickle files should be used: the project inherits their Python serialization format.

| Input | Contract and purpose |
|---|---|
| `demographic_source` | Full 102,922-row registry pickle, including `NOTE_EX`, `NoteExist`, `WARNSPEAK1`–`WARNSPEAK4`, age, sex, year, suicide date, full note text and original demographic variables. `NOTE_EX`: 1 yes, 2 no; unknown/skipped is not no. |
| `eligible_notes` | Original eligible-text Excel workbook with 37,462 documents, stable original row ordering, `NOTE_CONTENTDTL`, `YEAR`, `SEX`, `AGE2` and `SUICIDE_DATE`. Its prior unavailable/multilingual exclusions are upstream decisions. |
| `raw_features` | Frozen primary theme dataframe. `too_short == False` selects 18,635; complete valid age/sex selects 18,630. Presence columns contain three binary entries per note. Includes text, section text and linkage fields. |
| `sentiment_features` | Frozen section sentiment dataframe with matching original IDs, linkage fields, `too_short` and section dictionaries containing `labels`. Sentiments are multi-label and can co-occur. |
| `section_annotations` | Newer classifier/segmentation workbook; Excel row positions are the study note IDs used by the saved sentence annotations. Do not reorder this file. This cohort differs from frozen primary features. |
| `sentence_annotations` | Saved sentence-level keyword and sentiment annotations used by stage 15 to derive binary labels. |
| `sentence_flags` | Stage-15 sentence-derived CSV containing `note_id`, one-based `sentence_index`, `n_sent`, `rel_pos`, `third_bin` and the five `theme_*` binary flags. The permutation stage validates indices, totals, binning, raw classification and demographics and requires the distinct 18,648-note cohort. |
| `manual_labels` / `manual_predictions` / `saved_scores` | Original annotation/prediction workbooks and scored-note CSV. Manual validation verifies source row IDs against full normalized text; it does not merge duplicate text many-to-many. Both the historical first-1,500-row convention and all usable annotations are reported. |
| `kote_checkpoint` | External KOTE 44-label model weights; the analysis selects 15 labels. Source inference uses probability >0.7. Base KcELECTRA model/tokenizer revision is `v2021`. |
| `theme_clusters`, `sentiment_clusters` | Earlier saved feature/cluster snapshots; needed for retained legacy clustering/transition plots and historical dictionary-comparison outputs. These are not inputs to the newly specified sentence-order permutation test. |
| Other figure inputs | Existing odds-ratio and factor-test tables, noun/verb counts, population workbook, geographic shapefile and descriptive proportions. They support retained older figure stages. |

Primary section splitting and sensitivity midpoint splitting are different. Primary thirds assign floor(n/3) sentences to opening and middle and the remainder to ending. Sensitivity thirds use sentence midpoint relative position. Five sentences therefore split 1/1/3 versus 2/1/2. The permutation stage preserves the latter section sizes.

Registry-to-text linkage for communication/content models uses unique composite matches in both sources on year, recorded sex, age group, suicide date and full note text, with field equality checked afterward. Original row positions are not registry linkage identifiers. In contrast, sentence IDs and annotation-row IDs are within-source identifiers whose text/schema consistency must be preserved.

To reconstruct eligible notes directly from the registry, stage 00 requires a JSON manifest with `source_sha256`, `ordered_included_registry_ids` and `excluded_registry_id_reasons` (string keys). The inclusion list must have 37,462 unique registry IDs and the reasons must cover the other 582 note-positive records. The manifest is restricted case-level data and is not included. After running stage 00, explicitly configure `eligible_notes` to `derived/eligible_notes.xlsx` and treat this as a rebuild, not verification of the saved corpus.
