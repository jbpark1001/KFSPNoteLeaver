# Validation record, 9 November 2026

This record distinguishes completed computations, reused artifacts and unexecuted work. Detailed outputs/logs remain local; the code-only archive contains this aggregate record and source code, not study records.

## Completed

| Check or stage | Result |
|---|---|
| Input and cohort audit | All 11 enumerated denominator checks match. Input hashes and observed Python versions recorded. |
| Original-source preservation | All 81 copied-source provenance entries checked against their original file hashes; original files unchanged. Working adaptations are labeled separately. |
| Scientific numerical tests | Eight tests pass: joint-shuffle preservation, independent aggregation, full-cohort-size integer-index safety, parity with the original age-model function, primary FDR families, import without data reads, fixed-model bootstrap parity, and historical/newer artifact isolation. |
| Demographic cleaning and predictor subsets | Rebuilt from the full source; all eight cuts generated. |
| Eight candidate models | All 56 checked numerical entries match the prior study summary. Selected model: N=70,922, including 28,419 note-positive and 42,503 note-negative records; sensitivity 38.2737%, Nagelkerke R²=0.122761. |
| Final demographic coefficient refit | All 93 non-intercept table rows match the saved source to numerical precision, including matching missingness for one non-estimable coefficient. Across finite estimates/SEs/statistics/P values, maximum absolute differences are below 6e-14. |
| Dictionary-only extraction | Both alternatives rebuilt; baseline flags verified against the original dictionary/keyword membership. |
| Communication analyses | Profiles, age contrasts, age×sex multinomial models, other-verbal-adjusted age associations and sensitivity checks completed. Analytic standardization gradient agrees with finite differences to 1.21e-12. |
| Linked content | Theme models for all three extraction methods and 15 sentiment outcomes with length, other-verbal and duplicate-text sensitivity models completed. |
| Adjusted prevalence | All 180 categorical prevalence/sensitivity models reported success; primary complete-case N=18,630. Ordered-age trends also computed. |
| Primary feature-association models | Theme/sentiment demographic models rerun with the four FDR families. |
| Segmentation sensitivity | Section and sentence models rerun. The 12 enumerated selected thematic directional/nominal-P claims pass. Unstable sentiment models are flagged by inference status rather than treated as valid estimates. |
| Full-cohort permutation parity | All 279,720 section-theme binary indicators match the independently generated stage-15 feature table. All 15 Love/Gratitude coefficients match separate age-model outputs; maximum error 2.50e-16. |
| Full 4,999 permutations | Completed using the corrected implementation, seed 20261109 and four thread workers. Holm-adjusted range P values by age group: .002, .002, .002, .0028, .002. Ending-minus-opening adjusted P=.002 for the two younger groups and the oldest group, with the reported signs. |
| Enumerated current manuscript claims | All 118 match at reported precision: communication, linked content, prevalence, selected segmentation findings and stated permutation conclusions. These are the explicitly listed claims, not every manuscript sentence. |
| Figures | Current communication/content layouts, primary feature heatmaps, sensitivity panels and descriptive-proportion figures rendered. Figure 2 was rendered explicitly from saved model tables. A generated communication figure was visually inspected. Final manuscript panel design/numbering was not supplied for every figure. |
| Classifier refit and stability | Completed with independent weak-label holdout. Counts reproduce 25,992 raw / 11,470 summarized. All 16 enumerated supplementary stability claims match, including bootstrap mean/SD/CI, threshold range, cue removal, weak-label agreement, Brier score, mixture overlap and five-model stability. These are internal consistency checks, not independent manual validity. |
| Manual agreement | Executed with verified annotation IDs/text. 76.2% newer saved and freshly refitted classifiers, and 78.7333% older workbook on the first 1,500 rows; 80.5% is not reproduced. This discrepancy is recorded, not altered. |
| CLI and syntax | Current suite dry-run passes; working Python scripts parse. Successful R model comparison establishes required R packages and executable paths for that stage. |

## Scope limits

The full fresh final-model profile-likelihood interval calculation was stopped after the refitted coefficients/SEs/statistics/P values matched the original saved table. New profile intervals are **not** claimed. The explicit `fig02-saved` route reuses the original profile intervals and factor tests; `04-final-model` retains the original full recomputation code, and `verify-demographic-refit` can compare its completed output. This scope decision is recorded in `outputs/validation/final_model_execution_scope.json`. The earlier October report is retained as historical evidence, not counted as a new interval calculation.

Full new KeyBERT/KOTE inference and rebuilt text features have not been run in this project. The primary numerical replication uses the frozen saved inputs, whose classifier/cohort provenance conflicts with the newer classifier as described in `REPLICATION_STATUS.md`. Model/tokenizer checkpoints and a source inclusion/exclusion manifest are required to establish a coherent end-to-end raw-data rebuild.

The first process-worker permutation attempt failed because Windows disallowed named-pipe creation. A later full-cohort parity check identified integer overflow in the initial new aggregation implementation. All affected preliminary permutation outputs were rejected and moved to `outputs/validation/rejected_integer_overflow_runs/`; they are not used by the accepted result paths or claim checks. The corrected implementation promotes indices to int64 before multiplying, is covered by a full-cohort-size regression test, and passed the complete rerun.

One initial classifier-stability validation run was stopped because it repeatedly rescored the same fixed model over 200 bootstrap samples. The separate copy now predicts once and resamples those predictions with the identical random indices and formulas. A numerical test checks exact parity with independent rescoring. This optimization changes computation time, not the bootstrap estimand or random draws.

Classifier construction/stability completed successfully, all 16 enumerated stability claims pass, and the NLP import probe passed. Exact observed Python/NLP/R package versions are recorded in `environment/observed-current-versions.json`. No full KeyBERT/KOTE inference run is implied. No human validation of the automated theme/sentiment labels is established by these computational checks.

## Historical-classifier follow-up

Four actual detector definitions were refitted on the original 37,462 input texts. None matches every saved historical label; detailed differences are in HISTORICAL_CLASSIFIER_RECOVERY.md. The original kfsppororosplit.xlsx text column exactly matches the prediction workbook for every record. The new historical-label import completed, verified all 27,294 primary raw IDs and their text/demographic metadata, and preserves the 18,635 / 18,630 frozen primary samples. The historical NLP branch dry-run passes; the additional branch-isolation test brings the suite to eight passing tests. No additional NLP inference or classifier tuning was performed.
