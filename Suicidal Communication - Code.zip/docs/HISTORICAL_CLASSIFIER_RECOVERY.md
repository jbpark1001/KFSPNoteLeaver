# Historical primary classifications: recovery and use

## What was recovered

The saved `pred_label` and `p_summarized` columns in the original `summarizedrawnotes.xlsx` classify all 37,462 eligible documents as **27,294 raw and 10,168 summarized**. The raw IDs match **every record in `raw.pkl`**, not just its row count. The associated frozen primary sections comprise 18,635 records, including 18,630 with valid age and recorded sex.

The new `10-primary-labels` stage imports these actual historical predictions into a separate branch, after verifying all 37,462 text/row identities, probability-to-label consistency, all raw IDs, and the available metadata/text for the primary feature records. It does not substitute manually assigned labels, invent classifier predictions or pretend to refit an unidentified model.

```powershell
& 'C:/anaconda3/envs/NLP/python.exe' run.py 10-primary-labels --text-branch historical
```

This executed successfully. Its provenance is recorded in `derived/historical_primary/classifier_provenance.json` and `outputs/validation/historical_primary_label_selection.json`. The older primary labels are now explicitly available to the rebuild workflow. The existing default saved-feature analyses already use the associated frozen cohort.

## Which training script produced them?

The exact original fitted classifier implementation has **not** been established. The phrase “older classifier” in the earlier report identified older saved predictions, rather than a recovered and verified training script.

Four successive definitions were found inside the original `Summarized and Raw Classification.py`. Each was extracted without notebook I/O and refitted using its actual defaults, the same 37,462 recorded input texts, threshold .50, rule confidence .34 and no raw-length feature. The original `kfsppororosplit.xlsx` text column was also checked directly: all 37,462 texts exactly match the saved prediction workbook.

| Original detector definition | Rules | Refit raw count | Labels differing from historical saved predictions |
|---|---:|---:|---:|
| First, class begins at original line 390 | 17 | 27,491 | 2,559 |
| Second, original line 1054 | 22 | 26,583 | 1,449 |
| Third, original line 1730 | 24 | 26,026 | 1,310 |
| Fourth, original line 2450 | 26 | 25,992 | 1,302 |

None reproduces the historical classifications, so none is designated as their original classifier. Tests used actual recorded code variants; model parameters or thresholds were not searched to force the target count.

The standalone file named `Summarized and Raw Classification (Old Version).py` has the same detector logic as the fourth definition after removing documentation/formatting differences. Its filename does not establish that it generated the historical labels. Relevant Spyder autosaves also contain the same classifier definitions; the classifier code cell recovered from the IPython history matches the first definition. No exact older fitted model file was found in the checked home-directory model artifacts.

The exact training state may have been overwritten or depended on an earlier interactive state. That remains unverified. The four observed comparisons are recorded in `outputs/validation/historical_classifier/`; original definitions and source hashes are preserved under `reference/recovered/classifier_history/` and `docs/historical_classifier_candidates.json`.

## Use the historical labels for a new text-feature rebuild

```powershell
# Review the complete branch first.
& 'C:/anaconda3/envs/NLP/python.exe' run.py nlp-rebuild-primary --dry-run

# Uses verified historical predictions, then rebuilds segmentation and NLP.
& 'C:/anaconda3/envs/NLP/python.exe' run.py nlp-rebuild-primary

# Analyze the explicitly rebuilt historical-label features.
& 'C:/anaconda3/envs/NLP/python.exe' run.py fig05-06 --inputs rebuilt --text-branch historical
```

Historical artifacts write to `derived/historical_primary/`; newer classifier artifacts remain in `derived/`. Rebuilt historical analysis outputs write to `outputs/rebuilt/historical_primary/`. The verified frozen saved-feature route remains unchanged. Branch isolation has a focused regression test.

Only the historical-label import and route checks were executed here; a new KSS/KeyBERT/KOTE rebuild was not run. Even with identical document classifications, different sentence splitting, tokenizers or model weights may change feature eligibility/results. The historical classifier alone is therefore not a guarantee of raw-to-paper reproduction.

## Consequences for the manuscript

Keeping the primary saved corpus means describing its actual **27,294 raw / 10,168 summarized** classification snapshot. The **25,992 / 11,470** counts and the newer detector's stability metrics belong to a separate version and cannot be presented as the filter that generated those primary features.

The older predictions agree with 78.7333% of the first 1,500 available manual annotations (78.7475% across all 1,501 usable annotations). “Historical labels used in the analyses” does not mean independently correct labels. The 80.5% manual-agreement claim remains unreproduced. No manuscript wording was changed automatically.
