# Replication status and issues requiring scientific reconciliation

Prepared against the current main manuscript and Supplementary Methods on 9 November 2026. This project organizes the relevant supplied scripts, recovers additional upstream originals and adds missing executable stages. It does not certify that every manuscript statement follows from one coherent raw-data pipeline.

## Historical-classifier follow-up

The saved older labels are now recovered as an explicit required input and imported by `10-primary-labels --text-branch historical`. They match all 27,294 raw-feature IDs and the frozen 18,635 / 18,630 primary samples. The exact training code remains unidentified: four actual historical definitions were refitted and none matches every saved label. See [the recovery report](HISTORICAL_CLASSIFIER_RECOVERY.md). The default saved analyses already use the historical corpus; the new branch makes its classification provenance explicit.

## Verified in this project

- All 11 enumerated registry, communication, section and linked-content denominator checks match: registry 102,922; note-positive 38,044; note-negative 59,603; unknown 5,275; known status 97,647; communication profiles 79,083; other-verbal complete cases 79,063; section-eligible 18,635; complete demographics 18,630; linked themes and sentiments each 15,163.
- The classifier refit reproduces 25,992 raw / 11,470 summarized; all 16 enumerated supplementary internal-stability claims match. The fresh classifier still gives 76.2% manual agreement on the first 1,500 annotation rows.
- Fresh dictionary-only, communication-profile, age/sex contrast, linked-theme, linked-sentiment and adjusted prevalence analyses run successfully. All 180 fitted categorical prevalence/sensitivity models reported convergence without a failure. Six specified negative Burden/Despair trends satisfy FDR P<.001.
- All 118 enumerated communication/content/prevalence, selected sensitivity and permutation numerical or significance claims match at their reported precision. The exact list and tolerances are in `outputs/validation/current_manuscript_claims.csv`. This does not cover every number or all captions.
- The primary demographic-classification theme/sentiment models were rerun. The numerical test suite independently checks parity with original model fits and the four BH families (75, 15, 225 and 45).
- The newly implemented permutation stage validates the distinct 18,648-note cohort. Its aggregation and age-model coefficients match an independently executed function from the existing sentence-model script on a synthetic numerical fixture. Joint sentence shuffling preserves within-note counts and five-theme sentence patterns. Full-cohort parity additionally checks all 279,720 binary indicators against independently generated sentence features and all 15 Love/Gratitude coefficients against independently fitted age models; the maximum coefficient difference is 2.50e-16.
- Eight focused numerical/import/branch-isolation tests pass. Original archived code files are preserved with source hashes. Source/config/runtime and model-run logs distinguish executed results from prior saved outputs.

The full 4,999-permutation corrected run reproduces the stated range and focal contrast conclusions. See `VALIDATION_RUNS.md` for the final execution record, including the complete permutation and demographic/sensitivity runs. The machine-readable result files are the evidence; the historical October report is prior evidence only.

## Unresolved source and manuscript discrepancies

| Issue | Evidence | Required resolution |
|---|---|---|
| New classifier count and primary corpus are different versions | Newer metadata gives 25,992 raw / 11,470 summarized. The saved primary section cohort contains 1,071 notes that this newer classifier labels summarized. Prior reconciliation ties the saved features to an older 27,294-raw-note version. | Specify the classifier/cohort actually used for the primary features, or rebuild all features and update results. Matching the total 18,635 alone does not resolve membership. |
| Manual agreement of 80.5% on 1,500 notes is not reproduced | Verified ID/text linkage on the first 1,500 annotation rows gives 76.2% for the newer saved classifier and 78.7333% for the older prediction workbook. All usable labels total 1,501 and give 76.2159% / 78.7475%. Neither is 80.5%. | Identify the intended independent gold set and classifier version, or correct the claim. Duplicate-text many-to-many merges are not an acceptable remedy. |
| Methods state 27 labeling functions | The recovered detector contains 26 labeling functions. | Recover the intended additional function/version or correct the function count. No arbitrary function was added. |
| Initial text eligibility exclusions are undocumented | The 37,462-document workbook is available, but the exact 582 unavailable/multilingual exclusion decisions and ordered registry-to-document inclusion manifest were not supplied. | Retain the workbook as an explicit restricted input, or supply the authoritative manifest required by stage 00. A new filter would define a new cohort. |
| Original permutation implementation/seed unavailable | The Supplementary Methods fully specify the test, but no original 4,999-draw script or seed was found in the searched study code and figure folders. | Use the transparently reconstructed implementation and explicit new seed; retain its output. Exact Monte Carlo p-value identity with an unknown original random stream is not guaranteed. |
| Software version differs | The configured installed R is 4.4.2; the manuscript states 4.4.1. Python dependencies are observed modern versions, not a recovered original-study lock. | Document the verified environment and evaluate any changes. No claim is made that modern model/tokenizer downloads reproduce the original NLP weights. |
| Complete final supplementary artifacts/captions were not supplied | Main text and methods describe eTables/eFigures but do not provide every numerical cell, dictionary table or final caption. | Compare the final artifacts to the generated outputs before submission. Earlier figure filenames preserve historical numbering. |

## Changes made in the separate copy

- Added stage registration, ordered suites, explicit prerequisites, portable path templates and claim checks for the current manuscript additions.
- Recovered upstream segmentation, classifier-stability, manual-evaluation and multiplicity originals into `reference/recovered/` without executing their notebook-style top-level workflows.
- Added the exact supplied permutation method with deterministic per-draw seeds, thread workers, source fingerprints and checkpoint/resume support. A Windows named-pipe restriction prevented the initial process-worker diagnostic attempt; the final implementation uses threads The initial full-cohort check then caught int16 section-index overflow; those preliminary outputs were rejected and archived separately. The corrected code promotes indices before multiplication and has a full-cohort-size regression test. No rejected p-values are accepted as inference.
- Removed unrelated import-time registry reads from `raw_detector.py`; a test verifies importing the detector performs no Excel reads. Stage 10 supplies data explicitly.
- Fixed the rebuilt feature writer to retain year, date, original text and section text, which downstream linkage/prevalence models require.
- Removed the linked-sentiment script's hardcoded copying of outputs into the older figure workspace. Future runs write only inside this project.
- Optimized the fixed-classifier bootstrap by resampling one prediction vector, with exact-parity tests against independent rescoring. The initial redundant stability run was stopped before the optimized rerun.
- Pointed sensitivity figures to newly generated local regression tables. They do not silently read previously exported tables from the home directory.

The raw registry and original scripts were not edited. Newly generated restricted intermediates live in this project's `derived/` and `outputs/`. The initial linked-sentiment validation run inherited the original script's external aggregate-output copy; that copying was removed from this package immediately after the path audit.

The earlier October audit also documents discrepancies involving clustering and transition results in an older manuscript. Those analyses are preserved as legacy/reference code, but the current supplied manuscript does not report those results, so they are not treated as current-paper replication failures.
