# Current manuscript to executable code

The main manuscript and Supplementary Methods are reference specifications, not execution instructions. The user's request authorizes this separate replication project. Earlier manuscript analyses are retained where useful, but are not silently presented as current results.

| Current analysis | Stage / source | Inputs and dependencies | Output |
|---|---|---|---|
| Population and analysis denominators | `audit-inputs` | full registry, saved primary features, text metadata | `outputs/validation/cohort_checks.csv` |
| Predictor selection, eight subsets and eTable 1 | `01-clean-demographics` → `02-select-subsets` → `03-compare-models` | full demographic source; generated cleaned data and all eight cuts | `derived/cuts/`, `outputs/tables/model_fit_summary.csv` |
| Final note-documentation model, Figure 2 | `04-final-model` → `05-demographic-plots` | generated Cut_2 (50 columns), manuscript Subset 3 | `outputs/tables/`, `outputs/figures/` |
| Classifier construction and stability | `10-classify --stability --weak-holdout` | original eligible notes; sklearn classifier/rules | `derived/scored_notes.pkl`, classifier tables |
| Manual document-type agreement | `validate-classifier` | original annotation/prediction files, saved scores | `outputs/validation/document_classifier_manual_agreement.json` |
| Primary sections, KeyBERT, sentiments | `11-segment` → `12-keywords` → `13-sentiments` → `17-build-primary-features` | new classifier output, external models and checkpoint | `derived/`; rebuilt profile is explicit |
| Dictionary-only extraction alternatives | `dictionary-sensitivity` | saved section text/features, original dictionaries, cached KLUE tokenizer | `outputs/dictionary_only_sensitivity/` |
| Four communication profiles and exact text–registry linkage | `communication-profiles` | registry, saved themes, three dictionary feature tables | `outputs/communication_profiles/` |
| Standardized age-profile differences | `communication-age-contrasts` | registry; categorical-age multinomial model | `adjusted_age_profile_contrasts.csv`; BH across two focal age contrasts |
| Overall and within-age sex comparisons | `communication-sex` | registry; multinomial age×sex + year | `outputs/communication_profiles/sex_analysis/`; BH families 4 and 20 |
| Age-specific verbal–note association adjusting other verbal signs | `communication-sensitivity` | registry; completed communication summary | `mutually_adjusted_verbal_age_associations.csv`, `robustness_summary.json` |
| Linked thematic content | included in `communication-profiles` | unique exact matches; 5 themes × 3 methods | `note_content_bridge_models.csv`; BH family 15 |
| Linked sentiments and sensitivities | `verbal-sentiments` | unique exact registry/sentiment matches | `outputs/verbal_sentiment_bridge_20261106/all_sentiment_models.csv`; BH family 15 within each specification |
| Section-specific adjusted theme prevalence and ordered trends | `content-prevalence` | frozen complete-case themes/sentiments, dictionary feature tables | `outputs/direct_content_prevalence/`; theme trend family 15 |
| Primary demographic-classification features, Figures 5/6 | `fig05-06` | frozen saved features, or explicit rebuilt branch | `outputs/figures/fig05_06/`; four BH families 75/15/225/45 |
| Four sections, ≥5 sentences and sentence-relative position; eFigures 1–4 | `14-section-robustness`, `15-sentence-robustness`, then `ed03-06` and `ed03e` | saved section/sentence annotations; raw filter from corresponding metadata | `outputs/tables/section_robustness/`, `sentence_robustness/`; nominal Wald sensitivity tests |
| 4,999 joint sentence-order permutations | `sentence-order-permutation` | saved sentence flags, matching metadata, distinct n=18,648 | `outputs/tables/sentence_order_permutation/B4999_seed20261109/`; ten Holm tests |
| Current communication and linked-content figure layouts | `communication-figure`, `sex-specific-age-contrasts` → `communication-age-sex-figure`, `verbal-content-figure` | newly generated aggregate tables | `outputs/publication_communication_figures/` |
| Enumerated manuscript numerical comparisons | `tools/verify_manuscript_claims.py` | new model outputs | `outputs/validation/current_manuscript_claims.csv` |
| Descriptive proportions, eFigures 5–8 | `ed07-10` | saved proportion summary | `outputs/figures/ed07_10/`; old numbering retained in source |

`run.py current` orders the current saved-cohort stages. It does not include new NLP inference or silently merge a rebuilt cohort. `run.py nlp-rebuild` is separate. `run.py legacy-figures` contains the earlier geography/monthly/lexical/clustering/transition/PCA stages. Those scripts provide traceability to older figures; the supplied current manuscript has no corresponding clustering/transition results. `reference/19_*` are earlier exploratory analyses and are not substitutes for the supplied permutation specification.

The current main manuscript and pasted methods do not include complete figure captions, eTable 1 numerical entries, or eTable 2 as a separate artifact. Exact final panel numbering/design and every supplementary cell cannot be verified from these texts alone. The original Korean thematic dictionaries are preserved in the archived source and reused directly.

## Explicit historical primary-label branch

`10-primary-labels --text-branch historical` imports the verified saved historical predictions and checks every raw-note ID against the frozen primary features. `nlp-rebuild-primary` uses these labels for subsequent segmentation/NLP stages with isolated outputs. The newer `10-classify` stage remains available for the distinct 25,992-raw-note classifier. The historical branch does not claim the exact original fitted classifier was recovered; see HISTORICAL_CLASSIFIER_RECOVERY.md.
