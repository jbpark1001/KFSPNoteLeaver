"""Run a named manuscript analysis, with explicit inputs and local logs."""
import argparse
import ast
from datetime import datetime
import json
import os
from pathlib import Path
import subprocess
import shutil
import sys
from project import ROOT, input_path, derived_path

STAGES = {
    '01-clean-demographics': ('scripts/01_reorganize_demographic_data.py', ['demographic_source']),
    '02-select-subsets': ('scripts/02_select_predictor_subsets.py', ['@derived/cleaned_demographic_data.xlsx']),
    '03-compare-models': ('scripts/03_compare_logistic_models.R', ['@derived/cuts/Cut_0_DF_32Columns.xlsx','@derived/cuts/Cut_1_DF_43Columns.xlsx','@derived/cuts/Cut_2_DF_50Columns.xlsx','@derived/cuts/Cut_3_DF_58Columns.xlsx','@derived/cuts/Cut_4_DF_68Columns.xlsx','@derived/cuts/Cut_5_DF_84Columns.xlsx','@derived/cuts/Cut_6_DF_97Columns.xlsx','@derived/cuts/Cut_7_DF_143Columns.xlsx']),
    '04-final-model': ('scripts/04_final_logistic_regression.R', ['@derived/cuts/Cut_2_DF_50Columns.xlsx']),
    '05-demographic-plots': ('scripts/05_plot_demographic_results.py', ['@outputs/tables/or_table_Cut_2_DF_50Columns.xlsx','@outputs/tables/var_tests_Cut_2_DF_50Columns.xlsx']),
    '10-classify': ('text_analysis/10_classify_notes.py', ['eligible_notes']),
    '11-segment': ('text_analysis/11_segment_notes.py', ['@derived/scored_notes.pkl']),
    '12-keywords': ('text_analysis/12_extract_keywords.py', ['@derived/sectioned_notes.pkl','@derived/sentences.pkl']),
    '13-sentiments': ('text_analysis/13_extract_sentiments.py', ['@derived/keyword_notes.pkl','@derived/keyword_sentences.pkl','kote_checkpoint']),
    '14-section-robustness': ('text_analysis/14_section_robustness.py', ['section_annotations']),
    '15-sentence-robustness': ('text_analysis/15_sentence_robustness.py', ['section_annotations','sentence_annotations']),
    '16-transition-tables': ('text_analysis/16_transition_tables.py', ['raw_features','sentiment_features']),
    '17-build-primary-features': ('text_analysis/17_build_primary_features.py', ['@derived/annotated_notes.pkl']),
    'fig01a': ('figures/fig01a_geography.py', ['registry','population','shapefile']),
    'fig01b': ('figures/fig01b_monthly.py', ['registry']),
    'fig02-saved': ('figures/fig02_saved_model.py', ['existing_odds_ratios','existing_factor_tests']),
    'fig03': ('figures/fig03_lexical_profile.py', ['noun_counts','verb_counts']),
    'fig04': ('figures/fig04_cluster_centroids.py', ['theme_clusters','sentiment_clusters']),
    'fig05-06': ('figures/fig05_06_association_heatmaps.py', ['raw_features','sentiment_features']),
    'fig05-06-lines': ('figures/fig05_06_association_lines.py', ['@outputs/figures/fig05_06/figure6a_theme_heatmap_estimates.csv','@outputs/figures/fig05_06/figure6b_sentiment_heatmap_estimates.csv']),
    'fig07': ('figures/fig07_transitions.py', ['theme_clusters','sentiment_clusters']),
    'ed01': ('figures/ed01_monthly_counts.py', ['registry']),
    'ed02': ('figures/ed02_pca_projections.py', ['theme_clusters','sentiment_clusters']),
    'ed03-06': ('figures/ed03_06_robustness_panels.py', ['section_results','sentence_results']),
    'ed03e': ('figures/ed03e_real_vs_shuffled.py', ['section_results','sentence_results']),
    'ed07-10': ('figures/ed07_10_descriptive_proportions.py', ['proportion_summary']),

}

# Current manuscript additions, absent from the earlier launcher.
DICT = ['@outputs/dictionary_only_sensitivity/'+m+'_features.pkl' for m in ['keybert_saved','dictionary_all_tokens','dictionary_substring']]
STAGES.update({
    '10-primary-labels': ('tools/use_historical_primary_labels.py', ['manual_predictions','raw_features','eligible_notes']),
    'verify-classifier-stability': ('tools/verify_classifier_stability.py', ['@outputs/tables/classifier_summary_report.csv','@outputs/tables/classifier_threshold_sensitivity.csv']),
    'validate-permutation-observed': ('tools/validate_permutation_observed.py', ['sentence_flags','@outputs/tables/sentence_robustness/sent_real_third_sentence_theme_features_df.csv','@outputs/tables/sentence_robustness/sent_real_third_sentence_theme_age_results.csv']),
    'verify-demographic-refit': ('tools/verify_demographic_refit.py', ['existing_odds_ratios','@outputs/tables/or_table_Cut_2_DF_50Columns.xlsx']),
    '00-eligible-notes': ('text_analysis/00_prepare_eligible_notes.py', ['demographic_source']),
    'verify-claims': ('tools/verify_manuscript_claims.py', ['@outputs/communication_profiles/note_content_bridge_models.csv','@outputs/communication_profiles/mutually_adjusted_verbal_age_associations.csv','@outputs/communication_profiles/sex_analysis/primary_profiles_by_sex.csv','@outputs/direct_content_prevalence/adjusted_prevalence_by_age.csv','@outputs/verbal_sentiment_bridge_20261106/all_sentiment_models.csv']),
    'audit-inputs': ('tools/audit_current_inputs.py', ['demographic_source','raw_features','sentiment_features','eligible_notes','section_annotations','sentence_flags']),
    'validate-classifier': ('tools/validate_document_classifier.py', ['manual_labels','manual_predictions','saved_scores']),
    'dictionary-sensitivity': ('tools/dictionary_only_sensitivity.py', ['raw_features','theme_clusters']),
    'communication-profiles': ('tools/analyze_communication_profiles.py', ['demographic_source','raw_features',*DICT]),
    'communication-age-contrasts': ('tools/test_communication_age_trends.py', ['demographic_source']),
    'communication-sex': ('tools/analyze_communication_sex.py', ['demographic_source']),
    'communication-sensitivity': ('tools/check_communication_sensitivity.py', ['demographic_source','@outputs/communication_profiles/summary.json']),
    'verbal-sentiments': ('tools/analyze_verbal_sentiment_bridge.py', ['demographic_source','sentiment_features']),
    'content-prevalence': ('tools/analyze_direct_content_prevalence.py', ['raw_features','sentiment_features',*DICT]),
    'sentence-order-permutation': ('text_analysis/18_sentence_order_permutation.py', ['sentence_flags','section_annotations']),
    'communication-figure': ('tools/plot_combined_age_sex_stacked.py', ['@outputs/communication_profiles/primary_explicit_profiles_by_age.csv','@outputs/communication_profiles/adjusted_age_profile_contrasts.csv','@outputs/communication_profiles/sex_analysis/primary_adjusted_sex_differences.csv']),
    'sex-specific-age-contrasts': ('tools/plot_sex_specific_age_contrast_options.py', ['demographic_source','@outputs/communication_profiles/sex_analysis/primary_adjusted_age_sex_profiles.csv','@outputs/communication_profiles/sex_analysis/primary_sex_differences_within_age.csv']),
    'communication-age-sex-figure': ('tools/draw_clean_communication_pair.py', ['@outputs/publication_communication_figures/age_contrast_options/sex_specific_age_contrasts.csv','@outputs/communication_profiles/sex_analysis/primary_adjusted_age_sex_profiles.csv']),
    'verbal-content-figure': ('tools/draw_all_verbal_content_results.py', ['@outputs/communication_profiles/note_content_bridge_models.csv','@outputs/verbal_sentiment_bridge_20261106/primary_sentiment_results.csv']),
})
SAVED_ONLY = set(STAGES) - {'01-clean-demographics','02-select-subsets','03-compare-models','04-final-model','05-demographic-plots','10-classify','11-segment','12-keywords','13-sentiments','14-section-robustness','15-sentence-robustness','17-build-primary-features','fig05-06','fig05-06-lines','ed03-06','ed03e'}
SUITES = {
    'nlp-rebuild-primary': ['10-primary-labels','11-segment','12-keywords','13-sentiments','17-build-primary-features'],
    'current': ['audit-inputs','01-clean-demographics','02-select-subsets','03-compare-models','04-final-model','verify-demographic-refit','05-demographic-plots','dictionary-sensitivity','communication-profiles','communication-age-contrasts','communication-sex','communication-sensitivity','verbal-sentiments','content-prevalence','fig05-06','14-section-robustness','15-sentence-robustness','ed03-06','ed03e','validate-permutation-observed','sentence-order-permutation','communication-figure','sex-specific-age-contrasts','communication-age-sex-figure','verbal-content-figure','ed07-10','validate-classifier','verify-claims'],
    'nlp-rebuild': ['10-classify','11-segment','12-keywords','13-sentiments','17-build-primary-features'],
    'legacy-figures': ['fig01a','fig01b','fig02-saved','fig03','fig04','fig07','ed01','ed02','ed07-10'],
}

def needed(key):
    if key.startswith('@derived/') and os.environ.get('MANUSCRIPT_TEXT_BRANCH')=='historical':
        return derived_path(key[len('@derived/'):])
    if key.startswith(('@outputs/figures/', '@outputs/tables/transitions/')) and os.environ.get('MANUSCRIPT_INPUT_PROFILE')=='rebuilt':
        base='outputs/rebuilt/historical_primary' if os.environ.get('MANUSCRIPT_TEXT_BRANCH')=='historical' else 'outputs/rebuilt'
        return ROOT/base/key[len('@outputs/'):]
    return ROOT / key[1:] if key.startswith('@') else input_path(key)

def preflight():
    results=[]
    for name,(script,keys) in STAGES.items():
        missing=[str(needed(k)) for k in keys if not needed(k).exists()]
        results.append({'stage':name,'script':script,'inputs_present':not missing,'missing':missing})
        print(f"{name:26} {'INPUTS PRESENT' if not missing else 'MISSING INPUTS'}")
        for path in missing: print('  '+path)
    for directory in ('scripts','figures','text_analysis','tools'):
        for path in (ROOT/directory).glob('*.py'):
            ast.parse(path.read_text(encoding='utf-8-sig'),filename=str(path))
    (ROOT/'docs/preflight.json').write_text(json.dumps(results,indent=2),encoding='utf-8')
    print('Python syntax checks passed. Input presence does not establish statistical reproducibility.')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('stage',choices=['list','check',*STAGES,*SUITES])
    parser.add_argument('--dry-run',action='store_true')
    parser.add_argument('--inputs', choices=['saved','rebuilt'], default='saved',
                        help='Published saved snapshots or explicitly rebuilt features/robustness outputs')
    parser.add_argument('--text-branch',choices=['newer','historical'],default='newer',help='Historical primary labels or newer classifier rebuild')
    args,extra=parser.parse_known_args()
    if args.stage=='nlp-rebuild-primary':args.text_branch='historical'
    os.environ['MANUSCRIPT_TEXT_BRANCH']=args.text_branch
    derived_path('.').mkdir(parents=True,exist_ok=True)
    if args.stage=='10-classify' and args.text_branch=='historical':
        raise SystemExit('Use 10-primary-labels for verified historical labels; 10-classify fits the newer detector.')
    os.environ['MANUSCRIPT_INPUT_PROFILE']=args.inputs
    for folder in ('docs','derived','outputs/logs','outputs/tables','outputs/figures'):
        (ROOT/folder).mkdir(parents=True,exist_ok=True)
    if args.stage in SUITES:
        if extra: raise SystemExit('Run individual stages to pass stage-specific arguments.')
        for stage in SUITES[args.stage]:
            command=[sys.executable,str(ROOT/'run.py'),stage,'--inputs',args.inputs,'--text-branch',args.text_branch]
            if args.dry_run:command.append('--dry-run')
            subprocess.run(command,cwd=ROOT,check=True)
        return
    if args.stage=='list':
        for name,(script,_) in STAGES.items(): print(f'{name:26} {script}')
        return
    if args.stage=='check':
        preflight(); return
    if args.inputs=='rebuilt' and args.stage in SAVED_ONLY:
        raise SystemExit('This stage requires the frozen saved cohort. A rebuilt cohort needs separate reconciliation; see docs/REPLICATION_STATUS.md.')
    script,keys=STAGES[args.stage]
    runtime=json.loads((ROOT/'config/runtime.json').read_text(encoding='utf-8'))
    configured=runtime['rscript' if script.endswith('.R') else 'python']
    exe=shutil.which(configured) or configured
    command=[exe,str(ROOT/script),*extra]
    print(subprocess.list2cmdline(command),flush=True)
    if args.dry_run:return
    missing=[str(needed(k)) for k in keys if not needed(k).exists()]
    if missing: raise SystemExit('Missing inputs:\n'+'\n'.join(missing)+'\nSee config/paths.json and docs/REPRODUCIBILITY.md.')
    if not Path(exe).is_file():raise SystemExit('Runtime not found; update config/runtime.json.')
    env=os.environ.copy();env.update(PYTHONUNBUFFERED='1',OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLBACKEND='Agg',PYTHONUTF8='1',PYTHONIOENCODING='utf-8',MANUSCRIPT_PYTHON=runtime['python'],MANUSCRIPT_PROJECT_ROOT=str(ROOT))
    stamp=datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    # R reads expressions incrementally. Freeze its source before execution so
    # edits in the working file cannot corrupt a long-running profile-CI job.
    if script.endswith('.R'):
        snapshot=ROOT/'outputs/logs/source_snapshots'/f'{stamp}_{Path(script).name}'
        snapshot.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(ROOT/script,snapshot)
        command[1]=str(snapshot)
    log=ROOT/'outputs/logs'/f'{stamp}_{args.stage}.log'
    with log.open('w',encoding='utf-8') as handle:
        handle.write('Input profile: '+args.inputs+'\n');handle.flush()
        result=subprocess.run(command,cwd=ROOT,env=env,stdout=handle,stderr=subprocess.STDOUT)
    print('Log:',log)
    if result.returncode:raise SystemExit(f'Stage failed ({result.returncode}). Read the log above.')
    print('Completed',args.stage)

if __name__=='__main__':main()
