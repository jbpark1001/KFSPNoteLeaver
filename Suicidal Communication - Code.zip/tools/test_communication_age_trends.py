"""Test the two age patterns in panel b, with adjusted probability contrasts."""
from analyze_communication_profiles import *
from scipy.stats import norm


def main():
    source=pd.read_pickle(input_path('demographic_source'))
    d=valid(prepare(source))
    model,design=fit_mn(d,'C(AGE2) + C(SEX) + C(YEAR)')
    groups=d.groupby(['SEX','YEAR']).size().rename('weight').reset_index()
    weights=groups.weight.to_numpy()/len(d)
    probs={};gradients={}
    for age in AGE:
        grid=groups.assign(AGE2=age)
        x=np.asarray(patsy.build_design_matrices([design.design_info],grid)[0])
        p=np.asarray(model.predict(x))
        for k in [1,2]:
            probs[age,k]=weights@p[:,k]
            gradients[age,k]=np.column_stack([
                np.sum((weights*p[:,k]*((k==j)-p[:,j]))[:,None]*x,axis=0)
                for j in range(1,4)]).ravel(order='F')
    cov=np.asarray(model.cov_params())
    contrasts=[]
    for k in [1,2]:
        for older,younger in [(2,1),(3,2),(4,3),(5,4),(5,2)]:
            diff=probs[older,k]-probs[younger,k]
            gradient=gradients[older,k]-gradients[younger,k]
            se=np.sqrt(gradient@cov@gradient)
            contrasts.append({'profile':PROFILES[k],'younger':AGE[younger],'older':AGE[older],
                'family':'adjacent_age_groups' if older-younger==1 else '65plus_vs_19to34',
                'younger_adjusted_percent':100*probs[younger,k],'older_adjusted_percent':100*probs[older,k],
                'difference_percentage_points':100*diff,'ci_lower_pp':100*(diff-1.96*se),
                'ci_upper_pp':100*(diff+1.96*se),'z':diff/se,'p':2*norm.sf(abs(diff/se))})
    table=pd.DataFrame(contrasts)
    table['q_BH']=table.groupby('family').p.transform(lambda a:multipletests(a,method='fdr_bh')[1])
    table.to_csv(OUT/'adjusted_age_profile_contrasts.csv',index=False)
    trends=[]
    for k in [1,2]:
        a=d.copy();a['focal_profile']=a.profile.eq(k).astype(int)
        result=check(smf.glm('focal_profile ~ AGE2 + C(SEX) + C(YEAR)',a,family=sm.families.Binomial()).fit())
        b=result.params['AGE2'];lo,hi=result.conf_int().loc['AGE2']
        trends.append({'profile':PROFILES[k],'n':len(a),'OR_per_ordered_age_category':float(np.exp(b)),
            'ci_lower':float(np.exp(lo)),'ci_upper':float(np.exp(hi)),
            'p':float(result.pvalues['AGE2']),'z':float(result.tvalues['AGE2'])})
    trend=pd.DataFrame(trends);trend['q_BH_two_trends']=multipletests(trend.p,method='fdr_bh')[1]
    trend.to_csv(OUT/'ordered_age_trend_tests.csv',index=False)
    note='''AGE TRENDS IN ADJUSTED COMMUNICATION PROFILES, PANEL B
Exploratory follow-up, 4 November 2026

Same primary sample: 79,083 decedents with explicit NOTE_EX and WARNSPEAK1
yes/no status plus valid demographics. The verbal item combines talk about
suicide, homicide, or death. Note only means without this specific indicator.

Probability contrasts use the same categorical-age multinomial model and
common sex/year standardization as panel b. Difference CIs use the full
model covariance and analytic delta-method gradients, accounting for the
fact that age-specific adjusted probabilities come from the same model.
Pointwise 95% CIs are reported. Two-sided p-values receive BH correction
within two families: eight adjacent-age contrasts, and two contrasts between
65+ and 19-34 (one for each of note-only and verbal-only).

Separate binomial models compare each focal profile with the other three
profiles combined, adjusting for categorical sex and year. AGE2 is entered
as ordered scores 1,2,3,4,5. These two trend tests receive BH correction
together. The per-category OR is not an effect per year of chronological
age: category intervals differ. An ordered trend does not imply that every
adjacent age comparison is significant, and it does not establish causation.

Adjusted probability differences:
'''+table.to_string(index=False)+'\n\nOrdered trend models:\n'+trend.to_string(index=False)+'''

The verbal-only adjusted percentage dips from <=18 to 19-34, then rises
across the adult groups. The note-only percentage is nearly identical in
those two youngest groups, then declines. Hence the verbal-only series is
not strictly increasing across all five categories, nor is the note-only
series strictly decreasing across all five. Statistical trends and specific
adult-group contrasts should be distinguished from strict monotonicity.

All estimates concern recorded profiles among complete-response decedents.
Missingness, reporting differences and observational limitations from the
main communication analysis still apply. No other verbal categories or
clinical exposures were added as covariates because these tests correspond
specifically to panel b's sex/year-adjusted distributions.
'''
    (OUT/'AGE_TREND_RESULTS.txt').write_text(note,encoding='utf-8')
    print(table.to_json(orient='records',indent=2))
    print(trend.to_json(orient='records',indent=2))


if __name__=='__main__':
    with threadpool_limits(limits=4):main()
