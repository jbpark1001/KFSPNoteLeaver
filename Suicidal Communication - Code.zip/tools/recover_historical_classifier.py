"""Refit an actual historical code version and compare every saved label.

Version numbers identify successive detector definitions in the original
notebook-style .py file, not a search over newly chosen model parameters.
"""
from pathlib import Path
import argparse,sys,json,importlib,hashlib
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import ROOT,input_path,output_path
sys.path.insert(0,str(ROOT/'text_analysis'))

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--version',type=int,choices=[1,2,3,4,5],required=True)
    p.add_argument('--normalize-parent-spacing',action='store_true',help='Explicit alternative input preprocessing; never silently applied')
    args=p.parse_args()
    module=importlib.import_module(f'historical_detector_v{args.version}')
    saved=pd.read_excel(input_path('manual_predictions'))
    ids=pd.to_numeric(saved.iloc[:,0],errors='raise').astype(int)
    assert ids.is_unique and np.array_equal(ids.to_numpy(),np.arange(len(saved)))
    notes=saved[['NOTE_CONTENTDTL']].copy();notes.index=ids
    assert notes.NOTE_CONTENTDTL.notna().all()
    if args.normalize_parent_spacing:notes.NOTE_CONTENTDTL=notes.NOTE_CONTENTDTL.str.replace('엄마아빠','엄마 아빠',regex=False)
    label=saved.pred_label.to_numpy();prob=saved.p_summarized.to_numpy()
    raw=pd.read_pickle(input_path('raw_features'))
    assert raw.index.is_unique
    normalize=lambda s:s.fillna('').astype(str).str.replace('엄마아빠','엄마 아빠',regex=False).to_numpy()
    assert (normalize(notes.loc[raw.index,'NOTE_CONTENTDTL'])==normalize(raw.NOTE_CONTENTDTL)).all()
    target_raw=set(ids[label=='raw'])
    assert target_raw==set(raw.index),'Historical saved labels do not define the configured raw feature cohort'
    print(f'Refitting original version {args.version}: {len(module.LABELING_FUNCTIONS)} rules, {len(notes)} documents',flush=True)
    det=module.SummarizationDetector(text_col='NOTE_CONTENTDTL',min_rule_conf=.34,use_length_feature=False)
    with threadpool_limits(limits=1):
        det.fit(notes)
        proba=det.predict_proba(notes)[:,1]
    predicted=np.where(proba>=.5,'summarized','raw')
    name=f'v{args.version}'+('_parent_spacing' if args.normalize_parent_spacing else '_original_text')
    result=dict(candidate=name,n=len(notes),rules=len(module.LABELING_FUNCTIONS),
                counts=pd.Series(predicted).value_counts().to_dict(),
                saved_target_counts=pd.Series(label).value_counts().to_dict(),
                saved_label_disagreements=int((predicted!=label).sum()),
                exact_saved_label_match=bool(np.array_equal(predicted,label)),
                raw_ids_match_saved_features=set(ids[predicted=='raw'])==set(raw.index),
                max_probability_difference=float(np.max(abs(proba-prob))),
                preprocessing='mother/father spacing normalized' if args.normalize_parent_spacing else 'recorded historical workbook text unchanged',
                parameters='original defaults; min_rule_conf=.34; use_length_feature=False; threshold=.5',
                historical_script_sha256=hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest())
    manual=saved.head(1500)['Manual Label'].astype('string').str.strip().str.upper().map({'R':'raw','S':'summarized'})
    keep=manual.notna();result['manual_n_first1500']=int(keep.sum())
    result['manual_accuracy_first1500']=float((predicted[:1500][keep.to_numpy()]==manual[keep].to_numpy()).mean())
    pd.DataFrame({'pred_label':predicted,'p_summarized':proba},index=ids).to_pickle(ROOT/f'derived/historical_classifier_{name}_scores.pkl')
    output_path(f'validation/historical_classifier/{name}.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    if result['exact_saved_label_match']:
        import joblib
        joblib.dump(det,ROOT/f'derived/historical_classifier_{name}.joblib')
    print(json.dumps(result,indent=2),flush=True)

if __name__=='__main__':main()
