"""Recorded note/verbal communication profiles, with explicit missingness.

Primary: explicit WARNSPEAK1 responses only. The codebook combines suicide,
homicide and death talk; this is not an indicator of explicit suicidal intent.
No original records, published models or figures are overwritten.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
import patsy
import statsmodels.api as sm
import statsmodels.formula.api as smf
from scipy.stats import chi2,chi2_contingency
from statsmodels.stats.multitest import multipletests
from statsmodels.stats.proportion import proportion_confint
from threadpoolctl import threadpool_limits
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

P=Path(__file__).resolve().parents[1];sys.path.insert(0,str(P))
from project import input_path
OUT=P/'outputs/communication_profiles';OUT.mkdir(parents=True,exist_ok=True)
AGE={1:'≤18',2:'19–34',3:'35–49',4:'50–64',5:'65+'}
PROFILES=['Neither recorded','Note only','Verbal only','Both recorded']
COLORS=['#b6bdc5','#4479ad','#cf9850','#5a9587']
VERBAL={'WARNSPEAK1':'Suicide/homicide/death talk','WARNSPEAK2':'Physical discomfort',
        'WARNSPEAK3':'Self-deprecating comments','WARNSPEAK4':'Other verbal signs'}
SITUATIONS={'NP_DXEX':'Recorded psychiatric diagnosis','NP_THERAPYEX':'Mental health treatment',
    'PAST_STRIAL':'Prior suicide attempt','ECONOMY_PB':'Economic problems','JOB_PB':'Job problems',
    'FAMILY_PB':'Family problems','RELATION_PB':'Relationship problems','COHABITATION_EX':'Cohabitation',
    'DRINKING_EX':'Alcohol use at death'}


def yesno(series):
    return series.map({1:1.,2:0.})


def prepare(source,field='WARNSPEAK1',legacy=False,broad=False):
    d=source.copy()
    d['note']=yesno(d.NOTE_EX)
    cols=list(VERBAL) if broad else [field]
    v=pd.concat({c:yesno(d[c]) for c in cols},axis=1)
    if legacy:
        v.loc[d.WARNSIGN_TP.eq(2),:]=0
    d['verbal']=np.where(v.eq(1).any(axis=1),1.,np.where(v.eq(0).all(axis=1),0.,np.nan))
    d['profile']=d.note+2*d.verbal
    return d


def valid(d):
    return d[d.profile.notna() & d.AGE2.isin(AGE) & d.SEX.isin([1,2]) & d.YEAR.between(2013,2020)].copy()


def check(result):
    if hasattr(result,'mle_retvals'):
        assert result.mle_retvals['converged']
    else:
        assert result.converged
    assert np.isfinite(np.asarray(result.params)).all()
    assert np.isfinite(np.asarray(result.bse)).all()
    return result


def descriptive(d,name):
    rows=[]
    for age in AGE:
        a=d[d.AGE2.eq(age)]
        for k,label in enumerate(PROFILES):
            count=int(a.profile.eq(k).sum());n=len(a)
            lo,hi=proportion_confint(count,n,method='wilson')
            rows.append({'analysis':name,'age':AGE[age],'age_code':age,'profile':label,'count':count,'n':n,
                'percent':100*count/n,'ci_lower_percent':100*lo,'ci_upper_percent':100*hi})
    frame=pd.DataFrame(rows);frame.to_csv(OUT/f'{name}_profiles_by_age.csv',index=False)
    return frame


def fit_mn(d,formula):
    x=patsy.dmatrix(formula,d,return_type='dataframe')
    m=check(sm.MNLogit(d.profile.astype(int),x).fit(method='newton',maxiter=100,disp=False))
    return m,x


def adjusted_profiles(d,m,x):
    weights=d.groupby(['SEX','YEAR']).size().rename('weight').reset_index()
    w=weights.weight.to_numpy()/len(d)
    result=[]
    for age in AGE:
        grid=weights.assign(AGE2=age)
        xx=np.asarray(patsy.build_design_matrices([x.design_info],grid)[0])
        probs=np.asarray(m.predict(xx))
        mean=w@probs
        for k in range(4):
            gradient=np.column_stack([np.sum((w*probs[:,k]*((k==j)-probs[:,j]))[:,None]*xx,axis=0) for j in range(1,4)]).ravel(order='F')
            se=np.sqrt(gradient@np.asarray(m.cov_params())@gradient)
            result.append({'age':AGE[age],'age_code':age,'profile':PROFILES[k], 'percent':100*mean[k],
                'ci_lower_percent':100*max(0,mean[k]-1.96*se),'ci_upper_percent':100*min(1,mean[k]+1.96*se)})
    out=pd.DataFrame(result);out.to_csv(OUT/'primary_adjusted_profiles_by_age.csv',index=False)
    assert np.allclose(out.groupby('age_code').percent.sum(),100)
    return out


def association(d,name):
    base=check(smf.glm('note ~ verbal + C(AGE2) + C(SEX) + C(YEAR)',d,family=sm.families.Binomial()).fit())
    inter=check(smf.glm('note ~ verbal * C(AGE2) + C(SEX) + C(YEAR)',d,family=sm.families.Binomial()).fit())
    lr=2*(inter.llf-base.llf)
    summary={'n':len(d),'counts':{label:int(d.profile.eq(k).sum()) for k,label in enumerate(PROFILES)},
        'overall_adjusted_note_verbal_OR':float(np.exp(base.params['verbal'])),
        'overall_adjusted_CI':np.exp(base.conf_int().loc['verbal']).tolist(),
        'overall_adjusted_p':float(base.pvalues['verbal']), 'age_interaction_lr':float(lr),
        'age_interaction_df':int(inter.df_model-base.df_model),'age_interaction_p':float(chi2.sf(lr,inter.df_model-base.df_model))}
    records=[]
    for age in AGE:
        vector=pd.Series(0.,index=inter.params.index);vector['verbal']=1
        if age!=1:vector[f'verbal:C(AGE2)[T.{age}]']=1
        b=float(vector@inter.params);se=float(np.sqrt(vector@inter.cov_params()@vector))
        a=d[d.AGE2.eq(age)]
        records.append({'analysis':name,'age':AGE[age],'age_code':age,'n':len(a),
            'adjusted_OR':np.exp(b),'ci_lower':np.exp(b-1.96*se),'ci_upper':np.exp(b+1.96*se),
            'note_percent_verbal_yes':100*a.loc[a.verbal.eq(1),'note'].mean(),
            'note_percent_verbal_no':100*a.loc[a.verbal.eq(0),'note'].mean()})
    tab=pd.DataFrame(records);tab.to_csv(OUT/f'{name}_note_verbal_association_by_age.csv',index=False)
    return summary,tab


def situational(d):
    records=[];models=[]
    for field,label in SITUATIONS.items():
        a=d[d[field].isin([1,2])].copy();a['situation']=yesno(a[field])
        m,x=fit_mn(a,'C(AGE2) + C(SEX) + C(YEAR) + situation')
        for j in range(3):
            b=m.params.loc['situation',j];se=m.bse.loc['situation',j]
            records.append({'variable':field,'label':label,'n':len(a),'excluded_unknown':len(d)-len(a),
                'profile_vs_neither':PROFILES[j+1],'RRR':np.exp(b),'ci_lower':np.exp(b-1.96*se),
                'ci_upper':np.exp(b+1.96*se),'p':m.pvalues.loc['situation',j]})
        for k,labelprofile in enumerate(PROFILES):
            sub=a[a.profile.eq(k)]
            models.append({'variable':field,'label':label,'profile':labelprofile,'known_n':len(sub),
                'yes_n':int(sub.situation.sum()),'percent':100*sub.situation.mean()})
        print('Situational:',field,len(a),flush=True)
    tab=pd.DataFrame(records);tab['q_BH_27']=multipletests(tab.p,method='fdr_bh')[1]
    tab.to_csv(OUT/'situational_multinomial_models.csv',index=False)
    pd.DataFrame(models).to_csv(OUT/'situational_descriptive.csv',index=False)
    return tab


def content_bridge(source):
    raw=pd.read_pickle(input_path('raw_features'))
    fields=['YEAR','SEX','AGE2','SUICIDE_DATE','NOTE_CONTENTDTL']
    def hashes(d):
        a=d[fields].copy()
        for c in fields:a[c]=a[c].astype('string').fillna('<MISSING>')
        return pd.util.hash_pandas_object(a,index=False)
    sh,rh=hashes(source),hashes(raw)
    s_unique=~sh.duplicated(keep=False);r_unique=~rh.duplicated(keep=False)
    mapping=pd.Series(source.index[s_unique],index=sh[s_unique].to_numpy())
    match=rh.map(mapping)
    match=match.where(r_unique)
    ok=match.notna()
    linked=source.loc[match.loc[ok].astype(int)].copy()
    linked.index=raw.index[ok]
    assert all((raw.loc[ok,c].astype('string').fillna('<MISSING>')==linked[c].astype('string').fillna('<MISSING>')).all() for c in fields)
    eligible=raw.too_short.eq(False)&ok
    d=prepare(linked);d=d.loc[d.index.intersection(raw.index[eligible])]
    d=valid(d)
    assert d.note.eq(1).all(), 'Content linkage included a registry non-note record'
    records=[]
    theme_names=['Sorry and Shame','Love and Gratitude','Burden','Despair','Post-mortem Affairs']
    presence=['sorrysentence_presence','loveandgratitudesentence_presence','burdensomesentence_presence','despairsentence_presence','pmaffairssentence_presence']
    for method in ['keybert_saved','dictionary_all_tokens','dictionary_substring']:
        features=pd.read_pickle(P/f'outputs/dictionary_only_sensitivity/{method}_features.pkl')
        for label,c in zip(theme_names,presence):
            a=d.copy();a['theme']=features.loc[a.index,c].map(lambda x:int(any(x)))
            fit=check(smf.glm('theme ~ verbal + C(AGE2) + C(SEX) + C(YEAR)',a,family=sm.families.Binomial()).fit())
            b=fit.params['verbal'];se=fit.bse['verbal']
            records.append({'method':method,'theme':label,'n':len(a),'verbal_yes_n':int(a.verbal.sum()),
                'OR':np.exp(b),'ci_lower':np.exp(b-1.96*se),'ci_upper':np.exp(b+1.96*se),'p':fit.pvalues['verbal'],
                'theme_percent_verbal_yes':100*a.loc[a.verbal.eq(1),'theme'].mean(),
                'theme_percent_verbal_no':100*a.loc[a.verbal.eq(0),'theme'].mean()})
    tab=pd.DataFrame(records);tab['q_BH_15']=multipletests(tab.p,method='fdr_bh')[1]
    tab.to_csv(OUT/'note_content_bridge_models.csv',index=False)
    metadata={'raw_notes':len(raw),'uniquely_exact_matched_raw':int(ok.sum()),
        'eligible_content_notes':int(raw.too_short.eq(False).sum()),'matched_eligible':int(eligible.sum()),
        'known_verbal_demographics_eligible':len(d),'linkage_fields':fields,
        'index_only_linkage_rejected':True,'rule':'unique composite exact match in both datasets; verify fields after join'}
    (OUT/'content_linkage_audit.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    return metadata


def figures(desc,adjusted,odds,situations):
    plt.rcParams.update({'font.family':'Arial','font.size':10,'pdf.fonttype':42,'svg.fonttype':'none'})
    fig,axes=plt.subplots(1,3,figsize=(16,5.6),gridspec_kw={'width_ratios':[1.15,1.15,1]})
    for ax,table,title in [(axes[0],desc,'a. Observed communication profiles'),(axes[1],adjusted,'b. Adjusted for sex and year')]:
        bottom=np.zeros(5)
        for k,label in enumerate(PROFILES):
            vals=table[table.profile.eq(label)].sort_values('age_code').percent.to_numpy()
            ax.bar(range(5),vals,bottom=bottom,color=COLORS[k],label=label,width=.7)
            for x,v,b in zip(range(5),vals,bottom):
                if v>6:ax.text(x,b+v/2,f'{v:.0f}%',ha='center',va='center',fontsize=8,color='white' if k else '#333333')
            bottom+=vals
        ax.set_xticks(range(5),AGE.values());ax.set_ylim(0,100);ax.set_ylabel('Decedents with known communication status (%)')
        ax.set_title(title,loc='left',fontweight='bold');ax.set_xlabel('Age group')
    ax=axes[2];order=odds.sort_values('age_code');y=np.arange(5)
    ax.errorbar(order.adjusted_OR,y,xerr=[order.adjusted_OR-order.ci_lower,order.ci_upper-order.adjusted_OR],fmt='o',color='#3c6f99',capsize=3)
    if (OUT/'mutually_adjusted_verbal_age_associations.csv').exists():
        ax.clear()
        other=pd.read_csv(OUT/'mutually_adjusted_verbal_age_associations.csv').sort_values('age_code')
        ax.errorbar(order.adjusted_OR,y-.09,xerr=[order.adjusted_OR-order.ci_lower,order.ci_upper-order.adjusted_OR],fmt='o',color='#3c6f99',capsize=3,label='Age, sex and year')
        ax.errorbar(other.OR,y+.09,xerr=[other.OR-other.ci_lower,other.ci_upper-other.OR],fmt='s',color='#a5733f',capsize=3,label='+ Other verbal categories')
        ax.legend(loc='upper left',bbox_to_anchor=(0,-.27),fontsize=8,frameon=False)
    ax.axvline(1,color='#777777',ls=':');ax.set_yticks(y,order.age);ax.invert_yaxis()
    ax.set_xlabel('Adjusted odds ratio for note presence\nVerbal record: yes versus no (95% CI)')
    ax.set_title('c. Note–verbal association by age',loc='left',fontweight='bold')
    for ax in axes:ax.spines[['top','right']].set_visible(False)
    handles,labels=axes[0].get_legend_handles_labels();fig.legend(handles,labels,ncol=4,loc='lower center',bbox_to_anchor=(.35,.09),frameon=False)
    fig.suptitle('Recorded note presence and reported pre-death verbal communication',fontsize=16,fontweight='bold')
    fig.text(.055,.025,'Verbal indicator: talk about suicide, homicide, or death (WARNSPEAK1). Profiles refer to this indicator, not all verbal categories.\nPrimary analysis requires explicit yes/no responses. Neither recorded does not establish absence of communication.',fontsize=9)
    fig.subplots_adjust(left=.055,right=.98,top=.85,bottom=.28,wspace=.32)
    for ext in ['png','pdf','svg']:fig.savefig(OUT/f'communication_profiles_by_age.{ext}',dpi=220)
    plt.close(fig)
    fig,axes=plt.subplots(1,3,figsize=(15,6.7),sharey=True)
    for j,label in enumerate(PROFILES[1:]):
        a=situations[situations.profile_vs_neither.eq(label)].set_index('variable').loc[list(SITUATIONS)]
        ax=axes[j];ax.errorbar(a.RRR,np.arange(len(a)),xerr=[a.RRR-a.ci_lower,a.ci_upper-a.RRR],fmt='o',color=COLORS[j+1],capsize=3)
        ax.axvline(1,color='#777777',ls=':');ax.set_xscale('log');ax.set_title(label+' vs neither recorded',fontsize=10,fontweight='bold')
        ax.set_xlim(.6,2.1);ax.set_xticks([.75,1,1.5,2],['0.75','1.0','1.5','2.0']);ax.set_xticks([],minor=True)
        ax.set_yticks(range(len(a)),list(SITUATIONS.values()));ax.set_xlabel('Relative risk ratio (95% CI), log scale')
        ax.spines[['top','right']].set_visible(False)
    axes[0].invert_yaxis();fig.suptitle('Situational and clinical correlates of recorded communication profiles',fontsize=15,fontweight='bold')
    fig.text(.25,.025,'Verbal = recorded suicide/homicide/death talk. Separate models adjusted for age, sex and year.\nEach exposure requires known yes/no status. Exploratory associations among decedents, not estimates of suicide risk.',fontsize=9)
    fig.subplots_adjust(left=.25,right=.98,top=.86,bottom=.16,wspace=.25)
    for ext in ['png','pdf','svg']:fig.savefig(OUT/f'communication_situational_profiles.{ext}',dpi=220)
    plt.close(fig)


def main():
    source=pd.read_pickle(input_path('demographic_source'))
    audit=[]
    for c in ['NOTE_EX','WARNSIGN_TP','WARNSPEAK_DK',*VERBAL,'AGE2','SEX',*SITUATIONS]:
        for value,count in source[c].value_counts(dropna=False).items():audit.append({'variable':c,'value':str(value),'n':int(count),'percent':100*count/len(source)})
    pd.DataFrame(audit).to_csv(OUT/'raw_field_completeness.csv',index=False)
    primary_all=prepare(source);primary=valid(primary_all)
    assert len(source)==102922 and source.index.is_unique
    summary={'registry_n':len(source),'note_known':int(source.NOTE_EX.isin([1,2]).sum()),
        'note_unknown':int((~source.NOTE_EX.isin([1,2])).sum()),'note_present':int(source.NOTE_EX.eq(1).sum()),
        'noteexist_disagreements_note_yes':int((source.NOTE_EX.eq(1)&source.NoteExist.eq(0)).sum()),
        'explicit_verbal_known':int(primary_all.verbal.notna().sum()),
        'both_status_known_before_demographics':int(primary_all.profile.notna().sum()),
        'parent_no_change_skipped':int(source.WARNSIGN_TP.eq(2).sum()),'analyses':{}}
    main_desc=descriptive(primary,'primary_explicit')
    assoc,odds=association(primary,'primary_explicit');summary['analyses']['primary_explicit']=assoc
    m,x=fit_mn(primary,'C(AGE2) + C(SEX) + C(YEAR)')
    null,_=fit_mn(primary,'C(SEX) + C(YEAR)')
    summary['age_profile_lrt']={'statistic':float(2*(m.llf-null.llf)), 'df':int(m.df_model-null.df_model),
        'p':float(chi2.sf(2*(m.llf-null.llf),m.df_model-null.df_model))}
    adjusted=adjusted_profiles(primary,m,x)
    for name,kwargs in [('legacy_parent_no_change_as_no',{'legacy':True}),('any_verbal_explicit',{'broad':True}),
        ('physical_discomfort',{'field':'WARNSPEAK2'}),('self_deprecating',{'field':'WARNSPEAK3'}),('other_verbal',{'field':'WARNSPEAK4'})]:
        d=valid(prepare(source,**kwargs));descriptive(d,name)
        summary['analyses'][name],_=association(d,name)
        print('Analysis',name,'n=',len(d),flush=True)
    missing=[]
    for age in AGE:
        a=primary_all[primary_all.AGE2.eq(age)&primary_all.note.notna()]
        for note in [0,1]:
            b=a[a.note.eq(note)]
            missing.append({'age':AGE[age],'note':note,'n':len(b),'verbal_known':int(b.verbal.notna().sum()),
                'verbal_unknown_percent':100*b.verbal.isna().mean()})
    pd.DataFrame(missing).to_csv(OUT/'verbal_missingness_by_age_note.csv',index=False)
    # No-assumption bounds: missing verbal yes/no can shift joint profile shares.
    bounds=[]
    for age in AGE:
        a=primary_all[primary_all.AGE2.eq(age)&primary_all.note.notna()]
        for k,label in enumerate(PROFILES):
            count=int(a.profile.eq(k).sum());unknown=int((a.verbal.isna()&a.note.eq(k%2)).sum())
            bounds.append({'age':AGE[age],'profile':label,'n_known_note':len(a),'lower_percent':100*count/len(a),
                'upper_percent':100*(count+unknown)/len(a)})
    pd.DataFrame(bounds).to_csv(OUT/'worst_case_missing_verbal_bounds.csv',index=False)
    situation=situational(primary)
    summary['content_bridge']=content_bridge(source)
    figures(main_desc,adjusted,odds,situation)
    manifest={'input_path':str(input_path('demographic_source')),'input_sha256':hashlib.sha256(input_path('demographic_source').read_bytes()).hexdigest(),
        'primary_definition':'WARNSPEAK1 explicit 1=yes / 2=no. 999999, parent skips and unknowns excluded; NOTE_EX 1/2 only.',
        'verbal_label':'Talk about suicide OR homicide OR death; not specific to suicidal intent.',
        'codebook':'Original and recoded codebooks decrypted in memory with user-supplied password; extracts saved without password.',
        'situational_models':'One multinomial model per exposure; adjust categorical age, sex and year; exclude that exposure unknowns; reference neither recorded.',
        'primary_model':'Four-category multinomial outcome adjusted for categorical age, sex and year; age probabilities standardized to common sex-year distribution; delta-method 95% CI.',
        'interaction_model':'Binomial note presence ~ verbal * age + sex + year; likelihood ratio test of interaction.',
        'content_model':'Any-section theme presence ~ verbal + age + sex + year within uniquely matched eligible notes; BH across 15 coefficients.',
        'interpretation':'Retrospective recorded communication among decedents only; neither is not actual silence; associations not predictive or causal.'}
    (OUT/'run_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (OUT/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2),flush=True)


if __name__=='__main__':
    with threadpool_limits(limits=4):main()
