"""Audit supplementary classifier-stability claims separately from manual validity."""
from pathlib import Path
import sys,json
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import ROOT,output_path

def main():
    s=pd.read_csv(ROOT/'outputs/tables/classifier_summary_report.csv').iloc[0]
    threshold=pd.read_csv(ROOT/'outputs/tables/classifier_threshold_sensitivity.csv')
    rows=[]
    claims=[('mean_pct_raw',100,69.42,2),('sd_pct_raw',100,.25,2),('ci95_low',100,68.97,2),('ci95_high',100,69.85,2),
            ('mean_delta_p_on_summarized_after_stripping_summary_cues',1,.259,3),
            ('mean_delta_p_on_raw_after_stripping_raw_cues',1,.048,3),
            ('agreement_with_LFs',100,99.62,2),('brier_vs_weak',1,.0035,4),
            ('mixture_overlap_(0=good,0.5=bad)',1,.000005,6),
            ('pairwise_agreement_to_majority',100,99.55,2),('fraction_unanimous',100,98.44,2),
            ('n_nonabstain',1,24230,0),('bootstrap_models',1,5,0),('bootstrap_B',1,200,0)]
    for col,scale,expected,digits in claims:
        actual=float(s[col])*scale;tol=.5*10**(-digits)+1e-12
        rows.append(dict(claim=col,actual=actual,reported=expected,tolerance=tol,status='match' if abs(actual-expected)<=tol else 'mismatch'))
    for label,actual,expected in [('threshold_raw_min_percent',100*threshold.pct_raw.min(),69.01),('threshold_raw_max_percent',100*threshold.pct_raw.max(),70.05)]:
        rows.append(dict(claim=label,actual=actual,reported=expected,tolerance=.005,status='match' if abs(actual-expected)<=.005+1e-12 else 'mismatch'))
    pd.DataFrame(rows).to_csv(output_path('validation/classifier_stability_claims.csv'),index=False)
    report={'claims':len(rows),'counts':pd.Series([r['status'] for r in rows]).value_counts().to_dict(),
            'interpretation':'Internal stability against fitted classifier/weak labels; independent manual agreement is a separate unresolved claim.'}
    output_path('validation/classifier_stability_claim_summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    if any(r['status']!='match' for r in rows):raise SystemExit(1)

if __name__=='__main__':main()
