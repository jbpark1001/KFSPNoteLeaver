"""Selected probability layout with one full-width age-contrast panel."""
from pathlib import Path
import re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

P=Path(__file__).resolve().parents[1]
ROOT=P/'outputs/publication_communication_figures'
OUT=ROOT/'selected_with_age_panel';OUT.mkdir(parents=True,exist_ok=True)
S=P/'outputs/communication_profiles/sex_analysis'
cells=pd.read_csv(S/'primary_adjusted_age_sex_profiles.csv')
sex_tests=pd.read_csv(S/'primary_sex_differences_within_age.csv')
age_tests=pd.read_csv(ROOT/'age_contrast_options/sex_specific_age_contrasts.csv')
age_tests=age_tests[age_tests.family.eq('endpoint')].copy()
assert len(cells)==40 and len(sex_tests)==20 and len(age_tests)==8
profiles=['Neither recorded','Note only','Verbal only','Both recorded']
colors=['#B6BDC5','#4479AD','#CF9850','#5A9587']
ages=['≤18','19–34','35–49','50–64','65+']
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.labelsize':10,
    'axes.titlesize':11,'axes.linewidth':.7,'xtick.labelsize':9,'ytick.labelsize':9,
    'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})

def star(q):return '***' if q<.001 else '**' if q<.01 else '*' if q<.05 else ''

fig=plt.figure(figsize=(11.6,12.2))
positions=[(.085,.685,.38,.225),(.585,.685,.38,.225),
           (.085,.39,.38,.225),(.585,.39,.38,.225)]
for j,(pos,profile,color) in enumerate(zip(positions,profiles,colors)):
    ax=fig.add_axes(pos)
    for sex,marker,ls,shift in [('Male','s','--',-.045),('Female','o','-',.045)]:
        d=cells[cells.profile.eq(profile)&cells.sex.eq(sex)].sort_values('age_code')
        x=np.arange(5)+shift
        ax.plot(x,d.percent,color=color,lw=1.4,ls=ls)
        ax.errorbar(x,d.percent,yerr=[d.percent-d.ci_lower_percent,d.ci_upper_percent-d.percent],
            fmt=marker,ms=5,color=color,mfc='white' if sex=='Male' else color,
            mew=1.2,capsize=2.5,lw=.9)
    for k,(_,r) in enumerate(sex_tests[sex_tests.profile.eq(profile)].sort_values('age_code').iterrows()):
        if star(r.q_BH_20):
            top=cells[cells.profile.eq(profile)&cells.age_code.eq(k+1)].ci_upper_percent.max()
            ax.text(k,top+2,star(r.q_BH_20),ha='center',fontsize=10)
    ax.set(xticks=range(5),xticklabels=ages,xlim=(-.3,4.3),ylim=(0,65),
        xlabel='Age group',ylabel='Adjusted proportion, %')
    ax.set_yticks(range(0,61,15));ax.spines[['top','right']].set_visible(False)
    ax.set_title(f'{chr(65+j)}  {profile}',loc='left',fontweight='bold',pad=10)
    ax.grid(axis='y',color='#E7E9EB',lw=.55);ax.set_axisbelow(True)

fig.text(.085,.322,'E  Age differences within sex: ≥65 vs 19–34',fontsize=11,fontweight='bold')
ax=fig.add_axes([.20,.100,.475,.195])
for j,(profile,color) in enumerate(zip(profiles,colors)):
    for sex,marker,offset in [('Male','s',-.14),('Female','o',.14)]:
        r=age_tests[age_tests.profile.eq(profile)&age_tests.sex.eq(sex)].iloc[0]
        y=j+offset
        ax.errorbar(r.difference_pp,y,
            xerr=[[r.difference_pp-r.ci_lower_pp],[r.ci_upper_pp-r.difference_pp]],
            fmt=marker,ms=5.7,color=color,mfc='white' if sex=='Male' else color,
            mew=1.2,lw=1,capsize=2.5)
        ax.text(1.08,y,f'{r.difference_pp:+.1f} ({r.ci_lower_pp:+.1f} to {r.ci_upper_pp:+.1f})',
            transform=ax.get_yaxis_transform(),va='center',fontsize=9,clip_on=False)
        q='<.001' if r.q_BH<.001 else f'{r.q_BH:.3f}'.lstrip('0')
        ax.text(1.57,y,q,transform=ax.get_yaxis_transform(),va='center',fontsize=9,clip_on=False)
ax.axvline(0,color='#777777',ls=(0,(3,3)),lw=.8)
ax.set(yticks=range(4),yticklabels=profiles,ylim=(3.6,-.6),xlim=(-20,35),
    xticks=[-20,-10,0,10,20,30],xlabel='Adjusted difference, percentage points')
ax.spines[['top','right']].set_visible(False)
ax.text(1.08,1.055,'Difference (95% CI)',transform=ax.transAxes,fontweight='bold',fontsize=9)
ax.text(1.57,1.055,'FDR P',transform=ax.transAxes,fontweight='bold',fontsize=9)
fig.suptitle('Adjusted Communication Profiles by Age and Recorded Sex',fontsize=15,fontweight='bold',y=.975)
fig.legend(handles=[Line2D([],[],color='#555555',marker='s',mfc='white',ls='--',label='Male'),
    Line2D([],[],color='#555555',marker='o',ls='-',label='Female')],
    loc='lower right',bbox_to_anchor=(.965,.018),ncol=2,frameon=False)
stem=OUT/'communication_profiles_with_age_contrasts'
for ext in ['png','pdf','svg','tiff']:
    fig.savefig(stem.with_suffix('.'+ext),dpi=600 if ext=='tiff' else 200,
        **({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tiff' else {}))
plt.close(fig)
fonts=re.findall(rb'/BaseFont\s*/([^\s/<>\[\]()]+)',stem.with_suffix('.pdf').read_bytes())
assert fonts and all(b'Arial' in f for f in fonts)
caption='''Figure. Adjusted Communication Profiles and Within-Sex Age Differences.

A-D, Adjusted proportions with neither indicator recorded (A), note presence
only (B), verbal communication only (C), and both indicators recorded (D).
Estimates derive from multinomial logistic regression including categorical age,
recorded sex, their interaction, and calendar year, standardized to the common
calendar-year distribution of 79,083 eligible decedents. Age groups are in years.
Hollow squares/dashed lines denote male and filled circles/solid lines denote
female decedents. Error bars show pointwise 95% confidence intervals.
Stars in A-D indicate female-minus-male contrasts within age after BH correction
across 20 tests: * adjusted P<.05, ** adjusted P<.01, *** adjusted P<.001.

E, Adjusted percentage-point differences comparing age 65+ with age 19-34
within each sex, estimated from the same interaction model and standardization.
Positive differences indicate higher proportions in the oldest group; negative
differences indicate lower proportions. CIs use the full covariance of both
predicted probabilities. FDR P values use BH correction across eight contrasts
(four profiles x two sexes). These intervals are pointwise, not multiplicity-
adjusted intervals. The eight comparisons remain significant after correction.
The sex-specific contrasts in E differ from the pooled sex/year-adjusted age
contrasts reported separately in the Results. E does not test every adjacent-age
comparison or a longitudinal change within individuals.

The verbal indicator combines reported talk about suicide, homicide, or death
(WARNSPEAK1). Note-only does not imply absence of other verbal communication;
neither recorded does not establish absence of communication. Unknown/skipped
responses are excluded. Additional age contrasts are exploratory.
'''
stem.with_suffix('.caption.txt').write_text(caption,encoding='utf-8')
age_tests.to_csv(OUT/'panel_E_estimates.csv',index=False)
print('Saved five-panel figure; Arial verified; no model refit.')
print(stem)
