"""Feature-as-outcome models for age-related theme/sentiment prevalence.

The frozen 18,630-record complete-case cohort is retained intentionally.
No classifier or NLP inference is rerun. This is an exploratory follow-up.
"""
from analyze_communication_profiles import *
from itertools import combinations
from scipy.special import expit
from scipy.stats import norm
import importlib.util
import re

DEST=P/'outputs/direct_content_prevalence';DEST.mkdir(parents=True,exist_ok=True)
SECTIONS=['1st_section','2nd_section','3rd_section']
SENTIMENTS={'Despair':'절망','Defeat':'패배/자기혐오','Exhaustion':'힘듦/지침',
    'Anxious':'불안/걱정','Disappointment':'안타까움/실망','Anger':'화남/분노',
    'Hatred':'증오/혐오','Resentment':'어이없음','Sadness':'슬픔','Sorrow':'서러움',
    'Gratitude':'고마움','Affection':'흐뭇함(귀여움/예쁨)','Happiness':'행복',
    'Relief':'안심/신뢰','Neutral':'없음'}
THEMES={'Sorry and Shame':'sorrysentence_presence','Love and Gratitude':'loveandgratitudesentence_presence',
    'Burden':'burdensomesentence_presence','Despair':'despairsentence_presence','Post-mortem Affairs':'pmaffairssentence_presence'}


def fit(y,x,clusters):
    m=sm.GLM(y,x,family=sm.families.Binomial()).fit(cov_type='cluster',cov_kwds={'groups':clusters})
    check(m)
    bounds=np.exp(np.asarray(m.conf_int()))
    assert np.isfinite(bounds).all() and (bounds>0).all()
    return m


def fdr(table,pcol,families,outcol):
    table[outcol]=table.groupby(families)[pcol].transform(lambda a:multipletests(a,method='fdr_bh')[1])
    return table


def main():
    raw=pd.read_pickle(input_path('raw_features'))
    d=raw[raw.too_short.eq(False)&raw.AGE2.isin(AGE)&raw.SEX.isin([1,2])].copy()
    assert len(d)==18630 and d.YEAR.between(2013,2020).all() and d.index.is_unique
    sentiments=pd.read_pickle(input_path('sentiment_features')).loc[d.index]
    assert sentiments[['SEX','AGE2','YEAR']].equals(d[['SEX','AGE2','YEAR']])
    text=d.NOTE_CONTENTDTL.astype(str).str.replace(r'\s+','',regex=True)
    clusters=pd.factorize(text)[0]
    base='C(AGE2) + C(SEX) + C(YEAR)'
    design=patsy.dmatrix(base,d,return_type='dataframe')
    trend_design=patsy.dmatrix('AGE2 + C(SEX) + C(YEAR)',d,return_type='dataframe')
    groups=d.groupby(['SEX','YEAR']).size().rename('n').reset_index();w=groups.n.to_numpy()/len(d)
    grids={age:np.asarray(patsy.build_design_matrices([design.design_info],groups.assign(AGE2=age))[0]) for age in AGE}
    means=[];pairs=[];trends=[];globaltests=[];diagnostics=[]
    for method in ['keybert_saved','dictionary_all_tokens','dictionary_substring']:
        if method=='keybert_saved':features=d
        else:features=pd.read_pickle(P/f'outputs/dictionary_only_sensitivity/{method}_features.pkl').loc[d.index]
        domains=['theme','sentiment'] if method=='keybert_saved' else ['theme']
        for domain in domains:
            labels=THEMES if domain=='theme' else SENTIMENTS
            for label,column in labels.items():
                for section,section_col in enumerate(SECTIONS):
                    if domain=='theme':y=features[column].map(lambda v:int(v[section])).to_numpy()
                    else:y=sentiments[section_col+'_sentiment'].map(lambda v:int(column in v['labels'])).to_numpy()
                    for spec in ['sex_year','sex_year_length']:
                        try:
                            if spec=='sex_year':x=design;grid=grids;weights=w
                            else:
                                # Section length affects the chance of detecting a label.
                                # Standardize over the empirical length/sex/year distribution.
                                dl=d[['AGE2','SEX','YEAR']].copy()
                                dl['log_section_chars']=np.log1p(d[section_col].str.len())
                                x=patsy.dmatrix(base+' + bs(log_section_chars, df=4, degree=3)',dl,return_type='dataframe')
                                grid={age:np.asarray(patsy.build_design_matrices([x.design_info],dl.assign(AGE2=age))[0]) for age in AGE}
                                weights=np.full(len(dl),1/len(dl))
                            m=fit(y,x,clusters);cov=np.asarray(m.cov_params());margins={}
                            keys={'method':method,'domain':domain,'feature':label,'section':section+1,'specification':spec}
                            age_indices=[i for i,c in enumerate(x.columns) if c.startswith('C(AGE2)')]
                            restriction=np.eye(x.shape[1])[age_indices]
                            test=m.wald_test(restriction,scalar=True)
                            globaltests.append({**keys,'wald_age_p':float(test.pvalue)})
                            for age in AGE:
                                xx=grid[age];p=expit(xx@np.asarray(m.params));mean=weights@p
                                g=np.sum((weights*p*(1-p))[:,None]*xx,axis=0)
                                se=np.sqrt(g@cov@g);margins[age]=(mean,g)
                                a=y[d.AGE2.eq(age)]
                                means.append({**keys,'age':AGE[age],'age_code':age,'n_age':len(a),'observed_percent':100*a.mean(),
                                    'adjusted_percent':100*mean,'ci_lower_percent':100*max(0,mean-1.96*se),
                                    'ci_upper_percent':100*min(1,mean+1.96*se)})
                            for younger,older in combinations(AGE,2):
                                a,ga=margins[younger];b,gb=margins[older];diff=b-a;g=gb-ga;se=np.sqrt(g@cov@g)
                                pairs.append({**keys,'younger':AGE[younger],'older':AGE[older],'younger_code':younger,'older_code':older,
                                    'difference_pp':100*diff,'ci_lower_pp':100*(diff-1.96*se),'ci_upper_pp':100*(diff+1.96*se),
                                    'p':2*norm.sf(abs(diff/se))})
                            diagnostics.append({**keys,'status':'ok','n':len(y),'positive':int(y.sum())})
                        except Exception as e:
                            diagnostics.append({'method':method,'domain':domain,'feature':label,'section':section+1,
                                'specification':spec,'status':'failed','error':str(e)})
                            print('Fit failed:',domain,label,section+1,spec,str(e),flush=True)
                    # Ordered-bin trend, distinct from the categorical model.
                    try:
                        mt=fit(y,trend_design,clusters)
                        ci=mt.conf_int().loc['AGE2'];b=mt.params['AGE2']
                        trends.append({'method':method,'domain':domain,'feature':label,'section':section+1,
                            'OR_per_ordered_group':np.exp(b),'ci_lower':np.exp(ci.iloc[0]),'ci_upper':np.exp(ci.iloc[1]),
                            'p':mt.pvalues['AGE2']})
                    except Exception as e:print('Trend failed:',label,section,str(e),flush=True)
                print('Completed',method,domain,label,flush=True)
    prevalence=pd.DataFrame(means)
    paired=fdr(pd.DataFrame(pairs),'p',['method','domain','specification'],'q_BH_all_age_contrasts')
    trend=fdr(pd.DataFrame(trends),'p',['method','domain'],'q_BH_trends')
    globaltest=fdr(pd.DataFrame(globaltests),'wald_age_p',['method','domain','specification'],'q_BH_age_tests')
    prevalence.to_csv(DEST/'adjusted_prevalence_by_age.csv',index=False)
    paired.to_csv(DEST/'all_age_pairwise_differences.csv',index=False)
    trend.to_csv(DEST/'ordered_age_trend_tests.csv',index=False)
    globaltest.to_csv(DEST/'global_age_tests.csv',index=False)
    pd.DataFrame(diagnostics).to_csv(DEST/'model_diagnostics.csv',index=False)
    summary={'n':len(d),'age_counts':d.AGE2.value_counts().sort_index().to_dict(),'unique_normalized_texts':len(set(clusters)),
        'models_ok':sum(v['status']=='ok' for v in diagnostics),'models_failed':sum(v['status']!='ok' for v in diagnostics),
        'primary':'KeyBERT saved flags; feature presence outcome; categorical age, sex and year; common sex/year standardization.',
        'length_sensitivity':'Add cubic B-spline in log(1+section characters), df=4; standardize over common empirical length/sex/year distribution.',
        'covariance':'Cluster robust by whitespace-normalized full recorded text; 95% delta-method pointwise intervals.',
        'multiplicity':'Separate BH families per method/domain/specification: 15 theme/45 sentiment age tests; 150 theme/450 sentiment pairwise tests. Trends separate 15/45 test families per method/domain.',
        'cohort':'Frozen saved primary complete-case corpus; not rebuilt from the newer 25,992 raw classification.',
        'interpretation':'Age-related recorded-text label prevalence; no within-person aging effect, no validated psychiatric symptom prevalence, no proof each text is a single original note.'}
    (DEST/'run_manifest.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    draw(prevalence)
    print(json.dumps(summary,indent=2),flush=True)


def draw(prevalence):
    plt.rcParams.update({'font.family':'Arial','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none'})
    for domain,features,stem in [('theme',list(THEMES),'theme_prevalence'),
        ('sentiment',['Defeat','Exhaustion','Happiness','Neutral','Disappointment','Sadness'],'sentiment_prevalence')]:
        fig,axes=plt.subplots(2,3,figsize=(13,8.5))
        for i,(ax,label) in enumerate(zip(axes.flat,features)):
            a=prevalence[(prevalence.method=='keybert_saved')&(prevalence.domain==domain)&
                (prevalence.feature==label)&(prevalence.specification=='sex_year')]
            for section,color,marker in [(1,'#777777','o'),(2,'#76a2cb','s'),(3,'#275b8b','D')]:
                t=a[a.section.eq(section)].sort_values('age_code');x=np.arange(5)+(section-2)*.04
                ax.plot(x,t.adjusted_percent,color=color,lw=1)
                ax.errorbar(x,t.adjusted_percent,yerr=[t.adjusted_percent-t.ci_lower_percent,t.ci_upper_percent-t.adjusted_percent],
                    fmt=marker,color=color,ms=4,capsize=2,lw=.8,label=['Opening','Middle','Ending'][section-1])
            ax.set_xticks(range(5),AGE.values());ax.set_ylim(bottom=0);ax.set_xlabel('Age group, y')
            ax.set_ylabel('Adjusted prevalence, %');ax.set_title(label,fontweight='bold')
            ax.spines[['top','right']].set_visible(False);ax.grid(axis='y',color='#e5e5e5',lw=.5)
        if len(features)==5:axes.flat[5].axis('off')
        handles,labels=axes.flat[0].get_legend_handles_labels()
        fig.legend(handles,labels,ncol=3,loc='upper center',bbox_to_anchor=(.52,.925),frameon=False)
        fig.suptitle(f'Age-related {domain} prevalence in recorded note texts',fontsize=15,fontweight='bold',y=.98)
        fig.text(.07,.025,'Feature presence is the outcome; estimates standardized for recorded sex and year. N = 18,630.\n'
            'Error bars: pointwise 95% CIs; covariance clustered by normalized recorded text. These are cross-sectional age-group comparisons.',fontsize=8.5,linespacing=1.5)
        fig.subplots_adjust(left=.07,right=.98,top=.83,bottom=.15,wspace=.32,hspace=.48)
        for ext in ['png','pdf','svg']:fig.savefig(DEST/f'{stem}.{ext}',dpi=220)
        plt.close(fig)


if __name__=='__main__':
    with threadpool_limits(limits=4):main()
