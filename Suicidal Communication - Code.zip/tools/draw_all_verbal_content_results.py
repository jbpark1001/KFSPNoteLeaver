"""Complete theme/sentiment versions of figure options 1 and 4."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from statsmodels.stats.multitest import multipletests
import draw_verbal_content_options as shared

OUT=shared.OUT/'all_themes'
OUT.mkdir(parents=True,exist_ok=True)
shared.OUT=OUT
T=shared.T.copy();S=shared.S.copy()
THEMES=['Sorry and Shame','Love and Gratitude','Burden','Despair','Post-mortem Affairs']
assert set(T.theme)==set(THEMES) and len(T)==15 and len(S)==15
assert not T[['theme','method']].duplicated().any()
assert np.allclose(T.q_BH_15,multipletests(T.p,method='fdr_bh')[1])
assert np.allclose(S.q_BH_15,multipletests(S.p,method='fdr_bh')[1])
assert T[['OR','ci_lower','ci_upper']].notna().all().all()
assert S[['OR','ci_lower','ci_upper']].notna().all().all()

def significance_key(fig,anchor):
    fig.legend(handles=[Line2D([],[],color='#555555',marker='o',mfc='#555555',ls='none',label='FDR P < .05'),
        Line2D([],[],color='#555555',marker='o',mfc='white',ls='none',label='FDR P ≥ .05')],
        loc='lower left',bbox_to_anchor=anchor,ncol=2,frameon=False,fontsize=9,
        title='Marker fill: significance',title_fontsize=9)

def option1(explained=False):
    fig=plt.figure(figsize=(11.8,9.2))
    fig.suptitle('Reported Talk About Suicide, Homicide, or Death and Suicide Note Content'
                 if explained else 'Recorded Verbal Communication and Note Content',
                 fontsize=14 if explained else 15,fontweight='bold',y=.975)
    fig.text(.055,.91,'A  All themes across extraction methods',fontweight='bold',fontsize=11)
    fig.text(.555,.91,'B  All sentiment labels',fontweight='bold',fontsize=11)
    a=fig.add_axes([.255,.17,.225,.69]);labels=[];ys=[];coverage=[]
    for j,theme in enumerate(THEMES):
        head=j*4
        a.text(-.79,head-.68,theme.replace(' and ','/'),fontweight='bold',fontsize=9.5,
               transform=a.get_yaxis_transform(),clip_on=False)
        for k,(method,label,color,marker) in enumerate(shared.METHODS):
            r=T[T.theme.eq(theme)&T.method.eq(method)].iloc[0]
            shared.point(a,r,head+k,color,marker,significance=True)
            labels.append(label);ys.append(head+k);coverage.append((theme,method))
    shared.axis(a,18.8,labels,ys);a.tick_params(axis='y',labelsize=8.7)
    b=fig.add_axes([.745,.17,.225,.69])
    for i,r in S.iterrows():shared.point(b,r,i,significance=True)
    shared.axis(b,14.7,S.sentiment.tolist(),range(15))
    if explained:
        for ax in (a,b):
            ax.set_xlabel('Adjusted odds ratio (95% CI)')
            ax.text(0,1.018,'\u2190 Lower odds of content',transform=ax.transAxes,
                    ha='left',va='bottom',fontsize=7.2,color='#444444')
            ax.text(1,1.018,'Higher odds of content \u2192',transform=ax.transAxes,
                    ha='right',va='bottom',fontsize=7.2,color='#444444')
    if explained:
        shared.method_key(fig,anchor=(.48,.035))
        significance_key(fig,(.69,.035))
    else:
        significance_key(fig,(.055,.035));shared.method_key(fig,anchor=(.97,.015))
    assert len(set(coverage))==15
    shared.save(fig,'option1_all_themes_and_sentiments_explained' if explained
                else 'option1_all_themes_and_sentiments')

def option4():
    fig=plt.figure(figsize=(11.6,14.4));ax=fig.add_axes([.37,.105,.285,.80])
    fig.suptitle('Recorded Verbal Communication and Note Content',fontsize=15,fontweight='bold',y=.980)
    ax.text(-1.10,-1.05,'Themes',transform=ax.get_yaxis_transform(),fontweight='bold',fontsize=11)
    coverage=[]
    for j,theme in enumerate(THEMES):
        head=j*4
        ax.text(-1.10,head-.45,theme.replace(' and ','/'),transform=ax.get_yaxis_transform(),
                fontsize=10,fontweight='bold')
        for k,(method,label,color,marker) in enumerate(shared.METHODS):
            r=T[T.theme.eq(theme)&T.method.eq(method)].iloc[0];y=head+k+.35
            shared.point(ax,r,y,color,marker,significance=True)
            ax.text(-1.04,y,label,transform=ax.get_yaxis_transform(),va='center',fontsize=9.5)
            shared.values(ax,r,y);coverage.append((theme,method))
    ax.text(-1.10,20.0,'Sentiment labels',transform=ax.get_yaxis_transform(),fontweight='bold',fontsize=11)
    for i,r in S.iterrows():
        y=21+i;shared.point(ax,r,y,significance=True)
        ax.text(-1.04,y,r.sentiment,transform=ax.get_yaxis_transform(),va='center',fontsize=9.5)
        shared.values(ax,r,y)
    shared.axis(ax,36.2)
    ax.text(1.12,1.04,'aOR (95% CI)',transform=ax.transAxes,fontweight='bold',fontsize=10)
    ax.text(1.96,1.04,'FDR P',transform=ax.transAxes,fontweight='bold',fontsize=10)
    significance_key(fig,(.055,.025));shared.method_key(fig,anchor=(.97,.013),ncol=1)
    assert len(set(coverage))==15
    shared.save(fig,'option4_all_themes_and_sentiments_table')

if __name__=='__main__':
    option1();option4()
    T.to_csv(OUT/'all_theme_estimates.csv',index=False)
    S.to_csv(OUT/'all_sentiment_estimates.csv',index=False)
    caption='''Figure. Recorded Verbal Communication and Note Content.
All five themes are displayed using the original KeyBERT-based extraction,
dictionary matching across all KLUE-tokenized unigram candidates, and literal
dictionary substring matching. All 15 sentiment labels from the primary model
are displayed. Each plotted association compares explicit affirmative versus
negative responses for reported talk about suicide, homicide, or death
(WARNSPEAK1) in 15,163 uniquely linked eligible records, with adjustment for
categorical age group, recorded sex, and calendar year. The outcome is theme
or sentiment-label presence in any of the three sections; labels may co-occur.

Points represent adjusted odds ratios and horizontal bars indicate pointwise
95% confidence intervals. The odds-ratio axis is logarithmic and the dashed
line indicates aOR=1. Thematic extraction methods are distinguished by color
and shape: gray squares (KeyBERT-based), light-blue circles (dictionary + KLUE),
and dark-blue diamonds (literal dictionary). Sentiment estimates use dark-blue
circles. Filled markers indicate FDR-adjusted P<.05; open markers indicate
adjusted P>=.05 in both domains. Theme P values are BH-adjusted across all 15
theme-method tests; sentiment P values use a separate 15-label BH family.
Intervals are not multiplicity-adjusted simultaneous intervals.

Option 1 separates thematic and sentiment results into two panels. Option 4
provides the same complete estimates with numerical aOR/CI and adjusted-P
columns. Theme order follows the manuscript; sentiments are sorted by aOR.
The primary Neutral association (adjusted P approximately .049) is included
despite not being stable across all sensitivity analyses. None of these plots
constitutes human validation or independent replication across methods.

All estimates were available in saved model outputs. No new fitting was
required. Plot coverage: 15 theme-method estimates and 15 sentiment estimates.
'''
    (OUT/'caption_and_definitions.txt').write_text(caption,encoding='utf-8')
    print('Complete: both layouts include 15 theme-method estimates and 15 sentiments.')
    print('Both 15-test BH families verified against saved p-values; Arial verified.')
    print(OUT)
