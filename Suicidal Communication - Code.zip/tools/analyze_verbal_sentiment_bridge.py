"""Exploratory note sentiment associations; only aggregate outputs are exported."""
from pathlib import Path
import sys, json, shutil
import numpy as np
import pandas as pd
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.stats.multitest import multipletests
from threadpoolctl import threadpool_limits
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FixedLocator, FuncFormatter, NullFormatter

P=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P))
from project import input_path
OUT=P/'outputs/verbal_sentiment_bridge_20261106'
OUT.mkdir(parents=True,exist_ok=True)
LABELS={'Despair':'절망','Defeat / self-disgust':'패배/자기혐오','Exhaustion':'힘듦/지침',
        'Anxiety / worry':'불안/걱정','Disappointment':'안타까움/실망','Anger':'화남/분노',
        'Hatred':'증오/혐오','Resentment':'어이없음','Sadness':'슬픔','Sorrow':'서러움',
        'Gratitude':'고마움','Affection':'흐뭇함(귀여움/예쁨)','Happiness':'행복',
        'Relief / trust':'안심/신뢰','Neutral':'없음'}
COLS=['1st_section_sentiment','2nd_section_sentiment','3rd_section_sentiment']
FIELDS=['YEAR','SEX','AGE2','SUICIDE_DATE','NOTE_CONTENTDTL']

def hashes(d):
    return pd.util.hash_pandas_object(d[FIELDS].astype('string').fillna('<MISSING>'),index=False)

def main():
    source=pd.read_pickle(input_path('demographic_source'))
    sent=pd.read_pickle(input_path('sentiment_features'))
    assert source.index.is_unique and sent.index.is_unique
    sh,rh=hashes(source),hashes(sent)
    su,ru=~sh.duplicated(keep=False),~rh.duplicated(keep=False)
    mapping=pd.Series(source.index[su],index=sh[su].to_numpy())
    match=rh.map(mapping).where(ru).dropna().astype(int)
    d=source.loc[match.values].copy(); d.index=match.index
    for c in FIELDS:
        assert d[c].astype('string').fillna('<MISSING>').equals(sent.loc[d.index,c].astype('string').fillna('<MISSING>'))
    d=d.loc[sent.loc[d.index,'too_short'].eq(False)]
    n_eligible=len(d)
    d['verbal']=d.WARNSPEAK1.map({1:1.,2:0.})
    d=d.loc[d.NOTE_EX.eq(1)&d.verbal.notna()&d.AGE2.isin(range(1,6))&d.SEX.isin([1,2])&d.YEAR.between(2013,2020)].copy()
    valid=sent.loc[d.index,COLS].apply(lambda s:s.map(lambda x:isinstance(x,dict) and isinstance(x.get('labels'),list)))
    invalid=int((~valid.all(axis=1)).sum())
    d=d.loc[valid.all(axis=1)].copy()
    labelsets=sent.loc[d.index,COLS].apply(lambda s:s.map(lambda x:set(x['labels'])))
    union=labelsets.apply(lambda r:set().union(*r),axis=1)
    text=d.NOTE_CONTENTDTL.astype('string').fillna('').str.replace(r'\s+',' ',regex=True).str.strip()
    d['log_length']=np.log1p(text.str.len().astype(float))
    d['text_group']=pd.factorize(text)[0]
    for k in [2,3,4]:d[f'v{k}']=d[f'WARNSPEAK{k}'].map({1:1.,2:0.})
    records=[]
    models={
        'primary':'verbal + C(AGE2) + C(SEX) + C(YEAR)',
        'length_adjusted':'verbal + C(AGE2) + C(SEX) + C(YEAR) + log_length + I(log_length ** 2)',
        'other_verbal_common_sample_base':'verbal + C(AGE2) + C(SEX) + C(YEAR)',
        'other_verbal_adjusted':'verbal + C(AGE2) + C(SEX) + C(YEAR) + v2 + v3 + v4',
        'duplicate_cluster_robust':'verbal + C(AGE2) + C(SEX) + C(YEAR)'}
    with threadpool_limits(limits=2):
        for name,korean in LABELS.items():
            d['outcome']=union.map(lambda s:int(korean in s))
            for model,rhs in models.items():
                a=d.dropna(subset=['v2','v3','v4']).copy() if model.startswith('other_verbal') else d.copy()
                cells=pd.crosstab(a.verbal,a.outcome).reindex(index=[0.,1.],columns=[0,1],fill_value=0)
                row={'sentiment':name,'model':model,'n':len(a),'yes_n':int(a.verbal.eq(1).sum()),'no_n':int(a.verbal.eq(0).sum()),
                     'positive_yes_n':int(cells.loc[1.,1]),'positive_no_n':int(cells.loc[0.,1]),
                     'percent_yes':100*a.loc[a.verbal.eq(1),'outcome'].mean(),'percent_no':100*a.loc[a.verbal.eq(0),'outcome'].mean(),
                     'minimum_cell':int(cells.to_numpy().min())}
                if row['minimum_cell']<5:
                    row.update(status='withheld_sparse',p=1.)
                else:
                    kwargs={'cov_type':'cluster','cov_kwds':{'groups':a.text_group}} if model=='duplicate_cluster_robust' else {}
                    fit=smf.glm('outcome ~ '+rhs,data=a,family=sm.families.Binomial()).fit(**kwargs)
                    assert fit.converged
                    b,se=fit.params['verbal'],fit.bse['verbal']
                    assert np.isfinite([b,se]).all()
                    row.update(status='estimated',OR=float(np.exp(b)),ci_lower=float(np.exp(b-1.96*se)),ci_upper=float(np.exp(b+1.96*se)),p=float(fit.pvalues['verbal']))
                records.append(row)
    tab=pd.DataFrame(records)
    tab['q_BH_15']=tab.groupby('model')['p'].transform(lambda v:multipletests(v,method='fdr_bh')[1])
    tab.to_csv(OUT/'all_sentiment_models.csv',index=False)
    primary=tab.loc[tab.model.eq('primary')].copy()
    primary.to_csv(OUT/'primary_sentiment_results.csv',index=False)
    audit={'registry_rows':len(source),'sentiment_rows':len(sent),'unique_exact_matches':len(match),'matched_eligible':n_eligible,
           'analysis_n':len(d),'verbal_yes_n':int(d.verbal.sum()),'verbal_no_n':int(d.verbal.eq(0).sum()),
           'invalid_section_labels_excluded':invalid,'unique_normalized_texts':int(d.text_group.nunique()),
           'other_verbal_complete_n':int(d[['v2','v3','v4']].notna().all(axis=1).sum()),'link_fields':FIELDS,
           'outcome':'Saved sentiment label in any of three sections; multi-label outcomes can co-occur',
           'multiplicity':'BH across 15 planned sentiments within each model; sparse outcomes assigned p=1',
           'exposure':'WARNSPEAK1: talk about suicide, homicide, or death; explicit yes vs explicit no',
           'primary_covariates':['categorical age group','recorded sex','categorical year'],
           'missingness':'Unknown/skipped exposure responses excluded, never recoded as no',
           'timing_used':False}
    (OUT/'analysis_audit.json').write_text(json.dumps(audit,indent=2),encoding='utf-8')
    plt.rcParams.update({'font.family':'Arial','font.size':10,'pdf.fonttype':42,'svg.fonttype':'none'})
    fig,(left,ax)=plt.subplots(1,2,figsize=(10.5,7),gridspec_kw={'width_ratios':[1.6,1]})
    y=np.arange(15)
    for axis in [left,ax]:axis.set_ylim(14.7,-1.8)
    left.set_xlim(0,1);left.axis('off')
    left.text(0,-1.1,'Automated sentiment',weight='bold');left.text(.65,-1.1,'Talk yes / no, %',weight='bold',ha='center')
    for i,r in enumerate(primary.itertuples()):
        left.text(0,i,r.sentiment,va='center');left.text(.65,i,f'{r.percent_yes:.1f} / {r.percent_no:.1f}',ha='center',va='center')
        left.axhline(i+.5,color='#eeeeee',lw=.6)
        if r.status=='estimated':
            color='#2367a0' if r.q_BH_15<.05 else '#7b8188'
            ax.errorbar(r.OR,i,xerr=[[r.OR-r.ci_lower],[r.ci_upper-r.OR]],fmt='o',color=color,capsize=2,ms=4)
    ax.set_xscale('log');ax.axvline(1,color='#444444',ls='--',lw=.9)
    ax.set_xlim(.72,1.4)
    ax.xaxis.set_major_locator(FixedLocator([.75,1.,1.25]))
    ax.xaxis.set_major_formatter(FuncFormatter(lambda x,pos:f'{x:g}'))
    ax.xaxis.set_minor_locator(FixedLocator([.8,.9,1.1,1.2,1.3,1.4]))
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.set_yticks(y,labels=['']*15);ax.tick_params(axis='y',length=0)
    ax.grid(axis='both',which='both',color='#e5e5e5',lw=.6);ax.set_axisbelow(True)
    ax.set_xlabel('Adjusted odds ratio (95% CI)')
    ax.text(.5,-1.1,'Death-related talk vs explicit no',transform=ax.get_yaxis_transform(),ha='center',weight='bold')
    for s in ['top','right','left']:ax.spines[s].set_visible(False)
    fig.subplots_adjust(left=.025,right=.98,top=.98,bottom=.1,wspace=.02)
    for ext in ['pdf','svg','png']:fig.savefig(OUT/f'sentiment_forest.{ext}',dpi=300)
    plt.close(fig)
    lines=['EXPLORATORY DEATH-RELATED TALK AND NOTE SENTIMENT ANALYSIS',json.dumps(audit,indent=2),'',
           'INTERPRETATION: Recorded talk is associated with selected differences in automated emotional content, rather than a uniform increase in distress-related labels. Associations are modest; sadness remains common in both groups. Null results do not establish equivalence.',
           'Four associations (anger, hatred, disappointment, sadness) survive FDR in the primary model, note-length adjustment, other-verbal adjustment, and duplicate-text clustered inference. The neutral association does not survive all sensitivity checks.',
           'POSSIBLE RESULTS PARAGRAPH: Among 15,163 eligible notes uniquely linked to registry records, 7794 were linked to recorded talk about suicide, homicide, or death and 7369 to an explicit negative response. After adjustment for age group, recorded sex, and year, recorded talk was associated with higher odds of automated anger (aOR, 1.18; 95% CI, 1.09-1.27) and hatred (aOR, 1.22; 95% CI, 1.09-1.37) labels and lower odds of disappointment (aOR, 0.84; 95% CI, 0.77-0.92) and sadness (aOR, 0.84; 95% CI, 0.76-0.93) labels. These four associations remained significant after false discovery rate correction across 15 sentiment labels and in sensitivity analyses accounting separately for note length, other verbal categories, and repeated note text. Despair, exhaustion, and anxiety labels showed no clear adjusted associations. A borderline association with neutral labels in the primary model was not consistent across sensitivity analyses.',
           '',
           'Primary: conventional binomial logistic GLM; OR compares recorded talk yes with explicit no.',
           'Each sensitivity model has a separate 15-outcome FDR family. These are sensitivity analyses, not independent replications.',
           'The 15 sentiments were retained from the existing manuscript feature set. They are not all 44 classifier outputs.',
           'Neutral means the saved classifier label (없음), not absence of distress. Any-section labels can co-occur.',
           'Automated labels have no completed human validation here. No claim of risk prediction or causal communication mechanisms is supported.',
           'Neither recorded talk nor notes establish the timing, intent, audience, or opportunity for prevention. The analysis is conditional on note availability and linkage.', '',
           primary.to_string(index=False),'', 'SENSITIVITY MODELS',tab.loc[~tab.model.eq('primary')].to_string(index=False)]
    (OUT/'REPORT.txt').write_text('\n'.join(lines),encoding='utf-8')
    print(json.dumps(audit,indent=2))
    print(primary[['sentiment','percent_yes','percent_no','OR','ci_lower','ci_upper','p','q_BH_15']].to_string(index=False))
    print('Sensitivity significant counts:',tab.groupby('model').q_BH_15.apply(lambda s:int(s.lt(.05).sum())).to_dict())

if __name__=='__main__':main()
