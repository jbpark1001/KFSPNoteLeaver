"""Four coefficient-plot layouts; exact saved estimates, no refitting."""
from pathlib import Path
import re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator,FixedFormatter,NullLocator

P=Path(__file__).resolve().parents[1]
OUT=P/'outputs/publication_communication_figures/verbal_content_options'
OUT.mkdir(parents=True,exist_ok=True)
T=pd.read_csv(P/'outputs/communication_profiles/note_content_bridge_models.csv')
S=pd.read_csv(P/'outputs/verbal_sentiment_bridge_20261106/primary_sentiment_results.csv')
assert len(T)==15 and len(S)==15 and T.n.eq(15163).all() and S.n.eq(15163).all()
METHODS=[('keybert_saved','KeyBERT-based','#B8BBBE','s'),
         ('dictionary_all_tokens','Dictionary + KLUE','#88B4E8','o'),
         ('dictionary_substring','Literal dictionary','#326BA6','D')]
THEMES=['Sorry and Shame','Post-mortem Affairs']
FOCAL=['Anger','Hatred','Disappointment','Sadness']
S=S.sort_values('OR').reset_index(drop=True)
BLUE='#326BA6'
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.labelsize':10,
    'axes.titlesize':11,'xtick.labelsize':9,'ytick.labelsize':9,'axes.linewidth':.7,
    'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})

def qtext(q):return '<.001' if q<.001 else f'{q:.3f}'.lstrip('0')

def point(ax,row,y,color=BLUE,marker='o',significance=False):
    assert row.ci_lower<=row.OR<=row.ci_upper
    filled=(not significance) or row.q_BH_15<.05
    ax.errorbar(row.OR,y,xerr=[[row.OR-row.ci_lower],[row.ci_upper-row.OR]],
        fmt=marker,ms=5.1,color=color,mec=color,mfc=color if filled else 'white',
        mew=1.1,capsize=2.3,lw=1,zorder=3)

def axis(ax,ymax,labels=None,ys=None):
    ax.set_xscale('log');ax.set_xlim(.68,1.45)
    ticks=[.7,.8,1,1.2,1.4]
    ax.xaxis.set_major_locator(FixedLocator(ticks))
    ax.xaxis.set_major_formatter(FixedFormatter([f'{v:.1f}' for v in ticks]))
    ax.xaxis.set_minor_locator(NullLocator())
    ax.axvline(1,color='#73777C',lw=.8,ls=(0,(3,3)))
    ax.set_ylim(ymax,-1)
    if labels is None:ax.set_yticks([])
    else:ax.set_yticks(ys,labels)
    ax.set_xlabel('Adjusted odds ratio')
    ax.spines[['top','right','left']].set_visible(False)
    ax.tick_params(axis='y',length=0,pad=7)

def method_key(fig,anchor=(.97,.015),ncol=3):
    fig.legend(handles=[Line2D([],[],color=c,marker=m,lw=1,ms=5,label=label)
        for _,label,c,m in METHODS],loc='lower right',bbox_to_anchor=anchor,ncol=ncol,
        title='Thematic extraction method',frameon=False,fontsize=9,title_fontsize=9,
        columnspacing=1.5,handlelength=1.7)

def significance_key(fig,anchor=(.055,.035)):
    fig.legend(handles=[Line2D([],[],color=BLUE,marker='o',mfc=BLUE,ls='none',label='FDR P < .05'),
        Line2D([],[],color=BLUE,marker='o',mfc='white',ls='none',label='FDR P ≥ .05')],
        loc='lower left',bbox_to_anchor=anchor,ncol=2,frameon=False,fontsize=8.5,
        title='Sentiment associations',title_fontsize=8.5)

def save(fig,name):
    for ext in ['png','pdf','svg','tiff']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=600 if ext=='tiff' else 210,
            **({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tiff' else {}))
    fonts=re.findall(rb'/BaseFont\s*/([^\s/<>\[\]()]+)',(OUT/f'{name}.pdf').read_bytes())
    assert fonts and all(b'Arial' in f for f in fonts)
    plt.close(fig)

def theme_rows(ax):
    ys=[];labels=[]
    for j,theme in enumerate(THEMES):
        head=j*4
        ax.text(-.79,head-.68,theme.replace(' and ','/'),fontweight='bold',fontsize=10,
            transform=ax.get_yaxis_transform(),clip_on=False)
        for k,(method,label,color,marker) in enumerate(METHODS):
            r=T[T.theme.eq(theme)&T.method.eq(method)].iloc[0]
            point(ax,r,head+k,color,marker)
            ys.append(head+k);labels.append(label)
    return labels,ys

def option1():
    fig=plt.figure(figsize=(11.8,8.0))
    fig.suptitle('Recorded Verbal Communication and Note Content',fontsize=15,fontweight='bold',y=.975)
    fig.text(.055,.90,'A  Themes: extraction-method comparison',fontweight='bold',fontsize=11)
    fig.text(.555,.90,'B  All sentiment labels',fontweight='bold',fontsize=11)
    a=fig.add_axes([.255,.20,.225,.64]);labels,ys=theme_rows(a);axis(a,7,labels,ys)
    b=fig.add_axes([.745,.20,.225,.64])
    for i,r in S.iterrows():point(b,r,i,significance=True)
    axis(b,14.7,S.sentiment.tolist(),range(15))
    significance_key(fig);method_key(fig)
    save(fig,'option1_two_panel_forest')

def option2():
    fig=plt.figure(figsize=(10.6,7.7));ax=fig.add_axes([.34,.19,.35,.66])
    fig.suptitle('Recorded Verbal Communication and Selected Note Content',fontsize=14,fontweight='bold',y=.975)
    labels=[];ys=[]
    for j,theme in enumerate(THEMES):
        head=j*4
        ax.text(-.83,head-.68,theme.replace(' and ','/'),fontweight='bold',fontsize=10,
            transform=ax.get_yaxis_transform(),clip_on=False)
        for k,(method,label,color,marker) in enumerate(METHODS):
            r=T[T.theme.eq(theme)&T.method.eq(method)].iloc[0];y=head+k
            point(ax,r,y,color,marker)
            labels.append(label);ys.append(y)
    ax.text(-.83,7.5,'Sentiment labels',fontweight='bold',fontsize=10,
        transform=ax.get_yaxis_transform(),clip_on=False)
    for k,label in enumerate(['Disappointment','Sadness','Anger','Hatred']):
        r=S[S.sentiment.eq(label)].iloc[0];y=8.4+k
        point(ax,r,y);labels.append(label);ys.append(y)
    axis(ax,12,labels,ys)
    method_key(fig,anchor=(.97,.025))
    save(fig,'option2_combined_selected_forest')

def option3():
    fig=plt.figure(figsize=(11.8,7.4))
    fig.suptitle('Verbal Communication: Primary Associations and Extraction Robustness',fontsize=14,fontweight='bold',y=.975)
    fig.text(.055,.89,'A  Selected primary associations',fontweight='bold',fontsize=11)
    fig.text(.555,.89,'B  Thematic extraction robustness',fontweight='bold',fontsize=11)
    a=fig.add_axes([.235,.21,.245,.60]);labels=[]
    for k,theme in enumerate(THEMES):
        r=T[T.theme.eq(theme)&T.method.eq('keybert_saved')].iloc[0]
        point(a,r,k);labels.append(theme.replace(' and ','/'))
    a.axhline(1.5,color='#E3E5E8',lw=.7)
    for k,label in enumerate(['Disappointment','Sadness','Anger','Hatred']):
        r=S[S.sentiment.eq(label)].iloc[0];point(a,r,k+2);labels.append(label)
    axis(a,5.6,labels,range(6))
    b=fig.add_axes([.755,.21,.215,.60]);lab,ys=theme_rows(b);axis(b,7,lab,ys)
    method_key(fig,anchor=(.97,.03))
    save(fig,'option3_primary_and_robustness')

def option4():
    fig=plt.figure(figsize=(11.6,11.4));ax=fig.add_axes([.37,.13,.285,.76])
    fig.suptitle('Recorded Verbal Communication and Note Content',fontsize=15,fontweight='bold',y=.975)
    ax.text(-1.10,-1.05,'Themes',transform=ax.get_yaxis_transform(),fontweight='bold',fontsize=11)
    for j,theme in enumerate(THEMES):
        head=j*4
        ax.text(-1.10,head-.45,theme.replace(' and ','/'),transform=ax.get_yaxis_transform(),
            fontsize=10,fontweight='bold')
        for k,(method,label,color,marker) in enumerate(METHODS):
            r=T[T.theme.eq(theme)&T.method.eq(method)].iloc[0]
            y=head+k+.35;point(ax,r,y,color,marker)
            ax.text(-1.04,y,label,transform=ax.get_yaxis_transform(),va='center',fontsize=9.5)
            values(ax,r,y)
    ax.text(-1.10,8.0,'Sentiment labels',transform=ax.get_yaxis_transform(),fontweight='bold',fontsize=11)
    for i,r in S.iterrows():
        y=9+i;point(ax,r,y,significance=True)
        ax.text(-1.04,y,r.sentiment,transform=ax.get_yaxis_transform(),va='center',fontsize=9.5)
        values(ax,r,y)
    axis(ax,24.2)
    ax.text(1.12,1.045,'aOR (95% CI)',transform=ax.transAxes,fontweight='bold',fontsize=10)
    ax.text(1.96,1.045,'FDR P',transform=ax.transAxes,fontweight='bold',fontsize=10)
    significance_key(fig,anchor=(.055,.025));method_key(fig,anchor=(.97,.013),ncol=1)
    save(fig,'option4_forest_with_numeric_table')

def values(ax,r,y):
    ax.text(1.12,y,f'{r.OR:.2f} ({r.ci_lower:.2f}–{r.ci_upper:.2f})',
        transform=ax.get_yaxis_transform(),va='center',fontsize=9.5)
    ax.text(1.96,y,qtext(r.q_BH_15),transform=ax.get_yaxis_transform(),va='center',fontsize=9.5)

if __name__=='__main__':
    option1();option2();option3();option4()
    (OUT/'captions_and_definitions.txt').write_text('''Shared definition: exposure is explicit yes versus explicit no on WARNSPEAK1,
combining reported talk about suicide, homicide, or death. All models adjust
categorical age group, recorded sex, and calendar year in 15,163 uniquely
matched eligible records. The outcome is the presence of a theme or sentiment
label in any of three sections, not demographic membership. Outcomes can co-occur.
Horizontal bars are pointwise 95% CIs; the dashed line is aOR=1; the axis is
logarithmic. Lower odds do not establish lower psychological distress.

Themes: two focal themes out of five are displayed. Each has three extraction
variants: KeyBERT-based (gray square), dictionary matching across all KLUE-
tokenized candidates (light-blue circle), and literal dictionary substring
matching (dark-blue diamond). BH correction includes all 15 theme-method tests,
not only the six displayed associations. These are the same records, not three
independent replications. Color/shape in the thematic rows identify extraction
method. The gray/blue scheme matches the manuscript figures.

Sentiments: all 15 prespecified labels use one primary extraction procedure.
Dark-blue circles identify their estimates; fill indicates FDR significance,
with BH correction across all 15 labels. There are five significant primary
sentiment associations, including a borderline Neutral result (adjusted P=.049),
which was not stable across sensitivity analyses. Options 1 and 4 display all
15 labels; Options 2 and 3 display only the four focal robust associations
(Anger, Hatred, Disappointment, Sadness). These focused versions must be labeled
as selected associations; the full table must remain available elsewhere.
The Neutral label does not mean absence of psychological distress.

Option 1: two panels, thematic-method comparisons and all sentiment labels.
Option 2: one combined plot of selected theme-method and sentiment estimates.
Option 3: panel A shows six selected primary estimates (two themes, four
sentiments); panel B separately displays thematic extraction robustness.
Option 4: same six theme-method comparisons and all 15 sentiments, with
numeric aOR/CI and FDR-adjusted P columns. Labels are sorted by primary aOR
within the sentiment domain in Options 1 and 4. No models were refitted.
''',encoding='utf-8')
    T.to_csv(OUT/'source_theme_estimates.csv',index=False)
    S.to_csv(OUT/'source_sentiment_estimates.csv',index=False)
    print('Four gray/blue figure options exported in PNG/PDF/SVG/600-dpi TIFF; Arial verified.')
    print(OUT)
