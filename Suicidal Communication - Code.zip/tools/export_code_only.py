"""Export an explicit source/documentation allowlist, excluding local study data."""
from pathlib import Path
import sys,hashlib,json,zipfile
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import ROOT

def selected():
    files=[ROOT/n for n in ['README.md','run.py','project.py','.gitignore']]
    for folder in ['scripts','text_analysis','figures','tools','tests','reference']:
        files.extend(p for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix in ['.py','.R'])
    files.extend((ROOT/'config').glob('*.example.json'))
    files.extend((ROOT/'environment').glob('*.txt'))
    files.append(ROOT/'environment/observed-current-versions.json')
    for n in ['ANALYSIS_MAP.md','DATA_CONTRACT.md','REPLICATION_STATUS.md','VALIDATION_RUNS.md','manuscript_reference.json','provenance.json','HISTORICAL_CLASSIFIER_RECOVERY.md','historical_classifier_candidates.json']:
        p=ROOT/'docs'/n
        if p.exists():files.append(p)
    return sorted(set(files))

def main():
    files=selected()
    entries=[dict(path=p.relative_to(ROOT).as_posix(),sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files]
    manifest={'scope':'Explicit code/documentation allowlist; no data, derived records, model weights, outputs or local configuration',
              'files':entries}
    path=ROOT/'Code-only replication.zip'
    with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED) as archive:
        for p in files:archive.write(p,p.relative_to(ROOT).as_posix())
        archive.writestr('PACKAGE_MANIFEST.json',json.dumps(manifest,indent=2))
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        for entry in entries:assert hashlib.sha256(archive.read(entry['path'])).hexdigest()==entry['sha256']
        assert not any(n.startswith(('outputs/','derived/')) or n in ['config/paths.json','config/runtime.json','config/paths.rebuilt.json'] for n in archive.namelist())
    print('Verified source-only archive:',path,'files:',len(entries))

if __name__=='__main__':main()
