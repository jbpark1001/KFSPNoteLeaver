"""Uncluttered probability figure and separate age-effect figure."""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

P=Path(__file__).resolve().parents[1]
ROOT=P/'outputs/publication_communication_figures'
OUT=ROOT/'clean_design';OUT.mkdir(exist_ok=True)
S=P/'outputs/communication_profiles/sex_analysis'
d=pd.read_csv(S/'primary_adjusted_age_sex_profiles.csv')
q=pd.read_csv(S/'primary_sex_differences_within_age.csv')
tests=pd.read_csv(ROOT/'age_contrast_options/sex_specific_age_contrasts.csv')
tests=tests[tests.family.eq('endpoint')]
profiles=['Neither recorded','Note only','Verbal only','Both recorded']
colors=['#B6BDC5','#4479AD','#CF9850','#5A9587']
ages=['≤18','19–34','35–49','50–64','≥65']
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.labelsize':10,
    'axes.titlesize':11,'axes.linewidth':.7,'xtick.labelsize':9,'ytick.labelsize':9,
    'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})

def export(fig,name):
    for ext in ['png','pdf','svg','tiff']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=600 if ext=='tiff' else 200,
                    **({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tiff' else {}))
    plt.close(fig)

key=[Line2D([],[],color='#555555',marker='s',mfc='white',lw=1.4,ls='--',label='Male'),
     Line2D([],[],color='#555555',marker='o',lw=1.4,label='Female')]
fig,axes=plt.subplots(2,2,figsize=(10.4,7.4))
fig.subplots_adjust(left=.085,right=.98,top=.875,bottom=.13,hspace=.40,wspace=.23)
for j,(ax,profile,color) in enumerate(zip(axes.flat,profiles,colors)):
    for sex,marker,ls,shift in [('Male','s','--',-.035),('Female','o','-',.035)]:
        z=d[d.profile.eq(profile)&d.sex.eq(sex)].sort_values('age_code')
        x=np.arange(5)+shift
        ax.plot(x,z.percent,color=color,ls=ls,lw=1.5)
        ax.errorbar(x,z.percent,yerr=[z.percent-z.ci_lower_percent,z.ci_upper_percent-z.percent],
            fmt=marker,ms=4.7,color=color,mfc='white' if sex=='Male' else color,
            mew=1.1,lw=.8,capsize=2.5)
    for k,(_,r) in enumerate(q[q.profile.eq(profile)].sort_values('age_code').iterrows()):
        if r.q_BH_20<.05:
            top=d[d.profile.eq(profile)&d.age_code.eq(k+1)].ci_upper_percent.max()
            mark='***' if r.q_BH_20<.001 else '**' if r.q_BH_20<.01 else '*'
            ax.text(k,top+2,mark,ha='center',fontsize=9)
    ax.set(xticks=range(5),xticklabels=ages,xlim=(-.25,4.25),ylim=(0,65),
        xlabel='Age group, y',ylabel='Adjusted proportion, %')
    ax.set_yticks([0,20,40,60])
    ax.set_title(f'{chr(65+j)}  {profile}',loc='left',fontweight='bold',pad=8)
    ax.spines[['top','right']].set_visible(False)
    ax.grid(axis='y',color='#EBECEE',lw=.5);ax.set_axisbelow(True)
fig.legend(handles=key,ncol=2,loc='upper center',bbox_to_anchor=(.53,.975),frameon=False)
fig.text(.085,.035,'95% CIs. Stars compare female with male within age: FDR-adjusted * P < .05, ** P < .01, *** P < .001.',fontsize=8,color='#444444')
export(fig,'communication_profiles_clean')

fig,ax=plt.subplots(figsize=(10.4,4.5))
fig.subplots_adjust(left=.20,right=.72,top=.80,bottom=.20)
for j,(profile,color) in enumerate(zip(profiles,colors)):
    for sex,marker,offset in [('Male','s',-.14),('Female','o',.14)]:
        r=tests[tests.profile.eq(profile)&tests.sex.eq(sex)].iloc[0]
        ax.errorbar(r.difference_pp,j+offset,
            xerr=[[r.difference_pp-r.ci_lower_pp],[r.ci_upper_pp-r.difference_pp]],
            fmt=marker,ms=6,mfc='white' if sex=='Male' else color,mec=color,
            color=color,mew=1.2,lw=1.1,capsize=3)
        ax.text(1.04,j+offset,f'{r.difference_pp:+.1f} ({r.ci_lower_pp:+.1f} to {r.ci_upper_pp:+.1f})',
            va='center',transform=ax.get_yaxis_transform(),fontsize=9,clip_on=False)
ax.axvline(0,color='#777777',ls=(0,(3,3)),lw=.8)
ax.set(yticks=range(4),yticklabels=profiles,ylim=(3.6,-.65),xlim=(-20,35),
       xticks=[-20,-10,0,10,20,30],xlabel='Adjusted difference, percentage points')
ax.spines[['top','right']].set_visible(False)
ax.text(1.04,1.07,'Difference (95% CI)',transform=ax.transAxes,fontweight='bold',fontsize=9)
fig.suptitle('Age difference: ≥65 vs 19–34 years',fontsize=13,fontweight='bold',y=.98)
fig.legend(handles=key,ncol=2,loc='upper center',bbox_to_anchor=(.53,.93),frameon=False)
fig.text(.20,.045,'Year-standardized contrasts within sex. All eight comparisons remain significant after FDR correction.',fontsize=8,color='#444444')
export(fig,'age_differences_clean')
(OUT/'captions.txt').write_text('''Communication profiles: predicted probabilities from the multinomial model
including categorical age-by-sex interaction and year; standardization uses
the common empirical calendar-year distribution. N=79,083. Error bars are
pointwise 95% CIs. Sex stars use the existing 20-test BH family.

Age differences: probabilities at age 65+ minus probabilities at age 19-34,
separately within each sex, using the same model and standardization. Intervals
use the full covariance of the two predictions. BH correction across eight
contrasts; all adjusted P<.01. Marker shape/fill identifies sex, not significance.
Both figures are cross-sectional. Verbal means reported talk about suicide,
homicide, or death. Note-only refers specifically to absence of that verbal
indicator. Neither recorded does not establish absence of communication.
''',encoding='utf-8')
print(OUT)
