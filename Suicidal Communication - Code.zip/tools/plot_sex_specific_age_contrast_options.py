"""Reproduce saved interaction model; derive age contrasts and three layouts."""
from pathlib import Path
import json,re
import numpy as np
import pandas as pd
from scipy.stats import norm
from statsmodels.stats.multitest import multipletests
from threadpoolctl import threadpool_limits
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from analyze_communication_sex import valid,prepare,fit_mn,marginal,input_path

P=Path(__file__).resolve().parents[1]
SRC=P/'outputs/communication_profiles'
OUT=P/'outputs/publication_communication_figures/age_contrast_options'
OUT.mkdir(parents=True,exist_ok=True)
PROFILES=['Neither recorded','Note only','Verbal only','Both recorded']
COLORS=dict(zip(PROFILES,['#B6BDC5','#4479AD','#CF9850','#5A9587']))
AGES=['≤18','19–34','35–49','50–64','65+']
CELLS=pd.read_csv(SRC/'sex_analysis/primary_adjusted_age_sex_profiles.csv')
SEXTEST=pd.read_csv(SRC/'sex_analysis/primary_sex_differences_within_age.csv')
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.labelsize':10,
    'axes.titlesize':11,'xtick.labelsize':9,'ytick.labelsize':9,'axes.linewidth':.7,
    'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})

def stars(q,ns=False):
    return '***' if q<.001 else '**' if q<.01 else '*' if q<.05 else 'ns' if ns else ''

def estimate():
    source=pd.read_pickle(input_path('demographic_source'))
    d=valid(prepare(source));assert len(d)==79083
    model,x=fit_mn(d,'C(AGE2)*C(SEX) + C(YEAR)')
    cov=np.asarray(model.cov_params())
    years=d.groupby('YEAR').size().rename('n').reset_index();w=years.n.to_numpy()/len(d)
    cache={};errors=[]
    for age in range(1,6):
        for sex,label in [(1,'Male'),(2,'Female')]:
            pred,grad=marginal(model,x,years.assign(AGE2=age,SEX=sex),w)
            cache[age,sex]=(pred,grad)
            for k,profile in enumerate(PROFILES):
                saved=CELLS[CELLS.age_code.eq(age)&CELLS.sex.eq(label)&CELLS.profile.eq(profile)].iloc[0]
                errors.append(abs(100*pred[k]-saved.percent))
    assert max(errors)<1e-7,max(errors)
    rows=[]
    for younger,older,family in [(2,5,'endpoint')]+[(i,i+1,'adjacent') for i in range(1,5)]:
        for sex,label in [(1,'Male'),(2,'Female')]:
            p0,g0=cache[younger,sex];p1,g1=cache[older,sex]
            for k,profile in enumerate(PROFILES):
                delta=p1[k]-p0[k];gradient=g1[k]-g0[k]
                se=np.sqrt(gradient@cov@gradient)
                rows.append(dict(family=family,profile=profile,sex=label,
                    younger_code=younger,older_code=older,younger=AGES[younger-1],older=AGES[older-1],
                    difference_pp=100*delta,ci_lower_pp=100*(delta-1.96*se),
                    ci_upper_pp=100*(delta+1.96*se),p=2*norm.sf(abs(delta/se))))
    tests=pd.DataFrame(rows)
    tests['q_BH']=tests.groupby('family').p.transform(lambda p:multipletests(p,method='fdr_bh')[1])
    assert len(tests)==40 and tests.q_BH.between(0,1).all()
    tests.to_csv(OUT/'sex_specific_age_contrasts.csv',index=False)
    (OUT/'analysis_manifest.json').write_text(json.dumps(dict(n=len(d),
        formula='profile ~ C(age)*C(sex) + C(year)',standardization='Common empirical year distribution',
        covariance='Model-based multinomial covariance; delta method for probability differences',
        max_saved_prediction_discrepancy_pp=max(errors),
        fdr_families={'endpoint':8,'adjacent':32},
        interpretation='Exploratory within-sex cross-sectional age differences; no within-person aging inference'),indent=2),encoding='utf-8')
    return tests

def frame(ax,grid=False):
    ax.spines[['top','right']].set_visible(False);ax.tick_params(length=3,width=.7)
    ax.set_axisbelow(True)
    if grid:ax.grid(axis='y',color='#E8EAEC',lw=.55)

def key():
    return [Line2D([],[],color='#555555',marker='s',mfc='white',ls='--',label='Male'),
        Line2D([],[],color='#555555',marker='o',mfc='#555555',ls='-',label='Female')]

def curves(ax,profile,j,brackets=False):
    color=COLORS[profile]
    for sex,shift,marker,ls in [('Male',-.045,'s','--'),('Female',.045,'o','-')]:
        d=CELLS[CELLS.profile.eq(profile)&CELLS.sex.eq(sex)].sort_values('age_code')
        xx=np.arange(5)+shift
        ax.plot(xx,d.percent,color=color,ls=ls,lw=1.3)
        ax.errorbar(xx,d.percent,yerr=[d.percent-d.ci_lower_percent,d.ci_upper_percent-d.percent],
            fmt=marker,ms=4.8,mew=1.1,mfc=color if sex=='Female' else 'white',
            color=color,capsize=2.3,lw=.9)
    for k,(_,r) in enumerate(SEXTEST[SEXTEST.profile.eq(profile)].sort_values('age_code').iterrows()):
        top=CELLS[CELLS.profile.eq(profile)&CELLS.age_code.eq(k+1)].ci_upper_percent.max()
        if stars(r.q_BH_20):ax.text(k,top+2,stars(r.q_BH_20),ha='center',va='bottom',fontsize=10)
    ax.set(xlim=(-.3,4.3),ylim=(0,86 if brackets else 65),xticks=range(5),xticklabels=AGES,
        ylabel='Adjusted proportion, %')
    ax.set_yticks([0,15,30,45,60] if not brackets else [0,20,40,60,80])
    ax.set_title(f'{chr(65+j)}  {profile}',loc='left',fontweight='bold',pad=10)
    frame(ax,True)

def save(fig,name):
    for ext in ['png','pdf','svg','tiff']:
        fig.savefig(OUT/f'{name}.{ext}',dpi=600 if ext=='tiff' else 200,
            **({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tiff' else {}))
    font=re.findall(rb'/BaseFont\s*/([^\s/<>\[\]()]+)',(OUT/f'{name}.pdf').read_bytes())
    assert font and all(b'Arial' in f for f in font)
    plt.close(fig)

def layout(tests,kind):
    fig=plt.figure(figsize=(12.4,11.4))
    outer=fig.add_gridspec(2,2,left=.085,right=.965,top=.86,bottom=.15,hspace=.37,wspace=.28)
    subtitles={'strip':'Adjacent-age significance strips','forest':'Age contrasts with confidence intervals','brackets':'Within-sex age-comparison brackets'}
    fig.suptitle('Communication Profiles by Age and Recorded Sex',fontsize=16,fontweight='bold',y=.98)
    fig.text(.5,.94,subtitles[kind],ha='center',fontsize=11,color='#444444')
    fig.legend(handles=key(),loc='upper center',bbox_to_anchor=(.52,.918),ncol=2,frameon=False)
    for j,profile in enumerate(PROFILES):
        color=COLORS[profile]
        if kind=='brackets':
            ax=fig.add_subplot(outer[j//2,j%2]);curves(ax,profile,j,True)
            ax.set_xlabel('Age group, y')
            for sex,y,ls in [('Male',71,'--'),('Female',79,'-')]:
                r=tests[tests.family.eq('endpoint')&tests.profile.eq(profile)&tests.sex.eq(sex)].iloc[0]
                ax.plot([1,1,4,4],[y-1,y,y,y-1],color=color,lw=1.0,ls=ls)
                ax.text(2.5,y+.7,f'{sex}: {stars(r.q_BH,True)}',ha='center',fontsize=9,color='#333333')
            continue
        inner=outer[j//2,j%2].subgridspec(2,1,height_ratios=[3.6,1.0 if kind=='strip' else 1.35],hspace=.38)
        ax=fig.add_subplot(inner[0]);curves(ax,profile,j)
        lower=fig.add_subplot(inner[1]);frame(lower)
        if kind=='strip':
            for row,(sex,marker) in enumerate([('Male','s'),('Female','o')]):
                d=tests[tests.family.eq('adjacent')&tests.profile.eq(profile)&tests.sex.eq(sex)].sort_values('older_code')
                for k,(_,r) in enumerate(d.iterrows()):
                    lower.plot(k+.5,row,marker=marker,ls='none',ms=6,mew=1.1,
                        mec=color,mfc=color if r.q_BH<.05 else 'white')
            lower.set(xlim=(-.3,4.3),ylim=(1.55,-.55),yticks=[0,1],yticklabels=['Male','Female'],
                xticks=[.5,1.5,2.5,3.5],xticklabels=['19–34\nvs ≤18','35–49\nvs 19–34','50–64\nvs 35–49','65+\nvs 50–64'])
            lower.tick_params(axis='x',labelsize=8,length=0);lower.tick_params(axis='y',labelsize=8,length=0)
            lower.spines[['bottom','left']].set_visible(False)
            lower.set_title('Within-sex age contrasts',loc='left',fontsize=8.5,pad=2,color='#444444')
        else:
            for row,(sex,marker) in enumerate([('Male','s'),('Female','o')]):
                r=tests[tests.family.eq('endpoint')&tests.profile.eq(profile)&tests.sex.eq(sex)].iloc[0]
                lower.errorbar(r.difference_pp,row,
                    xerr=[[r.difference_pp-r.ci_lower_pp],[r.ci_upper_pp-r.difference_pp]],
                    fmt=marker,color=color,mfc=color if r.q_BH<.05 else 'white',mew=1.1,
                    ms=5.5,capsize=2.5,lw=1)
            lower.axvline(0,color='#777777',ls=(0,(3,3)),lw=.8)
            lower.set(xlim=(-22,37),xticks=[-20,0,20],ylim=(1.65,-.65),yticks=[0,1],yticklabels=['Male','Female'])
            lower.tick_params(labelsize=8)
            lower.set_xlabel('Age 65+ minus 19–34, percentage points',fontsize=8.5,labelpad=3)
            lower.set_title('Within-sex age differences (95% CI)',loc='left',fontsize=8.5,pad=3,color='#444444')
    if kind!='brackets':
        fill=[Line2D([],[],color='#555555',marker='o',mfc='#555555',ls='none',label='Age contrast: FDR P < .05'),
            Line2D([],[],color='#555555',marker='o',mfc='white',ls='none',label='Age contrast: FDR P ≥ .05')]
        fig.legend(handles=fill,loc='lower center',bbox_to_anchor=(.53,.080),ncol=2,frameon=False,fontsize=9)
    extra={'strip':'Age-contrast strips: adjacent age groups within each sex; BH correction across 32 comparisons.',
        'forest':'Lower plots: age 65+ minus 19–34 within each sex; BH correction across 8 comparisons.',
        'brackets':'Brackets: age 65+ versus 19–34 within each sex; BH correction across 8 comparisons. ns indicates FDR P ≥ .05.'}[kind]
    fig.text(.085,.040,'Stars above curves: female–male comparisons within each age group (BH across 20 tests). * P < .05; ** P < .01; *** P < .001.\n'
        +extra+'\nYear-standardized probabilities; pointwise 95% CIs. N = 79,083. Verbal indicator: reported talk about suicide, homicide, or death.',
        fontsize=8.1,color='#444444',linespacing=1.65)
    save(fig,f'age_contrasts_{kind}')

if __name__=='__main__':
    with threadpool_limits(limits=4):
        tests=estimate()
        for kind in ['strip','forest','brackets']:layout(tests,kind)
    (OUT/'figure_notes.txt').write_text('''Three exploratory display alternatives from the same age-by-sex interaction model.
The saved interaction model was reproduced, and all 40 standardized probabilities
were verified against the previously saved estimates to within 1e-7 percentage
points. New within-sex age differences use the full covariance of the two
standardized predictions; pooled age tests were not attached to sex-specific curves.
The reference population is the common empirical year distribution.
Endpoint contrasts: age 65+ minus age 19-34, 4 profiles x 2 sexes = 8 tests.
Adjacent-age contrasts: 4 adjacent pairs x 4 profiles x 2 sexes = 32 tests.
Each is a separate Benjamini-Hochberg FDR family. Sex stars retain the previous
20-test family for female-minus-male comparisons within age.
All CIs are pointwise 95% intervals, not multiplicity-adjusted intervals.
Filled/open markers in lower plots indicate FDR significance, not sex.
In the main curves, dashed hollow squares identify male and solid filled circles
identify female; their fill does not indicate FDR significance.
Brackets and their labels identify endpoint age comparisons within sex.
Communication profiles are based specifically on WARNSPEAK1. Note-only does not
establish absence of other verbal communication, and neither recorded does not
establish that no communication occurred. No within-person age change is estimated.
''',encoding='utf-8')
    print(tests[tests.family.eq('endpoint')][['profile','sex','difference_pp','ci_lower_pp','ci_upper_pp','q_BH']].to_string(index=False))
    print('All three versions exported; Arial verified. Output:',OUT)
