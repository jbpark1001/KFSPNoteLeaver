"""Exploratory recorded-sex differences in communication, with interactions.

Uses the same explicit-response cohort and codebook definitions as the age
analysis. Recorded SEX is not a measure of gender identity. Originals remain.
"""
from analyze_communication_profiles import *
from scipy.stats import norm
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator,FixedFormatter,NullLocator

DEST=OUT/'sex_analysis';DEST.mkdir(parents=True,exist_ok=True)
SEX={1:'Male',2:'Female'}


def lrt(full,reduced):
    df=int(full.df_model-reduced.df_model);stat=max(0,2*(full.llf-reduced.llf))
    return {'chi_square':float(stat),'df':df,'p':float(chi2.sf(stat,df))}


def marginal(model,design,grid,weights):
    x=np.asarray(patsy.build_design_matrices([design.design_info],grid)[0])
    p=np.asarray(model.predict(x));mean=weights@p
    grads=[]
    for k in range(4):
        grads.append(np.column_stack([np.sum((weights*p[:,k]*((k==j)-p[:,j]))[:,None]*x,axis=0)
            for j in range(1,4)]).ravel(order='F'))
    return mean,grads


def profile_analysis(source,name='primary'):
    d=valid(prepare(source,legacy=name=='legacy_parent_skips',broad=name=='any_verbal'))
    additive,x0=fit_mn(d,'C(AGE2) + C(SEX) + C(YEAR)')
    age_only,_=fit_mn(d,'C(AGE2) + C(YEAR)')
    interaction,x=fit_mn(d,'C(AGE2)*C(SEX) + C(YEAR)')
    stats={'n':len(d),'sex_counts':{label:int(d.SEX.eq(code).sum()) for code,label in SEX.items()},
        'sex_global_additive':lrt(additive,age_only),'age_sex_profile_interaction':lrt(interaction,additive)}
    # Marginal sex comparison allows age interactions and averages over the
    # same observed age/year distribution for both sexes.
    cov=np.asarray(interaction.cov_params())
    groups=d.groupby(['AGE2','YEAR']).size().rename('n').reset_index()
    w=groups.n.to_numpy()/len(d)
    margins={};observed=[]
    for sex in SEX:
        margins[sex]=marginal(interaction,x,groups.assign(SEX=sex),w)
        a=d[d.SEX.eq(sex)]
        for k,profile in enumerate(PROFILES):
            count=int(a.profile.eq(k).sum());lo,hi=proportion_confint(count,len(a),method='wilson')
            p,g=margins[sex];se=np.sqrt(g[k]@cov@g[k])
            observed.append({'sex':SEX[sex],'profile':profile,'count':count,'n':len(a),'observed_percent':100*count/len(a),
                'adjusted_percent':100*p[k],'ci_lower_percent':100*(p[k]-1.96*se),'ci_upper_percent':100*(p[k]+1.96*se)})
    pd.DataFrame(observed).to_csv(DEST/f'{name}_profiles_by_sex.csv',index=False)
    differences=[]
    for k,profile in enumerate(PROFILES):
        diff=margins[2][0][k]-margins[1][0][k];g=margins[2][1][k]-margins[1][1][k]
        se=np.sqrt(g@cov@g)
        differences.append({'profile':profile,'female_minus_male_pp':100*diff,'ci_lower_pp':100*(diff-1.96*se),
            'ci_upper_pp':100*(diff+1.96*se),'p':float(2*norm.sf(abs(diff/se)))})
    diffs=pd.DataFrame(differences);diffs['q_BH_4']=multipletests(diffs.p,method='fdr_bh')[1]
    diffs.to_csv(DEST/f'{name}_adjusted_sex_differences.csv',index=False)
    if name!='primary':return stats
    year=d.groupby('YEAR').size().rename('n').reset_index();wy=year.n.to_numpy()/len(d)
    cells=[];contrasts=[];grad_cache={}
    for age in AGE:
        for sex in SEX:
            p,g=marginal(interaction,x,year.assign(AGE2=age,SEX=sex),wy);grad_cache[age,sex]=(p,g)
            for k,profile in enumerate(PROFILES):
                se=np.sqrt(g[k]@cov@g[k])
                cells.append({'sex':SEX[sex],'age':AGE[age],'age_code':age,'profile':profile,'percent':100*p[k],
                    'ci_lower_percent':100*(p[k]-1.96*se),'ci_upper_percent':100*(p[k]+1.96*se)})
        for k,profile in enumerate(PROFILES):
            p1,g1=grad_cache[age,1];p2,g2=grad_cache[age,2]
            diff=p2[k]-p1[k];g=g2[k]-g1[k];se=np.sqrt(g@cov@g)
            contrasts.append({'age':AGE[age],'age_code':age,'profile':profile,'female_minus_male_pp':100*diff,
                'ci_lower_pp':100*(diff-1.96*se),'ci_upper_pp':100*(diff+1.96*se),'p':float(2*norm.sf(abs(diff/se)))})
    tab=pd.DataFrame(cells);assert np.allclose(tab.groupby(['age_code','sex']).percent.sum(),100)
    tab.to_csv(DEST/'primary_adjusted_age_sex_profiles.csv',index=False)
    sex_age=pd.DataFrame(contrasts);sex_age['q_BH_20']=multipletests(sex_age.p,method='fdr_bh')[1]
    sex_age.to_csv(DEST/'primary_sex_differences_within_age.csv',index=False)
    return stats


def association_analysis(source,other_verbal=False):
    d=valid(prepare(source))
    suffix='with_other_verbal' if other_verbal else 'demographic'
    extra=''
    if other_verbal:
        d=d[d[list(VERBAL)].isin([1,2]).all(axis=1)].copy()
        for i,field in enumerate(list(VERBAL)[1:]):d[f'v{i+2}']=yesno(d[field])
        extra=' + v2 + v3 + v4'
    # Keep known age-by-verbal heterogeneity in the reduced model, so a
    # pooled sex interaction cannot merely reflect different age composition.
    f0='note ~ verbal*C(AGE2) + C(SEX) + C(YEAR)'+extra
    f1=f0+' + verbal:C(SEX)'
    f2='note ~ verbal*C(AGE2)*C(SEX) + C(YEAR)'+extra
    m0=check(smf.glm(f0,d,family=sm.families.Binomial()).fit())
    m1=check(smf.glm(f1,d,family=sm.families.Binomial()).fit())
    m2=check(smf.glm(f2,d,family=sm.families.Binomial()).fit())
    # Include age-by-sex main effects in the nested comparator for the joint
    # test of sex-specific verbal associations at any age.
    no_sex_verbal=check(smf.glm('note ~ verbal*C(AGE2) + C(AGE2)*C(SEX) + C(YEAR)'+extra,
        d,family=sm.families.Binomial()).fit())
    no_threeway=check(smf.glm('note ~ verbal*C(AGE2) + C(AGE2)*C(SEX) + verbal*C(SEX) + C(YEAR)'+extra,
        d,family=sm.families.Binomial()).fit())
    results={'n':len(d),'pooled_sex_verbal_interaction':lrt(m1,m0),
        'joint_sex_difference_in_verbal_association':lrt(m2,no_sex_verbal),
        'three_way_interaction':lrt(m2,no_threeway)}
    records=[];ratios=[]
    def vector(age,sex):
        a=pd.DataFrame({'AGE2':[age,age],'SEX':[sex,sex],'YEAR':[2013,2013],'verbal':[0,1],
            'v2':[0,0],'v3':[0,0],'v4':[0,0]})
        x=np.asarray(patsy.build_design_matrices([m2.model.data.design_info],a)[0]);return x[1]-x[0]
    for age in AGE:
        for sex in SEX:
            v=vector(age,sex);beta=float(v@m2.params);se=float(np.sqrt(v@m2.cov_params()@v))
            records.append({'sex':SEX[sex],'age':AGE[age],'age_code':age,'OR':np.exp(beta),
                'ci_lower':np.exp(beta-1.96*se),'ci_upper':np.exp(beta+1.96*se)})
        v=vector(age,2)-vector(age,1);beta=float(v@m2.params);se=float(np.sqrt(v@m2.cov_params()@v))
        ratios.append({'age':AGE[age],'age_code':age,'female_vs_male_ratio_of_ORs':np.exp(beta),
            'ci_lower':np.exp(beta-1.96*se),'ci_upper':np.exp(beta+1.96*se),'p':2*norm.sf(abs(beta/se))})
    pd.DataFrame(records).to_csv(DEST/f'{suffix}_note_verbal_OR_by_age_sex.csv',index=False)
    tab=pd.DataFrame(ratios);tab['q_BH_5']=multipletests(tab.p,method='fdr_bh')[1]
    tab.to_csv(DEST/f'{suffix}_sex_contrasts_of_note_verbal_ORs.csv',index=False)
    return results


def draw():
    plt.rcParams.update({'font.family':'Arial','font.size':9,'pdf.fonttype':42,'svg.fonttype':'none'})
    tab=pd.read_csv(DEST/'primary_adjusted_age_sex_profiles.csv')
    diff=pd.read_csv(DEST/'primary_adjusted_sex_differences.csv')
    ors=pd.read_csv(DEST/'with_other_verbal_note_verbal_OR_by_age_sex.csv')
    colors=['#808891','#2969a3','#b77d28','#388779'];shapes=['o','s','D','^']
    fig,axes=plt.subplots(2,2,figsize=(12,9.5))
    fig.subplots_adjust(left=.15,right=.98,top=.85,bottom=.16,hspace=.6,wspace=.38)
    for i,sex in enumerate(['Male','Female']):
        ax=axes[0,i]
        for k,profile in enumerate(PROFILES):
            a=tab[tab.sex.eq(sex)&tab.profile.eq(profile)].sort_values('age_code');x=np.arange(5)+(k-1.5)*.04
            ax.plot(x,a.percent,color=colors[k],lw=1)
            ax.errorbar(x,a.percent,yerr=[a.percent-a.ci_lower_percent,a.ci_upper_percent-a.percent],fmt=shapes[k],
                ms=4,color=colors[k],capsize=2,lw=.8)
        ax.set_xticks(range(5),list(AGE.values()));ax.set_ylim(0,65);ax.set_yticks(range(0,61,10));ax.set_xlabel('Age group, y');ax.set_ylabel('Adjusted proportion, %')
        ax.set_title(f'{"AB"[i]}  {sex} communication profiles',loc='left',fontweight='bold',fontsize=11)
        ax.grid(axis='y',color='#e6e6e6',lw=.5)
    ax=axes[1,0];ax.axvline(0,color='#777777',ls=':',lw=.8)
    for k,profile in enumerate(PROFILES):
        a=diff[diff.profile.eq(profile)].iloc[0];v=a.female_minus_male_pp
        ax.errorbar(v,k,xerr=[[v-a.ci_lower_pp],[a.ci_upper_pp-v]],fmt=shapes[k],color=colors[k],
            mfc=colors[k] if a.q_BH_4<.05 else 'white',ms=5,capsize=3)
    ax.set_yticks(range(4),PROFILES);ax.invert_yaxis();ax.set_xlabel('Female minus male, adjusted percentage points')
    ax.set_title('C  Differences standardized for age and year',loc='left',fontweight='bold',fontsize=10.5)
    ax=axes[1,1];ax.axvline(1,color='#777777',ls=':',lw=.8)
    for i,(sex,color,marker) in enumerate([('Male','#355f89','o'),('Female','#a06482','s')]):
        a=ors[ors.sex.eq(sex)].sort_values('age_code')
        ax.errorbar(a.OR,np.arange(5)+(i-.5)*.18,xerr=[a.OR-a.ci_lower,a.ci_upper-a.OR],fmt=marker,
            color=color,ms=4.5,capsize=2.5,lw=.8,label=sex)
    ax.set_xscale('log');ax.set_yticks(range(5),list(AGE.values()));ax.invert_yaxis()
    ax.set_xlim(.48,1.68);ax.xaxis.set_major_locator(FixedLocator([.5,.75,1,1.5]))
    ax.xaxis.set_major_formatter(FixedFormatter(['0.5','0.75','1.0','1.5']));ax.xaxis.set_minor_locator(NullLocator())
    ax.set_xlabel('Adjusted odds ratio for note presence');ax.set_title('D  Note–verbal association by age and sex',loc='left',fontweight='bold',fontsize=10.5)
    ax.legend(frameon=False,loc='upper left',bbox_to_anchor=(0,-.22),ncol=2)
    for ax in axes.flat:ax.spines[['top','right']].set_visible(False)
    fig.suptitle('Recorded Communication Profiles by Sex and Age',fontsize=15,fontweight='bold',y=.97)
    fig.legend(handles=[Line2D([],[],color=c,marker=m,lw=1,ms=4,label=p) for p,c,m in zip(PROFILES,colors,shapes)],
        loc='upper center',bbox_to_anchor=(.55,.925),ncol=4,frameon=False)
    fig.text(.15,.035,'Points and error bars indicate estimates and pointwise 95% CIs. In C, filled markers indicate FDR-adjusted P < .05.\n'
        'A–B: sex-by-age model, standardized for year. D: adjusted for age, year, and other verbal categories.\n'
        'Verbal indicator: talk about suicide, homicide, or death. Recorded sex does not measure gender identity.',fontsize=8,color='#444444',linespacing=1.5)
    for ext in ['png','pdf','svg']:fig.savefig(DEST/f'communication_sex_age_profiles.{ext}',dpi=240)
    plt.close(fig)


def main():
    source=pd.read_pickle(input_path('demographic_source'))
    summary={}
    for name in ['primary','legacy_parent_skips','any_verbal']:
        summary[name]=profile_analysis(source,name);print('Profiles:',name,flush=True)
    summary['note_verbal_demographic']=association_analysis(source)
    summary['note_verbal_other_categories']=association_analysis(source,True)
    a=prepare(source);a=a[a.note.notna()&a.SEX.isin([1,2])&a.AGE2.isin(AGE)].copy()
    missing=[]
    for (sex,note),g in a.groupby(['SEX','note']):
        missing.append({'sex':SEX[sex],'note':int(note),'n':len(g),'verbal_unknown_percent':100*g.verbal.isna().mean()})
    pd.DataFrame(missing).to_csv(DEST/'verbal_missingness_by_sex_note.csv',index=False)
    (DEST/'summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    draw()
    print(json.dumps(summary,indent=2))


if __name__=='__main__':
    with threadpool_limits(limits=4):main()
