"""Local, paired theme sensitivity analysis; never imports or runs KeyBERT.

Run with the configured NLP Python. Original data and scripts are read-only.
The main ablation retains KLUE tokenization and dictionary exact membership,
but scans every CountVectorizer unigram candidate rather than five ranked words.
The secondary variant matches dictionary strings anywhere in section text.
"""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import os
import sys
from functools import lru_cache

os.environ['USE_TF'] = '0'
os.environ['TRANSFORMERS_NO_TF'] = '1'
os.environ['TOKENIZERS_PARALLELISM'] = 'false'
P = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(P))
from project import input_path
import numpy as np
import pandas as pd
from scipy.stats import binomtest
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import adjusted_rand_score, cohen_kappa_score
from scipy.optimize import linear_sum_assignment
from statsmodels.stats.multitest import multipletests
from transformers import AutoTokenizer
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

OUT = P / 'outputs/dictionary_only_sensitivity'
OUT.mkdir(parents=True, exist_ok=True)
SECTIONS = ['1st_section', '2nd_section', '3rd_section']
THEMES = ['Sorry and Shame', 'Love and Gratitude', 'Burden', 'Despair', 'Post-mortem Affairs']
PREFIXES = ['sorry', 'loveandgratitude', 'burdensome', 'despair', 'pmaffairs']
PRESENCE = [p + 'sentence_presence' for p in PREFIXES]
FEATURES = [f'Section {s} {t}' for s in range(1, 4) for t in THEMES]


def load_module(name, relative):
    spec = importlib.util.spec_from_file_location(name, P / relative)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main():
    source = P / 'reference/originals/Splitting raw notes (1. Gender controlled).py'
    dictionaries = {}
    for node in ast.parse(source.read_text(encoding='utf-8-sig')).body:
        if isinstance(node, ast.Assign) and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name):
            if node.targets[0].id in PREFIXES:
                dictionaries[node.targets[0].id] = ast.literal_eval(node.value)
    targets = [set(dictionaries[p]) for p in PREFIXES]
    raw = pd.read_pickle(input_path('raw_features'))
    data = raw.loc[raw.too_short.eq(False)].copy()
    assert data.index.is_unique
    assert all(data[c].map(lambda x: isinstance(x, str)).all() for c in SECTIONS)
    n = len(data)
    baseline = np.stack([np.asarray(data[c].tolist(), dtype=np.uint8) for c in PRESENCE], axis=2)
    assert baseline.shape == (n, 3, 5)
    # Verify stored flags against actual original keyword-token membership.
    recomputed = np.zeros_like(baseline)
    for s, c in enumerate(SECTIONS):
        for r, entry in enumerate(data['tokenizedkluekeywordsentencetransformer_' + c]):
            tokens = {t for t, score in entry} if isinstance(entry, list) else set()
            recomputed[r, s] = [bool(tokens & target) for target in targets]
    assert np.array_equal(baseline, recomputed), 'Saved baseline flags do not match dictionary'
    print(f'Baseline verified: {n:,} notes, {n*15:,} indicators.', flush=True)

    tokenizer = AutoTokenizer.from_pretrained('klue/roberta-large', local_files_only=True)
    analyzer = CountVectorizer(ngram_range=(1, 1), stop_words=None).build_analyzer()

    @lru_cache(maxsize=None)
    def word_tokens(word):
        return frozenset(t for t in tokenizer.tokenize(word) if '#' not in t)

    variants = {'keybert_saved': baseline}
    token_only = np.zeros_like(baseline)
    substring = np.zeros_like(baseline)
    candidate_audit = []
    for s, column in enumerate(SECTIONS):
        for r, text in enumerate(data[column]):
            words = set(analyzer(text))
            tokens = set().union(*(word_tokens(w) for w in words)) if words else set()
            token_only[r, s] = [bool(tokens & target) for target in targets]
            substring[r, s] = [any(term in text for term in target) for target in targets]
            # Candidate coverage check: every saved ranked word should come from
            # this candidate vocabulary, making the ablation a strict superset.
            saved = data['kluekeywordsentencetransformer_' + column].iloc[r]
            if isinstance(saved, list):
                for word, score in saved:
                    if word not in words:
                        candidate_audit.append({'section': s+1, 'row_position': r})
        print(f'Scanned {column}; cached {word_tokens.cache_info().currsize:,} unique words.', flush=True)
    variants['dictionary_all_tokens'] = token_only
    variants['dictionary_substring'] = substring
    assert not candidate_audit, 'Saved words outside the reconstructed candidate vocabulary'
    assert not ((baseline == 1) & (token_only == 0)).any(), 'Ablation lost baseline positives'

    # Save only source index, demographic covariates and binary flags locally.
    for name, matrix in variants.items():
        frame = data[['SEX', 'AGE2', 'too_short']].copy()
        for t, column in enumerate(PRESENCE):
            frame[column] = matrix[:, :, t].tolist()
        frame['full_theme_vector'] = matrix.reshape(n, 15).tolist()
        frame.to_pickle(OUT / f'{name}_features.pkl')

    prevalence_rows = []
    summary = {'n_notes': n, 'baseline_flag_mismatches': int((baseline != recomputed).sum()),
               'candidate_coverage_mismatches': len(candidate_audit), 'methods': {}}
    for name, matrix in variants.items():
        if name == 'keybert_saved':
            continue
        summary['methods'][name] = {
            'notes_with_any_changed_indicator': int(np.any(matrix != baseline, axis=(1, 2)).sum()),
            'changed_indicators': int((matrix != baseline).sum()),
            'indicator_change_percent': float(100*(matrix != baseline).mean()),
            'mean_themes_per_section_baseline': float(baseline.sum(axis=2).mean()),
            'mean_themes_per_section_dictionary': float(matrix.sum(axis=2).mean()),
        }
        for s in range(3):
            for t, theme in enumerate(THEMES):
                a, b = baseline[:, s, t], matrix[:, s, t]
                added = int(((a == 0) & (b == 1)).sum())
                lost = int(((a == 1) & (b == 0)).sum())
                prevalence_rows.append({'method': name, 'section': s+1, 'theme': theme,
                    'n': n, 'keybert_count': int(a.sum()), 'dictionary_count': int(b.sum()),
                    'keybert_percent': 100*a.mean(), 'dictionary_percent': 100*b.mean(),
                    'difference_percentage_points': 100*(b.astype(float)-a).mean(),
                    'added': added, 'lost': lost, 'agreement': float((a == b).mean()),
                    'kappa': float(cohen_kappa_score(a, b)),
                    'mcnemar_exact_p': binomtest(added, added+lost, 0.5).pvalue if added+lost else 1.0})
    prev = pd.DataFrame(prevalence_rows)
    prev['mcnemar_bh_q'] = prev.groupby('method')['mcnemar_exact_p'].transform(lambda x: multipletests(x, method='fdr_bh')[1])
    prev.to_csv(OUT / 'theme_prevalence_comparison.csv', index=False)

    # Reuse the study's regression implementation, including its two theme FDR
    # families (75 age coefficients together and 15 sex coefficients together).
    assoc = load_module('theme_associations', 'figures/fig05_06_association_heatmaps.py')
    estimates = {}
    for name, matrix in variants.items():
        print(f'Fitting demographic models: {name}', flush=True)
        estimates[name] = assoc.fit_demographic_models(data[['SEX', 'AGE2']],
            pd.DataFrame(matrix.reshape(n, 15), index=data.index, columns=FEATURES), FEATURES)
        estimates[name].to_csv(OUT / f'{name}_demographic_estimates.csv', index=False)
    comparisons = []
    for name in list(variants)[1:]:
        joined = estimates['keybert_saved'].merge(estimates[name], on=['Feature', 'Demographic'], suffixes=('_keybert', '_dictionary'), validate='one_to_one')
        joined['method'] = name
        joined['sign_changed'] = np.sign(joined.Coefficient_keybert) != np.sign(joined.Coefficient_dictionary)
        joined['significant_keybert'] = joined['p-value FDR_keybert'] < .05
        joined['significant_dictionary'] = joined['p-value FDR_dictionary'] < .05
        joined['absolute_coefficient_change'] = abs(joined.Coefficient_dictionary - joined.Coefficient_keybert)
        comparisons.append(joined)
        summary['methods'][name]['demographic'] = {
            'n_coefficients': len(joined), 'keybert_significant': int(joined.significant_keybert.sum()),
            'dictionary_significant': int(joined.significant_dictionary.sum()),
            'retained_significant': int((joined.significant_keybert & joined.significant_dictionary).sum()),
            'lost_significance': int((joined.significant_keybert & ~joined.significant_dictionary).sum()),
            'gained_significance': int((~joined.significant_keybert & joined.significant_dictionary).sum()),
            'all_sign_changes': int(joined.sign_changed.sum()),
            'both_significant_opposite_direction': int((joined.sign_changed & joined.significant_keybert & joined.significant_dictionary).sum()),
            'coefficient_correlation': float(joined.Coefficient_keybert.corr(joined.Coefficient_dictionary)),
            'median_absolute_coefficient_change': float(joined.absolute_coefficient_change.median())}
    pd.concat(comparisons).to_csv(OUT / 'demographic_comparison.csv', index=False)

    print('Refitting PCA and KMeans with common settings.', flush=True)
    labels = {}
    cluster_summary = {}
    saved = pd.read_pickle(input_path('theme_clusters')).loc[data.index]
    assert np.array_equal(np.asarray(saved.full_theme_vector.tolist()), baseline.reshape(n, 15))
    for name, matrix in variants.items():
        # Explicit full solver avoids sklearn auto changing across environments.
        pca = PCA(n_components=5, random_state=0, svd_solver='full')
        scores = pca.fit_transform(matrix.reshape(n, 15).astype(float))
        labels[name] = KMeans(n_clusters=15, random_state=0, n_init=10).fit_predict(scores)
        cluster_summary[name] = {'five_pc_variance_explained': float(pca.explained_variance_ratio_.sum())}
        pd.DataFrame(matrix.reshape(n, 15), columns=FEATURES).groupby(labels[name]).mean().to_csv(OUT / f'{name}_cluster_centroids.csv')
    for name in list(variants)[1:]:
        contingency = pd.crosstab(labels['keybert_saved'], labels[name])
        row, col = linear_sum_assignment(-contingency.to_numpy())
        matched = contingency.to_numpy()[row, col].sum()
        cluster_summary[name].update(adjusted_rand_vs_common_baseline=float(adjusted_rand_score(labels['keybert_saved'], labels[name])),
            adjusted_rand_vs_saved_labels=float(adjusted_rand_score(saved.theme_cluster_pca, labels[name])),
            best_matched_cluster_agreement=float(matched/n))
        contingency.to_csv(OUT / f'{name}_cluster_crosstab.csv')
    cluster_summary['keybert_saved']['adjusted_rand_vs_saved_labels'] = float(adjusted_rand_score(saved.theme_cluster_pca, labels['keybert_saved']))
    summary['clustering'] = cluster_summary
    pd.DataFrame(labels, index=data.index).to_csv(OUT / 'local_cluster_assignments.csv', index_label='source_index')

    # Original transition arithmetic, descriptive probabilities and log2 lift.
    transition = load_module('theme_transitions', 'figures/fig07_transitions.py')
    transition_records = []
    for name, matrix in variants.items():
        frame = pd.DataFrame(matrix.reshape(n, 15), columns=FEATURES)
        for s in range(2):
            from_cols, to_cols = FEATURES[s*5:(s+1)*5], FEATURES[(s+1)*5:(s+2)*5]
            _, probability, _, _ = transition.compute_transition_probability(frame, from_cols, to_cols, THEMES)
            loglift = transition.compute_log2_lift(frame, from_cols, to_cols, THEMES)
            for i, a in enumerate(THEMES):
                for j, b in enumerate(THEMES):
                    transition_records.append({'method': name, 'window': f'{s+1}_to_{s+2}', 'from_theme': a, 'to_theme': b,
                        'probability': float(probability.iloc[i,j]), 'log2_lift': float(loglift.iloc[i,j])})
    pd.DataFrame(transition_records).to_csv(OUT / 'transition_estimates.csv', index=False)

    fig, axes = plt.subplots(1, 3, figsize=(16, 5), sharey=True)
    colors = ['#355c85', '#d47a35', '#4b9173']
    y = np.arange(5)
    for s, ax in enumerate(axes):
        for k, (name, matrix) in enumerate(variants.items()):
            ax.barh(y + (k-1)*.24, 100*matrix[:,s,:].mean(axis=0), height=.22,
                    color=colors[k], label={'keybert_saved':'Original: KeyBERT top 5', 'dictionary_all_tokens':'Dictionary: all KLUE tokens', 'dictionary_substring':'Dictionary: text substrings'}[name])
        ax.set_yticks(y, THEMES)
        ax.set_title(['Opening', 'Middle', 'Ending'][s])
        ax.set_xlabel('Notes with theme (%)')
        ax.set_xlim(0, 85)
        ax.spines[['top','right']].set_visible(False)
    axes[0].invert_yaxis()
    handles, names = axes[0].get_legend_handles_labels()
    fig.legend(handles, names, loc='lower center', ncol=3, frameon=False)
    fig.suptitle(f'Removing KeyBERT: paired comparison of {n:,} notes')
    fig.tight_layout(rect=(0,.09,1,.94))
    fig.savefig(OUT / 'theme_prevalence_comparison.png', dpi=180)
    fig.savefig(OUT / 'theme_prevalence_comparison.pdf')
    plt.close(fig)

    manifest = {'source_data': str(input_path('raw_features')), 'source_sha256': hashlib.sha256(input_path('raw_features').read_bytes()).hexdigest(),
        'dictionary_source': str(source), 'dictionaries': dictionaries,
        'dictionary_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
        'tokenizer': 'klue/roberta-large, local_files_only=True',
        'tokenizer_vocab_sha256': hashlib.sha256(json.dumps(tokenizer.get_vocab(), sort_keys=True).encode()).hexdigest(),
        'primary_method': 'All default CountVectorizer unigram candidates; KLUE tokenization; discard tokens containing #; exact dictionary membership.',
        'secondary_method': 'Case-sensitive dictionary substring anywhere in section; no tokenizer, word boundaries or negation handling.',
        'cohort': 'raw.pkl too_short == False; original saved primary sections and cohort, no reclassification.',
        'limitations': ['No new KeyBERT or sentiment model run; original KeyBERT output reused as paired baseline.',
            'Transition probabilities/lifts rerun descriptively; transition permutation tests and alternative section/sentence robustness schemes are not rerun.',
            'Substring matching can match unrelated longer words; agreement does not establish accuracy without manual labels.',
            'Significance changes between demographic models are sensitivity descriptors, not formal tests of coefficient differences.',
            'PCA uses full solver for all three refits; cluster labels are matched without reusing old semantic names.']}
    (OUT / 'run_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    (OUT / 'summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2), flush=True)
    print('Outputs:', OUT, flush=True)


if __name__ == '__main__':
    main()
