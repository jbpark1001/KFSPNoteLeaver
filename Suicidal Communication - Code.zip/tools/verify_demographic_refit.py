"""Compare newly fitted demographic estimates with the original saved table."""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import ROOT,input_path,output_path

def main():
    old=pd.read_excel(input_path('existing_odds_ratios'))
    new=pd.read_excel(ROOT/'outputs/tables/or_table_Cut_2_DF_50Columns.xlsx')
    assert old.term.is_unique and new.term.is_unique and set(old.term)==set(new.term)
    a=old.set_index('term').sort_index();b=new.set_index('term').sort_index()
    rows=[]
    for col in ['estimate','std.error','statistic','p.value','conf.low','conf.high']:
        np.testing.assert_allclose(a[col],b[col],rtol=1e-8,atol=1e-10,equal_nan=True)
        finite=np.isfinite(a[col])&np.isfinite(b[col])
        rows.append(dict(column=col,terms=len(a),finite_pairs=int(finite.sum()),
                         maximum_absolute_difference=float(abs(a.loc[finite,col]-b.loc[finite,col]).max()),matches=True))
    pd.DataFrame(rows).to_csv(output_path('validation/demographic_refit_parity.csv'),index=False)
    result={'passed':True,'terms':len(a),'checks':rows,
            'comparison':'Fresh final-model fit and profile-likelihood intervals versus original saved odds-ratio table',
            'limitation':'Agreement with a saved result is not independent validation of study design or source data.'}
    output_path('validation/demographic_refit_parity.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

if __name__=='__main__':main()
