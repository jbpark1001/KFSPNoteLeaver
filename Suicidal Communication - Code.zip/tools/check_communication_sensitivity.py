"""Additional robustness checks and numeric validation for communication models."""
from analyze_communication_profiles import *


def main():
    source=pd.read_pickle(input_path('demographic_source'))
    d=valid(prepare(source));out={}
    # Sensitivity to differential availability of verbal records. Missing at
    # random conditional on observed note, age, sex and year is an assumption.
    allnote=prepare(source)
    allnote=allnote[allnote.note.notna()&allnote.AGE2.isin(AGE)&allnote.SEX.isin([1,2])].copy()
    allnote['observed']=allnote.verbal.notna().astype(int)
    response=check(smf.glm('observed ~ note*C(AGE2) + C(SEX) + C(YEAR)',allnote,family=sm.families.Binomial()).fit())
    d['ipw']=1/response.predict(d)
    f=check(smf.glm('note ~ verbal + C(AGE2) + C(SEX) + C(YEAR)',d,
        family=sm.families.Binomial(),freq_weights=d.ipw).fit())
    interaction=check(smf.glm('note ~ verbal*C(AGE2) + C(SEX) + C(YEAR)',d,
        family=sm.families.Binomial(),freq_weights=d.ipw).fit())
    out['IPW']={'adjusted_OR':float(np.exp(f.params['verbal'])),'weight_min':float(d.ipw.min()),
        'weight_max':float(d.ipw.max()),'assumption':'Verbal response missing at random conditional on note, age, sex, year; weighted CIs not reported.'}
    rows=[]
    for age in AGE:
        beta=interaction.params['verbal']+(interaction.params[f'verbal:C(AGE2)[T.{age}]'] if age!=1 else 0)
        rows.append({'age':AGE[age],'age_code':age,'IPW_adjusted_OR':float(np.exp(beta))})
    pd.DataFrame(rows).to_csv(OUT/'IPW_age_sensitivity.csv',index=False)
    a=d[d.S_AFTERMURDER.eq(2)].copy()
    out['excluding_recorded_homicide_suicide'],_=association(a,'excluding_homicide_suicide')
    # All situational variables together, known responses only. This smaller
    # selected cohort is a robustness analysis rather than the primary sample.
    complete=d[d[list(SITUATIONS)].isin([1,2]).all(axis=1)].copy()
    for field in SITUATIONS:complete[field]=yesno(complete[field])
    formula='C(AGE2) + C(SEX) + C(YEAR) + '+' + '.join(SITUATIONS)
    m,x=fit_mn(complete,formula)
    records=[]
    for field,label in SITUATIONS.items():
        for j in range(3):
            b=m.params.loc[field,j];se=m.bse.loc[field,j]
            records.append({'variable':field,'label':label,'profile_vs_neither':PROFILES[j+1],'n':len(complete),
                'RRR':float(np.exp(b)),'ci_lower':float(np.exp(b-1.96*se)),'ci_upper':float(np.exp(b+1.96*se)),
                'p':float(m.pvalues.loc[field,j])})
    tab=pd.DataFrame(records);tab['q_BH_27']=multipletests(tab.p,method='fdr_bh')[1]
    tab.to_csv(OUT/'joint_situational_complete_case.csv',index=False)
    out['joint_situational_n']=len(complete)
    out['joint_situational_counts']={label:int(complete.profile.eq(k).sum()) for k,label in enumerate(PROFILES)}
    # The four verbal categories overlap. Check the death-talk association
    # with the other three categories held constant, on a common complete set.
    verbal_complete=source[source[list(VERBAL)].isin([1,2]).all(axis=1)].copy()
    verbal_complete=valid(prepare(verbal_complete))
    for i,field in enumerate(VERBAL):verbal_complete[f'v{i+1}']=yesno(verbal_complete[field])
    common_formula='note ~ v1 + v2 + v3 + v4 + C(AGE2) + C(SEX) + C(YEAR)'
    vf=check(smf.glm(common_formula,verbal_complete,family=sm.families.Binomial()).fit())
    vi=check(smf.glm('note ~ v1*C(AGE2) + v2 + v3 + v4 + C(SEX) + C(YEAR)',verbal_complete,family=sm.families.Binomial()).fit())
    out['mutually_adjusted_verbal']={'n':len(verbal_complete),'death_talk_OR':float(np.exp(vf.params['v1'])),
        'death_talk_CI':np.exp(vf.conf_int().loc['v1']).tolist(),
        'age_interaction_p':float(chi2.sf(2*(vi.llf-vf.llf),4))}
    age_verbal=[]
    for age in AGE:
        vector=pd.Series(0.,index=vi.params.index);vector['v1']=1
        if age!=1:vector[f'v1:C(AGE2)[T.{age}]']=1
        beta=float(vector@vi.params);se=float(np.sqrt(vector@vi.cov_params()@vector))
        age_verbal.append({'age':AGE[age],'age_code':age,'OR':float(np.exp(beta)),
            'ci_lower':float(np.exp(beta-1.96*se)),'ci_upper':float(np.exp(beta+1.96*se))})
    pd.DataFrame(age_verbal).to_csv(OUT/'mutually_adjusted_verbal_age_associations.csv',index=False)
    vtab=[]
    for i,field in enumerate(VERBAL):
        ci=np.exp(vf.conf_int().loc[f'v{i+1}'])
        vtab.append({'field':field,'label':VERBAL[field],'OR':float(np.exp(vf.params[f'v{i+1}'])),
            'ci_lower':float(ci.iloc[0]),'ci_upper':float(ci.iloc[1]),'p':float(vf.pvalues[f'v{i+1}'])})
    pd.DataFrame(vtab).to_csv(OUT/'mutually_adjusted_verbal_categories.csv',index=False)
    # Independent finite-difference check of standardization gradient ordering.
    fit,design=fit_mn(d,'C(AGE2)+C(SEX)+C(YEAR)')
    w=d.groupby(['SEX','YEAR']).size().rename('w').reset_index();weights=w.w.to_numpy()/len(d)
    grid=w.assign(AGE2=5);xx=np.asarray(patsy.build_design_matrices([design.design_info],grid)[0])
    probs=np.asarray(fit.predict(xx));k=3
    grad=np.column_stack([np.sum((weights*probs[:,k]*((k==j)-probs[:,j]))[:,None]*xx,axis=0) for j in range(1,4)]).ravel(order='F')
    params=fit.params.to_numpy();flat=params.ravel(order='F');numeric=[]
    for j in range(len(flat)):
        hi=flat.copy();lo=flat.copy();hi[j]+=1e-5;lo[j]-=1e-5
        a=fit.model.predict(hi.reshape(params.shape,order='F'),xx)[:,k]
        b=fit.model.predict(lo.reshape(params.shape,order='F'),xx)[:,k]
        numeric.append(weights@(a-b)/(2e-5))
    error=float(np.max(abs(grad-numeric)));assert error<1e-7
    out['standardization_gradient_max_error']=error
    # Cross-check four-category counts independently from the binary crosstab.
    counts=pd.crosstab(d.note,d.verbal)
    expected=np.array([counts.loc[0,0],counts.loc[1,0],counts.loc[0,1],counts.loc[1,1]])
    observed=d.profile.value_counts().reindex(range(4)).to_numpy()
    assert np.array_equal(expected,observed)
    out['profile_count_crosscheck']=True
    (OUT/'robustness_summary.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
    # Supplementary figure keeps individual verbal categories separate.
    plt.rcParams.update({'font.family':'Arial','font.size':10,'pdf.fonttype':42,'svg.fonttype':'none'})
    summary=json.loads((OUT/'summary.json').read_text())
    names=['primary_explicit','physical_discomfort','self_deprecating','other_verbal','any_verbal_explicit']
    labels=['Suicide/homicide/death talk','Physical discomfort','Self-deprecating comments','Other verbal signs','Any of the four verbal signs']
    fig,ax=plt.subplots(figsize=(9,4.5))
    for y,name in enumerate(names):
        r=summary['analyses'][name];v=r['overall_adjusted_note_verbal_OR'];lo,hi=r['overall_adjusted_CI']
        ax.errorbar(v,y,xerr=[[v-lo],[hi-v]],fmt='o',color='#426f99' if y<4 else '#b0803f',capsize=3)
        ax.annotate(f'{v:.2f} [{lo:.2f}, {hi:.2f}]',(hi,y),xytext=(8,0),textcoords='offset points',va='center',fontsize=9)
    ax.axvline(1,color='#777777',ls=':');ax.set_yticks(range(5),labels);ax.invert_yaxis();ax.set_xlim(.65,3.05)
    ax.set_xlabel('Adjusted odds ratio for recorded note presence (95% CI)')
    fig.suptitle('Verbal categories differ in their association\nwith recorded note presence',fontweight='bold',fontsize=12,y=.97)
    ax.spines[['top','right']].set_visible(False)
    fig.text(.04,.025,'Separate models adjusted for age, sex and year, requiring explicit verbal yes/no responses.\nCategories overlap. The composite includes nonspecific verbal signs and is not equivalent to suicidal intent.',fontsize=9)
    fig.subplots_adjust(left=.34,right=.98,top=.78,bottom=.24)
    for ext in ['png','pdf','svg']:fig.savefig(OUT/f'verbal_category_comparison.{ext}',dpi=220)
    plt.close(fig)
    print(json.dumps(out,indent=2))


if __name__=='__main__':
    with threadpool_limits(limits=4):main()
