"""Audit current manuscript cohorts without exporting individual records or text."""
from pathlib import Path
import sys,json,hashlib,platform,importlib.metadata
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import input_path,output_path,ROOT

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    d=pd.read_pickle(input_path('demographic_source'))
    raw=pd.read_pickle(input_path('raw_features'));sent=pd.read_pickle(input_path('sentiment_features'))
    assert d.index.is_unique and raw.index.is_unique and sent.index.is_unique
    primary=raw[raw.too_short.eq(False)]
    complete=primary[primary.SEX.isin([1,2])&primary.AGE2.isin(range(1,6))]
    comm=d[d.NOTE_EX.isin([1,2])&d.WARNSPEAK1.isin([1,2])&d.SEX.isin([1,2])&d.AGE2.isin(range(1,6))&d.YEAR.between(2013,2020)]
    expected={'registry':102922,'note_yes':38044,'note_no':59603,'note_unknown':5275,
              'known_note':97647,'communication':79083,'communication_other_verbal':79063,
              'section_eligible':18635,'section_complete':18630,'linked_theme':15163,'linked_sentiment':15163}
    fields=['YEAR','SEX','AGE2','SUICIDE_DATE','NOTE_CONTENTDTL']
    def linked(frame):
        a=d[fields].astype('string').fillna('<MISSING>');b=frame[fields].astype('string').fillna('<MISSING>')
        ah=pd.util.hash_pandas_object(a,index=False);bh=pd.util.hash_pandas_object(b,index=False)
        lookup=pd.Series(d.index[~ah.duplicated(False)],index=ah[~ah.duplicated(False)].to_numpy())
        match=bh.map(lookup).where(~bh.duplicated(False)).dropna().astype(int)
        joined=d.loc[match.values].copy();joined.index=match.index
        for c in fields: assert a.loc[match.values,c].to_numpy().tolist()==b.loc[match.index,c].to_numpy().tolist()
        joined=joined[frame.loc[joined.index,'too_short'].eq(False)&joined.NOTE_EX.eq(1)&joined.WARNSPEAK1.isin([1,2])&joined.SEX.isin([1,2])&joined.AGE2.isin(range(1,6))&joined.YEAR.between(2013,2020)]
        return len(joined)
    actual=dict(registry=len(d),note_yes=int(d.NOTE_EX.eq(1).sum()),note_no=int(d.NOTE_EX.eq(2).sum()),
                note_unknown=int((~d.NOTE_EX.isin([1,2])).sum()),known_note=int(d.NOTE_EX.isin([1,2]).sum()),
                communication=len(comm),communication_other_verbal=int(comm[['WARNSPEAK2','WARNSPEAK3','WARNSPEAK4']].isin([1,2]).all(axis=1).sum()),
                section_eligible=len(primary),section_complete=len(complete),linked_theme=linked(raw),linked_sentiment=linked(sent))
    checks=[dict(item=k,expected=v,actual=actual[k],matches=v==actual[k]) for k,v in expected.items()]
    pd.DataFrame(checks).to_csv(output_path('validation/cohort_checks.csv'),index=False)
    versions={'python':platform.python_version()}
    for name in ['numpy','pandas','scipy','statsmodels','scikit-learn','patsy','threadpoolctl']:
        versions[name]=importlib.metadata.version(name)
    inputs={k:dict(path=str(input_path(k)),sha256=sha(input_path(k))) for k in ['demographic_source','raw_features','sentiment_features','eligible_notes','section_annotations','sentence_flags']}
    # Cross-version membership is evidence, never silently repaired by a count match.
    meta=pd.read_excel(input_path('section_annotations'),usecols=['pred_label'])
    old_raw=raw.index.intersection(meta.index)
    version=dict(saved_raw_rows=len(raw),newer_classifier_counts=meta.pred_label.value_counts().to_dict(),
                 saved_section_notes_newer_classifier_calls_summarized=int(meta.loc[primary.index,'pred_label'].eq('summarized').sum()),
                 saved_raw_ids_present_in_metadata=len(old_raw))
    report=dict(cohort_checks=checks,versions=versions,input_fingerprints=inputs,classifier_cohort_version=version,
                all_checked_counts_match=all(x['matches'] for x in checks),
                limitation='Matching counts do not establish cohort identity, NLP validity, or reproduction of every manuscript claim.')
    output_path('validation/input_audit.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'cohort_checks':checks,'classifier_cohort_version':version},indent=2))
    if not report['all_checked_counts_match']: raise SystemExit('Cohort mismatches require reconciliation')

if __name__=='__main__':main()
