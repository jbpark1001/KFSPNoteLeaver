"""Check full-cohort permutation inputs against independently built stage-15 tables."""
from pathlib import Path
import sys,json,argparse,importlib.util
import numpy as np
import pandas as pd
from threadpoolctl import threadpool_limits
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import ROOT,input_path,output_path

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--reference-dir',type=Path,default=ROOT/'outputs/tables/sentence_robustness')
    args=parser.parse_args()
    spec=importlib.util.spec_from_file_location('permutation',ROOT/'text_analysis/18_sentence_order_permutation.py')
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
    f=pd.read_csv(args.reference_dir/'sent_real_third_sentence_theme_features_df.csv')
    f=f[f.SEX.isin([1,2])&f.AGE2.isin(range(1,6))].sort_values('note_id');ids=f.note_id.to_numpy()
    assert len(f)==18648 and f.note_id.is_unique
    cols=['note_id','third_bin']+['theme_'+t for t in m.THEMES]
    s=pd.read_csv(input_path('sentence_flags'),usecols=cols)
    s=s[s.note_id.isin(ids)].sort_values('note_id')
    note=pd.Categorical(s.note_id,categories=ids).codes
    flags=s[['theme_'+t for t in m.THEMES]].to_numpy()
    x=m.aggregate(flags,note,s.third_bin.to_numpy()-1,len(ids))
    expected=f[[f'sent_real_third Section {b} {t}' for b in range(1,4) for t in m.THEMES]].to_numpy()
    np.testing.assert_array_equal(x,expected)
    state=dict(note=note,bins=s.third_bin.to_numpy()-1,age=f.AGE2.to_numpy(),male=f.SEX.eq(1).to_numpy(),flags=flags)
    with threadpool_limits(limits=1):_,coef=m.statistics(state,flags)
    prior=pd.read_csv(args.reference_dir/'sent_real_third_sentence_theme_age_results.csv')
    prior=prior[prior.Feature.str.contains('Love and Gratitude')]
    np.testing.assert_allclose(coef,prior.Coefficient.to_numpy().reshape(5,3),atol=1e-10)
    report=dict(passed=True,n_notes=len(ids),binary_indicators_checked=int(x.size),
                max_coefficient_error=float(np.max(abs(coef-prior.Coefficient.to_numpy().reshape(5,3)))),
                comparison='Independently generated sentence feature table and age-regression output',
                reference_directory=str(args.reference_dir),observed_coefficients=coef.tolist())
    output_path('validation/full_cohort_permutation_parity.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
