"""Refine the selected stacked-bar layout without changing estimates."""
from pathlib import Path
import re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

P=Path(__file__).resolve().parents[1]
S=P/'outputs/communication_profiles'
OUT=P/'outputs/publication_communication_figures/refined_stacked'
OUT.mkdir(parents=True,exist_ok=True)
PROFILES=['Neither recorded','Note only','Verbal only','Both recorded']
# Gray and blues from plot_dictionary_only_figures.py; one pale blue added
# because this figure has four categories rather than three sections.
COLORS=['#B8BBBE','#C9DCEF','#88B4E8','#326BA6']
AGES=['≤18','19–34','35–49','50–64','65+']
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.labelsize':10,
    'axes.titlesize':11,'xtick.labelsize':9,'ytick.labelsize':9,
    'axes.linewidth':.65,'pdf.fonttype':42,'svg.fonttype':'none',
    'mathtext.fontset':'custom','mathtext.rm':'Arial','mathtext.it':'Arial:italic',
    'mathtext.bf':'Arial:bold','mathtext.sf':'Arial','mathtext.fallback':None,
    'savefig.facecolor':'white'})
age_obs=pd.read_csv(S/'primary_explicit_profiles_by_age.csv')
age_adj=pd.read_csv(S/'primary_adjusted_profiles_by_age.csv')
sex=pd.read_csv(S/'sex_analysis/primary_profiles_by_sex.csv')
at=pd.read_csv(S/'adjusted_age_profile_contrasts.csv')
at=at[at.family.eq('65plus_vs_19to34')].set_index('profile')
st=pd.read_csv(S/'sex_analysis/primary_adjusted_sex_differences.csv').set_index('profile')

fig,axes=plt.subplots(2,2,figsize=(11.8,8.6))
fig.subplots_adjust(left=.085,right=.97,top=.88,bottom=.14,hspace=.47,wspace=.25)
items=[(age_obs,'age',AGES,'percent','A  Observed age profiles',None),
       (age_adj,'age',AGES,'percent','B  Adjusted age profiles','age'),
       (sex,'sex',['Male','Female'],'observed_percent','C  Observed sex profiles',None),
       (sex,'sex',['Male','Female'],'adjusted_percent','D  Adjusted sex profiles','sex')]
for ax,(table,key,groups,value,title,adjustment) in zip(axes.flat,items):
    x=np.arange(5) if key=='age' else np.array([1,3])
    bottom=np.zeros(len(groups))
    for i,(profile,color) in enumerate(zip(PROFILES,COLORS)):
        a=table[table.profile.eq(profile)].set_index(key).loc[groups,value].to_numpy()
        ax.bar(x,a,bottom=bottom,width=.72,color=color,edgecolor='white',linewidth=.65,zorder=3)
        for xx,group,v,b in zip(x,groups,a,bottom):
            annotation=''
            if adjustment=='age' and group=='65+' and profile in ['Note only','Verbal only']:
                assert at.loc[profile,'q_BH']<.001
                annotation=r'$^{*\!*\!*}$'
            if adjustment=='sex' and group=='Female':
                q=st.loc[profile,'q_BH_4']
                annotation=r'$^{*\!*\!*}$' if q<.001 else r'$^{ns}$'
            ax.text(xx,b+v/2,f'{v:.1f}%'+annotation,ha='center',va='center',
                color='white' if i==3 else '#25282B',fontsize=9.3,zorder=4)
        bottom+=a
    assert np.allclose(bottom,100)
    labels=list(groups)
    if adjustment=='age':labels[1]='19–34\n(reference)'
    if adjustment=='sex':labels[0]='Male\n(reference)'
    ax.set(xticks=x,xticklabels=labels,xlim=(-.55,4.55),ylim=(0,100),
        xlabel='Age group' if key=='age' else 'Recorded sex',
        ylabel='Adjusted proportion, %' if adjustment else 'Observed proportion, %')
    ax.set_yticks(range(0,101,20));ax.spines[['top','right']].set_visible(False)
    ax.spines[['left','bottom']].set_color('#666B70')
    ax.tick_params(length=3,width=.65,color='#666B70')
    ax.set_title(title,loc='left',fontweight='bold',pad=12)
    ax.set_axisbelow(True);ax.grid(axis='y',lw=.45,color='#EAEBED')
fig.suptitle('Recorded Communication Profiles by Age and Sex',fontsize=15,fontweight='bold',y=.975)
fig.legend(handles=[Patch(facecolor=c,edgecolor='none',label=p) for p,c in zip(PROFILES,COLORS)],
    loc='lower right',bbox_to_anchor=(.97,.014),ncol=4,frameon=False,fontsize=10,
    handlelength=1.4,handletextpad=.6,columnspacing=1.8)
stem=OUT/'communication_profiles_stacked_manuscript_palette'
for ext in ['png','pdf','svg','tiff']:
    fig.savefig(stem.with_suffix('.'+ext),dpi=600 if ext=='tiff' else 220,
        **({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tiff' else {}))
plt.close(fig)
fonts=re.findall(rb'/BaseFont\s*/([^\s/<>\[\]()]+)',stem.with_suffix('.pdf').read_bytes())
assert fonts and all(b'Arial' in f for f in fonts),fonts
caption='''Figure. Recorded Communication Profiles by Age and Recorded Sex.

A and C, Observed proportions by age group and recorded sex, respectively.
B, Age-specific predicted proportions from multinomial logistic regression
including categorical age, recorded sex, and calendar year, standardized to
the common sex/year distribution. D, Sex-specific predicted proportions from
multinomial logistic regression including categorical age, recorded sex, their
interaction, and calendar year, standardized to the common age/year distribution.
The sample includes 79,083 eligible decedents. Age groups are expressed in years.

In B, superscript asterisks compare ages 65+ with ages 19-34 for note-only and
verbal-only profiles; BH correction includes these two comparisons. Adjusted
differences are -11.8 percentage points (95% CI, -12.7 to -11.0) and +22.4
percentage points (95% CI, 21.4 to 23.4), respectively. Other age contrasts are
not annotated; stars do not establish significance of every age transition.
In D, superscripts compare female with male decedents within each profile,
with BH correction across four comparisons. Neither recorded is nonsignificant
(adjusted P=.707); note-only, verbal-only, and both-recorded comparisons have
adjusted P<.001. *** indicates FDR-adjusted P<.001; ns indicates adjusted P>=.05.
Tests are of standardized probability differences using the full model
covariance and delta method; confidence intervals are pointwise 95% intervals.
No significance tests are attached to the observed percentages in A or C.

Verbal communication refers to reported talk about suicide, homicide, or death
(WARNSPEAK1). Note-only does not imply absence of other verbal communication;
neither recorded does not establish absence of communication. Unknown/skipped
responses are excluded. Percentages rounded to one decimal may not sum to 100.0.
'''
stem.with_suffix('.caption.txt').write_text(caption,encoding='utf-8')
print('Stacked figure exported in manuscript gray/blue palette; Arial verified.')
print(stem)
