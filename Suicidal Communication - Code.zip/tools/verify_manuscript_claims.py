"""Compare explicitly enumerated current-manuscript claims with new outputs.

Expected values are used only here, never supplied to an estimator.
This is an enumerated claim check, not certification of unlisted statements.
"""
from pathlib import Path
import sys,json
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import ROOT,output_path
ROWS=[]

def check(label,actual,expected,decimals):
    tolerance=0.5*10**(-decimals)+1e-10
    ROWS.append(dict(claim=label,actual=float(actual),reported=expected,tolerance=tolerance,
                     status='match' if abs(float(actual)-expected)<=tolerance else 'mismatch'))

def table(relative):return pd.read_csv(ROOT/'outputs'/relative)
def select(frame,**where):
    for key,value in where.items():frame=frame[frame[key].eq(value)]
    if len(frame)!=1:raise ValueError(f'Ambiguous claim selector: {where}; {len(frame)} rows')
    return frame.iloc[0]

def group(name,callback):
    try:callback()
    except FileNotFoundError as e:ROWS.append(dict(claim=name,status='unavailable',reason=str(e)))

def communication():
    d=table('communication_profiles/primary_explicit_profiles_by_age.csv')
    for age,profile,p in [(2,'Verbal only',27.2),(5,'Verbal only',49.2),(2,'Note only',23.2),(5,'Note only',11.7)]:
        check(f'observed age {age} {profile}',select(d,age_code=age,profile=profile)['percent'],p,1)
    d=table('communication_profiles/adjusted_age_profile_contrasts.csv')
    for profile,values in [('Verbal only',(22.4,21.4,23.4)),('Note only',(-11.8,-12.7,-11.0))]:
        r=select(d,family='65plus_vs_19to34',profile=profile)
        for col,v in zip(['difference_percentage_points','ci_lower_pp','ci_upper_pp'],values):check(f'age contrast {profile} {col}',r[col],v,1)
        check(f'age contrast {profile} q<.001',float(r.q_BH<.001),1,0)
    d=table('communication_profiles/mutually_adjusted_verbal_age_associations.csv')
    for age,values in [(2,(1.13,1.05,1.21)),(5,(.78,.74,.83))]:
        r=select(d,age_code=age)
        for col,v in zip(['OR','ci_lower','ci_upper'],values):check(f'adjusted verbal age {age} {col}',r[col],v,2)
    d=table('communication_profiles/sex_analysis/primary_profiles_by_sex.csv')
    for sex,profile,v in [('Female','Verbal only',40.3),('Male','Verbal only',34.1),('Female','Note only',15.7),('Male','Note only',19.7),('Female','Both recorded',19.4),('Male','Both recorded',21.7),('Female','Neither recorded',24.6),('Male','Neither recorded',24.4)]:
        check(f'adjusted sex {sex} {profile}',select(d,sex=sex,profile=profile)['adjusted_percent'],v,1)
    d=table('communication_profiles/sex_analysis/primary_adjusted_sex_differences.csv')
    r=select(d,profile='Verbal only')
    for col,v in zip(['female_minus_male_pp','ci_lower_pp','ci_upper_pp'],[6.2,5.5,6.9]):check('overall sex '+col,r[col],v,1)
    check('neither sex q',select(d,profile='Neither recorded').q_BH_4,.707,3)
    d=table('communication_profiles/sex_analysis/primary_sex_differences_within_age.csv')
    for age,profile,values in [(2,'Both recorded',(2.6,1.1,4.1)),(5,'Both recorded',(-7.4,-8.4,-6.4)),(5,'Verbal only',(11.0,9.6,12.4))]:
        r=select(d,age_code=age,profile=profile)
        for col,v in zip(['female_minus_male_pp','ci_lower_pp','ci_upper_pp'],values):check(f'within age {age} sex {profile} {col}',r[col],v,1)

def linked_content():
    d=table('communication_profiles/note_content_bridge_models.csv')
    for theme,values in [('Sorry and Shame',(.80,.74,.86)),('Post-mortem Affairs',(.92,.85,.98))]:
        r=select(d,method='keybert_saved',theme=theme)
        for col,v in zip(['OR','ci_lower','ci_upper'],values):check(theme+' '+col,r[col],v,2)
        for method in ['keybert_saved','dictionary_all_tokens','dictionary_substring']:
            check(theme+' FDR '+method,float(select(d,method=method,theme=theme).q_BH_15<.05),1,0)
    d=table('verbal_sentiment_bridge_20261106/all_sentiment_models.csv')
    for label,values in [('Anger',(1.18,1.09,1.27)),('Hatred',(1.22,1.09,1.37)),('Disappointment',(.84,.77,.92)),('Sadness',(.84,.76,.93))]:
        r=select(d,model='primary',sentiment=label)
        for col,v in zip(['OR','ci_lower','ci_upper'],values):check(label+' '+col,r[col],v,2)
        for model in ['primary','length_adjusted','other_verbal_adjusted','duplicate_cluster_robust']:
            check(label+' FDR '+model,float(select(d,model=model,sentiment=label).q_BH_15<.05),1,0)

def prevalence():
    d=table('direct_content_prevalence/adjusted_prevalence_by_age.csv')
    for feature,young,old in [('Burden',12.0,5.5),('Despair',14.7,10.5)]:
        for age,v in [(2,young),(5,old)]:
            r=select(d,method='keybert_saved',domain='theme',feature=feature,section=3,specification='sex_year',age_code=age)
            check(f'ending {feature} age {age} prevalence',r.adjusted_percent,v,1)
    d=table('direct_content_prevalence/all_age_pairwise_differences.csv')
    for feature,values in [('Burden',(-6.5,-7.9,-5.1)),('Despair',(-4.2,-5.8,-2.6))]:
        r=select(d,method='keybert_saved',domain='theme',feature=feature,section=3,specification='sex_year',younger_code=2,older_code=5)
        for col,v in zip(['difference_pp','ci_lower_pp','ci_upper_pp'],values):check(feature+' ending '+col,r[col],v,1)
    d=table('direct_content_prevalence/ordered_age_trend_tests.csv')
    for feature in ['Burden','Despair']:
        for section in range(1,4):
            r=select(d,method='keybert_saved',domain='theme',feature=feature,section=section)
            check(f'{feature} section {section} negative trend FDR<.001',float(r.OR_per_ordered_group<1 and r.q_BH_trends<.001),1,0)

def segmentation():
    for file,scheme,end in [('section_robustness/ALL_SCHEMES_theme_age_ovr_results.csv','quart','Section 4'),('section_robustness/ALL_SCHEMES_theme_age_ovr_results.csv','third5','Section 3'),('sentence_robustness/ALL_sentence_theme_age_results.csv','sent_real_third','Section 3')]:
        d=table('tables/'+file)
        for age,section,theme in [(1,end,'Love and Gratitude'),(2,end,'Love and Gratitude'),(5,'Section 1','Love and Gratitude'),(3,end,'Sorry and Shame')]:
            r=select(d,scheme=scheme,section=section,theme=theme,**{'Age Group':age})
            check(f'{scheme} {section} {theme} age {age} positive, valid, nominal p<.01',float(r['Coefficient']>0 and r['p-value']<.01 and r['Inference Status']=='valid'),1,0)

def permutations():
    d=table('tables/sentence_order_permutation/B4999_seed20261109/results.csv')
    assert len(d)==10 and d.n_perm.eq(4999).all() and d.n.eq(18648).all()
    for age in range(1,6):
        r=select(d,age_code=age,test='coefficient_range')
        check(f'LG range age {age} Holm<=.0028',float(r.p_holm_10<=.0028+1e-12),1,0)
    for age,sign in [(1,1),(2,1),(5,-1)]:
        r=select(d,age_code=age,test='absolute_ending_minus_opening')
        check(f'LG ending-opening age {age} Holm',r.p_holm_10,.002,3)
        check(f'LG ending-opening age {age} sign',float(np.sign(r.signed_ending_minus_opening)==sign),1,0)

def main():
    for name,fn in [('communication',communication),('linked content',linked_content),('prevalence',prevalence),('alternative segmentation',segmentation),('full permutations',permutations)]:group(name,fn)
    pd.DataFrame(ROWS).to_csv(output_path('validation/current_manuscript_claims.csv'),index=False)
    counts=pd.Series([r['status'] for r in ROWS]).value_counts().to_dict()
    report={'enumerated_claims':len(ROWS),'counts':counts,'not_covered':['every demographic coefficient','classifier stability claims','all alternative segmentation coefficients','all figure captions'],
            'interpretation':'Matches at stated rounding precision; not validation of cohort provenance, NLP accuracy, or unlisted claims.'}
    output_path('validation/current_manuscript_claim_summary.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    if counts.get('mismatch',0) or counts.get('unavailable',0):raise SystemExit(1)

if __name__=='__main__':main()
