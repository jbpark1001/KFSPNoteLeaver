"""Four-panel observed/adjusted age and recorded-sex communication profiles."""
from pathlib import Path
import re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

P=Path(__file__).resolve().parents[1]
SRC=P/'outputs/communication_profiles'
OUT=P/'outputs/publication_communication_figures'
OUT.mkdir(parents=True,exist_ok=True)
PROFILES=['Neither recorded','Note only','Verbal only','Both recorded']
COLORS=['#B6BDC5','#4479AD','#CF9850','#5A9587']
AGES=['≤18','19–34','35–49','50–64','65+']
plt.rcParams.update({'font.family':'Arial','font.size':11,'axes.labelsize':11,
    'axes.titlesize':12,'xtick.labelsize':10,'ytick.labelsize':10,
    'axes.linewidth':.8,'pdf.fonttype':42,'svg.fonttype':'none',
    'savefig.facecolor':'white'})

def stars(q):
    return '***' if q<.001 else '**' if q<.01 else '*' if q<.05 else 'ns'

def panel(ax,table,groups,key,value,title,adjusted=None,tests=None):
    bottom=np.zeros(len(groups)); x=np.arange(len(groups))
    width=.70 if key=='age' else .45
    for i,(profile,color) in enumerate(zip(PROFILES,COLORS)):
        d=table[table.profile.eq(profile)].set_index(key).loc[groups]
        v=d[value].to_numpy()
        ax.bar(x,v,bottom=bottom,width=width,color=color,edgecolor='white',linewidth=.45)
        for k,(group,percent,b) in enumerate(zip(groups,v,bottom)):
            mark=''
            if adjusted=='age' and group=='65+' and profile in ['Note only','Verbal only']:
                mark=stars(tests.loc[profile,'q_BH'])
            if adjusted=='sex' and group=='Female':
                mark=stars(tests.loc[profile,'q_BH_4'])
            text=f'{percent:.1f}%'
            # Keep significance next to its estimate; no unanchored stars.
            if mark=='ns':text+=' ns'
            elif mark:text+=f'\n{mark}' if adjusted=='age' else f' {mark}'
            ax.text(k,b+percent/2,text,ha='center',va='center',
                color='#303030' if i==0 else 'white',fontsize=10.5,linespacing=.85)
        bottom+=v
    assert np.allclose(bottom,100),bottom
    ax.set_ylim(0,100);ax.set_yticks(range(0,101,20))
    ticks=list(groups)
    if adjusted=='age':ticks[1]='19–34\n(reference)'
    if adjusted=='sex':ticks[0]='Male\n(reference)'
    ax.set_xticks(x,ticks)
    ax.set_xlim((-.6,len(groups)-.4) if key=='age' else (-.85,1.85))
    ax.set_xlabel('Age group, y' if key=='age' else 'Recorded sex',labelpad=8)
    ax.set_ylabel('Decedents, %')
    ax.set_title(title,loc='left',fontweight='bold',pad=15)
    ax.spines[['top','right']].set_visible(False)
    ax.tick_params(length=3.5,width=.8)

def main():
    observed=pd.read_csv(SRC/'primary_explicit_profiles_by_age.csv')
    adjusted=pd.read_csv(SRC/'primary_adjusted_profiles_by_age.csv')
    sex=pd.read_csv(SRC/'sex_analysis/primary_profiles_by_sex.csv')
    age_tests=pd.read_csv(SRC/'adjusted_age_profile_contrasts.csv')
    age_tests=age_tests[age_tests.family.eq('65plus_vs_19to34')].set_index('profile')
    sex_tests=pd.read_csv(SRC/'sex_analysis/primary_adjusted_sex_differences.csv').set_index('profile')
    assert len(age_tests)==2 and len(sex_tests)==4
    fig,axes=plt.subplots(2,2,figsize=(12.6,10.8))
    fig.subplots_adjust(left=.09,right=.97,top=.855,bottom=.16,wspace=.30,hspace=.47)
    panel(axes[0,0],observed,AGES,'age','percent','A  Observed profiles by age')
    panel(axes[0,1],adjusted,AGES,'age','percent','B  Age profiles adjusted for sex and year',
          'age',age_tests)
    panel(axes[1,0],sex,['Male','Female'],'sex','observed_percent','C  Observed profiles by recorded sex')
    panel(axes[1,1],sex,['Male','Female'],'sex','adjusted_percent',
          'D  Sex profiles adjusted for age and year','sex',sex_tests)
    fig.suptitle('Recorded Written and Verbal Communication by Age and Sex',
        y=.974,fontsize=16,fontweight='bold')
    fig.legend(handles=[Patch(facecolor=c,label=p) for p,c in zip(PROFILES,COLORS)],
        loc='upper center',bbox_to_anchor=(.53,.932),ncol=4,frameon=False,fontsize=11,
        handlelength=1.5,columnspacing=2)
    fig.text(.09,.090,'*** FDR-adjusted P < .001; ns, not significant after FDR correction.',fontsize=10)
    fig.text(.09,.060,'B: stars compare ages 65+ with 19–34 for the note-only and verbal-only profiles.\n'
        'D: symbols compare female with male decedents within each profile; neither recorded, adjusted P = .707.',
        fontsize=9.5,linespacing=1.6,color='#3C3C3C')
    fig.text(.09,.017,'N = 79,083. Verbal indicator: reported talk about suicide, homicide, or death (WARNSPEAK1).\n'
        'Note only refers to absence of this indicator; neither recorded does not establish absence of communication.',
        fontsize=9,color='#4A4A4A',linespacing=1.6)
    stem=OUT/'combined_age_sex_profiles_stacked_significance'
    for ext in ['png','pdf','svg','tiff']:
        fig.savefig(stem.with_suffix('.'+ext),dpi=600 if ext=='tiff' else 240,
                    **({'pil_kwargs':{'compression':'tiff_lzw'}} if ext=='tiff' else {}))
    plt.close(fig)
    fonts=re.findall(rb'/BaseFont\s*/([^\s/<>\[\]()]+)',stem.with_suffix('.pdf').read_bytes())
    assert fonts and all(b'Arial' in f for f in fonts)
    caption='''Figure. Recorded communication profiles by age and recorded sex.
A, Observed percentages across five age groups. B, Predicted percentages from
a multinomial logistic model including categorical age, recorded sex, and year,
standardized to the common sex/year distribution. Stars identify comparisons
between ages 65+ and 19-34 for note-only and verbal-only profiles, with BH
correction across these two contrasts. The adjusted differences are -11.8
percentage points (95% CI, -12.7 to -11.0) and +22.4 percentage points (95% CI,
21.4 to 23.4), respectively. Stars are not tests of every adjacent-age difference
or of the ordered-age trend. Other age-profile contrasts are not annotated.
C, Observed percentages among male and female decedents. D, Predicted
percentages from a multinomial model including age-by-sex interaction and
calendar year, standardized to the common age/year distribution. Stars and ns
compare female with male decedents separately within each profile; BH correction
includes all four comparisons. Female-minus-male differences are +0.13 pp
(95% CI, -0.53 to +0.78; adjusted P=.707) for neither recorded, -4.00 pp
(-4.57 to -3.44) for note-only, +6.21 pp (+5.49 to +6.94) for verbal-only,
and -2.34 pp (-2.94 to -1.73) for both recorded. The last three comparisons
have adjusted P<.001. These are standardized overall sex comparisons and do
not display the age-by-sex interaction or its within-age contrasts.
All panels use the same 79,083 eligible decedents. Observed sample sizes:
male n=54,384; female n=24,699. The verbal indicator is WARNSPEAK1, combining
talk about suicide, homicide, or death. Only explicit yes/no responses are
included. Note-only does not imply absence of other verbal communication;
neither recorded does not establish that no communication occurred.
Percentages are rounded independently to one decimal and may not sum to 100.0.
*** indicates FDR-adjusted P<.001; ns indicates adjusted P>=.05. No inference
is attached to the observed bars in A or C. All estimates are cross-sectional.
'''
    stem.with_suffix('.caption.txt').write_text(caption,encoding='utf-8')
    pd.concat([age_tests.reset_index().assign(comparison='Age 65+ minus 19-34'),
               sex_tests.reset_index().assign(comparison='Female minus male')]).to_csv(
        OUT/'combined_age_sex_significance_data.csv',index=False)
    print('Saved combined figure in PNG, PDF, SVG and 600-dpi TIFF; Arial verified.')

if __name__=='__main__':main()
