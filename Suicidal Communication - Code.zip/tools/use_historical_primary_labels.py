"""Use verified saved historical classifications for the primary text branch.

This imports actual historical outputs; it does not refit the unrecovered
original classifier. All labels, probabilities and raw-note IDs are checked.
"""
from pathlib import Path
import sys,json,hashlib,os
import numpy as np
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import ROOT,input_path,load_frame,derived_path,output_path

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    if os.environ.get('MANUSCRIPT_TEXT_BRANCH')!='historical':
        raise SystemExit('Run with: run.py 10-primary-labels --text-branch historical')
    saved=pd.read_excel(input_path('manual_predictions'))
    ids=pd.to_numeric(saved.iloc[:,0],errors='raise').astype(int)
    assert ids.is_unique and np.array_equal(ids,np.arange(len(saved))) and len(saved)==37462
    assert saved.pred_label.isin(['raw','summarized']).all()
    assert saved.p_summarized.between(0,1).all()
    assert np.array_equal(saved.pred_label,np.where(saved.p_summarized.ge(.5),'summarized','raw'))
    cache=ROOT/'derived/scored_notes.pkl'
    frame=pd.read_pickle(cache) if cache.exists() else load_frame(input_path('eligible_notes'))
    assert frame.index.is_unique and frame.index.equals(pd.Index(ids.to_numpy()))
    normalized=lambda s:s.fillna('').astype(str).str.replace('엄마아빠','엄마 아빠',regex=False)
    assert np.array_equal(normalized(frame.NOTE_CONTENTDTL),normalized(saved.NOTE_CONTENTDTL))
    fields=['YEAR','SEX','AGE2','SUICIDE_DATE','NOTE_CONTENTDTL']
    notes=frame[fields].copy()
    notes['NOTE_CONTENTDTL']=saved.NOTE_CONTENTDTL.to_numpy()
    notes['pred_label']=saved.pred_label.to_numpy();notes['p_summarized']=saved.p_summarized.to_numpy()
    primary=pd.read_pickle(input_path('raw_features'))
    selected=set(notes.index[notes.pred_label.eq('raw')])
    assert selected==set(primary.index) and len(selected)==27294
    for c in ['YEAR','SEX','AGE2','SUICIDE_DATE']:
        assert np.array_equal(notes.loc[primary.index,c].astype('string').fillna('<MISSING>'),primary[c].astype('string').fillna('<MISSING>'))
    assert np.array_equal(normalized(notes.loc[primary.index,'NOTE_CONTENTDTL']),normalized(primary.NOTE_CONTENTDTL))
    section=primary[primary.too_short.eq(False)]
    assert len(section)==18635
    assert len(section[section.SEX.isin([1,2])&section.AGE2.isin(range(1,6))])==18630
    path=derived_path('scored_notes.pkl');path.parent.mkdir(parents=True,exist_ok=True);notes.to_pickle(path)
    report=dict(source='Actual saved historical classifications; original fitted implementation not recovered',
                source_path=str(input_path('manual_predictions')),source_sha256=sha(input_path('manual_predictions')),
                historical_counts=notes.pred_label.value_counts().to_dict(),
                every_saved_raw_id_matches_primary_features=True,primary_section_n=len(section),primary_complete_n=18630,
                all_input_text_rows_checked=len(notes),metadata_fields_checked=['YEAR','SEX','AGE2','SUICIDE_DATE'],
                label_generation='imported historical predictions, not newly fitted',
                downstream_rebuild='New KSS/model versions can still change segmentation/features; frozen saved route retains the verified published cohort.',
                manuscript_implication='Primary classifier count is 27,294 raw / 10,168 summarized; the newer 25,992 count and its robustness metrics are a distinct classifier version.')
    derived_path('classifier_provenance.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    output_path('validation/historical_primary_label_selection.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))

if __name__=='__main__':main()
