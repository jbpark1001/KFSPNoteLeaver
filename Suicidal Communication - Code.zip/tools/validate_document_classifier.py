"""Evaluate document-type agreement with verified source IDs and recorded text.

Evaluate the historical first-1500-row convention and all usable labels
separately; never use a many-to-many text merge to measure accuracy.
"""
from pathlib import Path
import sys,json
import pandas as pd
from sklearn.metrics import accuracy_score,confusion_matrix
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from project import input_path,output_path,ROOT

def main():
    manual=pd.read_excel(input_path('manual_labels'))
    source=pd.read_csv(input_path('saved_scores'),usecols=['NOTE_CONTENTDTL','pred_label'])
    old=pd.read_excel(input_path('manual_predictions'))
    fresh_path=ROOT/'derived/scored_notes.pkl'
    fresh=pd.read_pickle(fresh_path) if fresh_path.exists() else None
    reports={}
    for scope,frame in [('first_1500_rows',manual.head(1500)),('all_labeled_rows',manual)]:
        label=frame['Manual Label'].astype('string').str.strip().str.upper()
        frame=frame[label.isin(['R','S'])].copy();truth=label.loc[frame.index].map({'R':'raw','S':'summarized'})
        ids=pd.to_numeric(frame.iloc[:,0],errors='raise').astype(int)
        assert ids.is_unique and ids.between(0,len(source)-1).all()
        normalize=lambda a:a.fillna('').astype(str).str.replace('엄마아빠','엄마 아빠',regex=False).to_numpy()
        assert (normalize(frame.NOTE_CONTENTDTL)==normalize(source.iloc[ids].NOTE_CONTENTDTL)).all()
        pred=source.iloc[ids].pred_label.to_numpy()
        row={'n':len(frame),'saved_classifier_accuracy':accuracy_score(truth,pred),
             'confusion_matrix_raw_summarized':confusion_matrix(truth,pred,labels=['raw','summarized']).tolist(),
             'linkage':'unique verified source position supplied in annotation workbook, verified against text',
             'manual_set_independence':'not independently established by available files'}
        # The older prediction workbook uses the same source-row IDs.
        assert (normalize(frame.NOTE_CONTENTDTL)==normalize(old.iloc[ids].NOTE_CONTENTDTL)).all()
        row['older_workbook_accuracy']=accuracy_score(truth,old.iloc[ids].pred_label)
        if fresh is not None:
            assert fresh.index.is_unique and set(ids).issubset(fresh.index)
            assert (normalize(frame.NOTE_CONTENTDTL)==normalize(fresh.loc[ids].NOTE_CONTENTDTL)).all()
            row['fresh_refitted_classifier_accuracy']=accuracy_score(truth,fresh.loc[ids].pred_label)
        row['manuscript_claim_n_1500_accuracy_805_reproduced']=len(frame)==1500 and abs(row['saved_classifier_accuracy']-.805)<.0005
        reports[scope]=row
    output_path('validation/document_classifier_manual_agreement.json').write_text(json.dumps(reports,indent=2),encoding='utf-8')
    print(json.dumps(reports,indent=2))

if __name__=='__main__':main()
